import { font60 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled, { keyframes } from "styled-components";

export const StyledError = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${THEME.white};
  ${font60}
`;

const fadeIn = keyframes`
  from {
    transform: scale(1);
    opacity: 0;
  }

  to {
    transform: scale(1);
    opacity: 1;
  }
`;

const fadeOut = keyframes`
  from {
    transform: scale(1);
    opacity: 1;
  }

  to {
    transform: scale(1);
    opacity: 0;
  }
`;

export const StyledLoaderWrapper = styled.div<{ $loading: boolean}>`
  display: flex;
  visibility: ${({$loading}) => $loading ? 'visible' : 'hidden'};
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 1);
  z-index: 9999;
  animation: ${fadeOut} 1s linear;
  transition: visibility 1s linear;
`
