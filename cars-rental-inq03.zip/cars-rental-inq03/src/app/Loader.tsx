'use client';

import { Oval } from 'react-loader-spinner'
import { StyledLoaderWrapper } from './StyledShared';

import { useLoading } from '@/context/LoadingContext';

export default function Loading() {
  const { loading } = useLoading();

  return (
    <StyledLoaderWrapper $loading={loading}>
      <Oval
        visible={true}
        height="80"
        width="80"
        secondaryColor="grey"
        color="#E74251"
        ariaLabel="oval-loading"
        wrapperClass=""
      />
    </StyledLoaderWrapper>
  )
}
