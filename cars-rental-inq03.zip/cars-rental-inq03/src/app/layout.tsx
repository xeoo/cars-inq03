import type { Metadata } from "next";
import StyledComponentsRegistry from "./lib/registry";
import MainLayout from "./MainLayout";
import "./globals.css";

export const metadata: Metadata = {
    openGraph: {
        type: 'website',
        url: 'https://prodrivenurburg.de',
        title: 'ProDrive Nürburg - Car Rental Nürburgring',
        description: 'Rent a Car Now. We offer well-built cars with high attention to safety. Founded by true Nürburgring enthusiasts',
        siteName: 'ProDrive Nürburg',
    },
    alternates: { canonical: "https://prodrivenurburg.de" },
    title: "ProDrive Nürburg - Car Rental Nürburgring",
    description: "Rent a Car Now. We offer well-built cars with high attention to safety. Founded by true Nürburgring enthusiasts",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body suppressHydrationWarning={true}>
        <StyledComponentsRegistry>
          <MainLayout>{children}</MainLayout>
        </StyledComponentsRegistry>
      </body>
    </html>
  );
}
