const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const carId = url.searchParams.get('carId');
    const { data } = await axios.get(`${domain}/api/orders?filters[car][id]=${carId}&pagination[pageSize]=10000`, config);

    const unavailableDates = data.data.reduce((acc, {attributes}) => {
      const slotOrdered = attributes.pickup_time.split('+');
      if (acc[attributes.pickup_date]) {
        acc[attributes.pickup_date] = [...acc[attributes.pickup_date], ...slotOrdered]
      } else {
        acc[attributes.pickup_date] = slotOrdered;
      }
      return acc;
    }, {});

    return NextResponse.json(JSON.stringify(unavailableDates), { status: 200 });
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}
