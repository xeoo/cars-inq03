import { NextResponse } from "next/server";

const axios = require('axios');

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const formatOrder = (data) => {
  const { carSlug, car, contacts, addons, totalPrice } = data;
  const { clientId, notes } = contacts;

  const addonsFormatted = addons.reduce((acc, addon, index) => acc + `${index + 1}. ${addon.title} - ${addon.price} \n`, '');
  const client_notes = `${notes || ''} \ntime slot - ${car.timeSlot}`;

  return ({
    client: clientId,
    car: parseInt(carSlug),
    pickup_date: car.date,
    pickup_time: car.checkedTime,
    payment_status: 'unpaid',
    client_notes: client_notes,
    laps: car.checkedLaps,
    insurance: 'no',
    addons: addonsFormatted,
    Order_sum: totalPrice.toString(),
    status: 'received',
    paid_sum: 0
  })
}

function fetchProducts(limit = 10) {
  return new Promise((resolve, reject) => {
    stripe.products.list({ limit }, (err, products) => {
      if (err) {
        reject(err);
      } else {
        resolve(products?.data);
      }
    });
  });
}

const createProduct = async (product) => {
  try {
    const newProduct = await stripe.products.create({
      name: product.title,
      id: product.id.toString(),
      description: product.description,
      images: [
        product.image
      ],
      default_price_data: {
        currency: 'eur',
        unit_amount: (product.price) * 100
      }
    });

    return newProduct;
  } catch (err) {
    console.error('createProduct err', err)
    throw err;
  }
}

const updateProduct = async (product) => {
  try {
    const updatedProduct = await stripe.products.update(product.id.toString(), {
      name: product.title,
      description: product.description,
      images: [product.image],
    });

    return updatedProduct;
  } catch (err) {
    console.error('updateProduct err', err)
    throw err;
  }
}

const createNewProducts = async (createProducts, updateProducts) => {
  try {
    const createPromises = createProducts.map(product => createProduct(product));
    const updatePromises = updateProducts.map(product => updateProduct(product));
    const createdProducts = await Promise.all(createPromises);
    const updatecProducts = await Promise.all(updatePromises);
    return [...createdProducts, ...updatecProducts];
  } catch (err) {
    console.error('createNewProducts error', err);
  }
};

async function getPriceIdByProductId(productId) {
  try {
    const product = await stripe.products.retrieve(productId);

    return product.default_price;
  } catch (err) {
    console.error('getPriceIdByProductId err', err)
    throw err;
  }
}

export async function POST(req) {
  try {
    const stripeListOfProducts = await fetchProducts(10000);

    const body = await req.json();

    const { car, carSlug, addons, payment } = body;

    const allProducts = [car, ...addons];

    const orderProducts = allProducts.map((product) => { 
      const originalDescription = product.description || '';
      const isFree = product.price === 0;
      const paymentPercentage =
          payment.payment_percentage < 100 && !isFree ? ` | Partial payment ${payment.payment_percentage}%` : '';
      const item = {
        ...product, 
        id: `${car.id}-${product.carId ? '' : product.id + '-'}${payment.payment_percentage}-${parseInt(product.price)}`,
        title: `${product.title}`, 
        description: `${originalDescription}${paymentPercentage}`,
        price: (product.price * payment.payment_percentage / 100).toFixed(2)
      } 

      return item;
    });

    const productsNotInTheStripe = orderProducts.filter(product2 =>
      !stripeListOfProducts.find(product1 => product1.id == product2.id)
    );

    const updateProducts = orderProducts.filter(product2 =>
      stripeListOfProducts.find(product1 => product1.id == product2.id)
    );

    await createNewProducts(productsNotInTheStripe, updateProducts);

    const priceIds = await Promise.all(orderProducts.map(({ id }) => getPriceIdByProductId(id.toString())));

    const order = formatOrder({ ...body });

    const { data } = await axios.post(`${domain}/api/orders`, { data: { ...order } }, config);

    const orderId = data.data.id;

    const session = await stripe.checkout.sessions.create({
      line_items: priceIds.map(price => ({ price, quantity: 1 })),
      mode: 'payment',
      cancel_url: `${req.headers.get('origin')}/checkout/${carSlug}/payment`,
      success_url: `${req.headers.get('origin')}/checkout/${carSlug}/finish`,
      metadata: {
        orderId
      },
    });

    return NextResponse.json(JSON.stringify({ sessionId: session.id, sessionUrl: session.url, orderId }), { status: 200 });
  } catch (err) {
    console.error(err.response.data.error.details);
    return NextResponse.json({ error: 'failed' }, { status: 500 })
  }
}