const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function POST(req) {
  try {
    const body = await req.json();

    await axios.post(`${domain}/api/contact-forms`, {data: { ...body}}, config);

    return NextResponse.json(JSON.stringify(true), { status: 200 });
  } catch (err) {
    console.error({resp: err.response.data})
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}