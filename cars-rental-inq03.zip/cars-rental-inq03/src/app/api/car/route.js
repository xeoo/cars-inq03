const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};
const requestUrl = (carId) => `${domain}/api/cars/${carId}?populate[specification]=*&populate[options][populate][0]=icon&populate=localizations`

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const carId = url.searchParams.get('carId');
    const language = url.searchParams.get('language');
    const { data } = await axios.get(requestUrl(carId), config);

    let { attributes, id } = data.data;

    let { specification, description, options, localizations } = attributes;

    const localizedCarId = localizations.data.filter((car) => car.attributes.locale === language)[0]?.id;

    if(localizedCarId) {
      const localizedCar = await axios.get(requestUrl(localizedCarId), config);

      specification = localizedCar.data.data.attributes.specification;
      description = localizedCar.data.data.attributes.description;
      options = localizedCar.data.data.attributes.options;
    }

    delete specification.id;

    const characteristics = Object.entries(specification).map(([key, value]) => ({
      title: key,
      description: value
    }));

    const car = {
      descriptionHtml: description,
      specifications: options.map((option) => ({...option, icon: `${domain}${option.icon.data.attributes.url}`})),
      characteristics,
      id,
    }

    return NextResponse.json(JSON.stringify({car}), { status: 200 });
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}