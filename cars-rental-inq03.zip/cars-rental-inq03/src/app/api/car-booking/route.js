const axios = require('axios');
import { NextResponse } from "next/server";
import { getLocalizedCars } from "../../../utils/api";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const language = url.searchParams.get('language');
    const { data } = await axios.get(`${domain}/api/cars?populate=image&populate=prices&populate=default_price&populate=image&populate=specification&populate=localizations`, config);
    
    let dataCars = data.data;

    if (language && language !== data.data[0]?.attributes?.locale) {
    dataCars = await getLocalizedCars(data.data, language, domain, config);
    }

    const cars = dataCars.map(({ attributes, id}) => { 
      const { title, image, prices, quantity, not_available_dates, sales_short_description, default_price, specification } = attributes;

      const priceOptions = prices.data.map(({attributes}) => ({laps: attributes.laps, price: attributes.amount, fullPrice: attributes.full_price}));

      const characteristics = Object.entries(specification).map(([key, value]) => ({
        title: key,
        description: value
      }));

      return ({
      id,
      title,
      image: `${domain}${image.data.attributes.url}`,
      priceOptions: priceOptions.sort((a, b) => a.laps - b.laps),
      quantity,
      unAvailableDates: not_available_dates,
      description: sales_short_description,
      price: default_price.data.attributes.amount,
      laps: default_price.data.attributes.laps,
      characteristics
    })
  })

    return NextResponse.json(JSON.stringify(cars), { status: 200 });
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}