const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

const getUrl = (language) => `${domain}/api/faqs?populate=*&locale=${language}`;

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const language = url.searchParams.get('language');

    const { data } = await axios.get(getUrl(language), config);

    const FAQ = data.data.map(({ id, attributes}) => {
      return ({
        id, 
        title: attributes.QA.question,
        content: attributes.QA.answer
      })}
    );

    return NextResponse.json(JSON.stringify(FAQ), { status: 200 });
  } catch (err) {
    console.log(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}