const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const carId = url.searchParams.get('carId');
    const laps = url.searchParams.get('laps');
    const language = url.searchParams.get('language');
    const isFullPrice = url.searchParams.get('isFullPrice');
    const { data: carDataMain } = await axios.get(`${domain}/api/cars/${carId}?populate[additions][populate][0]=image&populate=localizations`, config);

    let data = carDataMain;
    const localizedCarId = carDataMain.data.attributes.localizations.data.filter((car) => car.attributes.locale === language)[0]?.id;

    if (localizedCarId) {
      const { data: localizedCar } = await axios.get(`${domain}/api/cars/${localizedCarId}?populate[additions][populate][0]=image`, config);
      
      data = localizedCar;
    }

    const additions = data.data.attributes.additions.map(({id,title, image, isPricePerLap, full_price, isDefault, highlighted_description, description, price, type}) => { 
      const addonPrice = isFullPrice === 'true' && full_price ? full_price : price;

      return ({
        id,
        title,
        description: highlighted_description,
        image: `${domain}${image.data.attributes.url}`,
        descriptionHtml: description,
        price: isPricePerLap ? laps * addonPrice : addonPrice,
        type,
        isDefault
      })
    })

    return NextResponse.json(JSON.stringify(additions), { status: 200 });
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}