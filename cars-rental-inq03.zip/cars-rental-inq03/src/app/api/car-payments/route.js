const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const carId = url.searchParams.get('carId');
    const language = url.searchParams.get('language');
    const { data: carDataMain } = await axios.get(`${domain}/api/cars/${carId}?populate[payment_type][populate][0]=image&populate=localizations`, config);

    let data = carDataMain;
    const localizedCarId = carDataMain.data.attributes.localizations.data.filter((car) => car.attributes.locale === language)[0]?.id;

    if (localizedCarId) {
      const { data: localizedCar } = await axios.get(`${domain}/api/cars/${localizedCarId}?populate[payment_type][populate][0]=image`, config);
      
      data = localizedCar;
    }

    const additions = data.data.attributes.payment_type.map(({id,title, image, payment_percentage, description, price}) => { 
      return ({
      id,
      title,
      payment_percentage,
      image: `${domain}${image.data.attributes.url}`,
      description,
      price
      })
    })

    return NextResponse.json(JSON.stringify(additions), { status: 200 });
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}