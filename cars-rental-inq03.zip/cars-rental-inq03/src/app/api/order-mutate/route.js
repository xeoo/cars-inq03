const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function PUT(req) {
  try {
    const body = await req.json();

    const { data } = await axios.put(`${domain}/api/orders/${body.orderId}`, {data: { payment_status: "paid"}}, config);

    return NextResponse.json(JSON.stringify({ clientId: data.data.id }), { status: 200 });
  } catch (err) {
    console.error({resp: err.response.data})
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}