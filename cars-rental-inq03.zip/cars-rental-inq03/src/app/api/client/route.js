const axios = require('axios');
import { NextResponse } from "next/server";

const domain = "http://31.131.21.128:30000";

const config = {
  headers: { Authorization: `Bearer ${process.env.STRAPI_TOKEN}` }
};

export async function GET(request) {
  try {
    const url =  new URL(request.url);
    const email = url.searchParams.get('email');

    const {data} = await axios.get(`${domain}/api/clients`, config);
    
    const isClient = data.data.find(({attributes}) => attributes.email === email);

    return NextResponse.json(JSON.stringify({clientId: isClient?.id}), { status: 200 });
  } catch (err) {
    console.error({resp: err})
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}

export async function POST(req) {
  try {
    const body = await req.json();

    const { data } = await axios.post(`${domain}/api/clients`, {data: { ...body}}, config);

    return NextResponse.json(JSON.stringify({ clientId: data.data.id }), { status: 200 });
  } catch (err) {
    console.error({resp: err.response.data})
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}

export async function PUT(req) {
  try {
    const url =  new URL(req.url);
    const clientId = url.searchParams.get('clientId');

    const body = await req.json();

    const { data } = await axios.put(`${domain}/api/clients/${clientId}`, {data: { ...body}}, config);

    return NextResponse.json(JSON.stringify({ clientId: data.data.id }), { status: 200 });
  } catch (err) {
    console.error({resp: err.response.data})
    return NextResponse.json({ error: 'failed'}, { status: 500 })
  }
}