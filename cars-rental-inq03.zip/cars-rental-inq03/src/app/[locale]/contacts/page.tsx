import Contacts from './Contacts'
import {Metadata} from "next";

export const metadata: Metadata = {
    title: 'Contact Us - ProDrive Nürburg | Car Rental Nürburgring',
    description: '' // TODO add title and description
}

export default function ContactsPage(){
    return <Contacts />;
}
