"use client";

import ContactForm from "@/components/ContactForm/ContactForm";
import {
    StyledContacts,
    InfoWrapper,
    ContactFormWrapper,
} from "./StyledContacts";
import Map from "@/components/Map/Map";
import ContactInfo from "@/components/ContactInfo/ContactInfo";

export default function Contacts() {
    return (
        <>
            <StyledContacts>
                <InfoWrapper>
                    <ContactInfo />
                </InfoWrapper>
                <ContactFormWrapper>
                    <ContactForm />
                </ContactFormWrapper>
            </StyledContacts>
            <Map />
        </>
    );
}
