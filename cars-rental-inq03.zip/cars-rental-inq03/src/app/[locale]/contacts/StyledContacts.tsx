import { DEVICE } from "@/utils/device";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledContacts = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 100px;
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
    margin-top: 100px;
    margin-left: auto;
    margin-right: auto;
  }
`;

export const InfoWrapper = styled.div`
  flex: 0.7;
  padding: 30px;
  gap: 30px;
  border-radius: 12px 0px 0px 12px;
  border-width: 1px 0px 1px 1px;
  border-style: solid;
  border-color: ${THEME.grey100};
  @media (max-width: ${DEVICE.large}px) {
    display: none;
  }
`;

export const ContactFormWrapper = styled.div`
  flex: 1;
  padding: 30px;
  gap: 30px;
  border-radius: 0px 12px 12px 0px;
  border: 1px solid ${THEME.grey100};
  @media (max-width: ${DEVICE.large}px) {
    border: none;
  }
`;
