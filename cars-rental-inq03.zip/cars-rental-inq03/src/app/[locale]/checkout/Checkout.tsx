'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import { routes } from "@/constants/routes";
import { useLoading } from '@/context/LoadingContext';

export default function Checkout() {
  const { setLoading } = useLoading();
  const router = useRouter();

  useEffect(() => {
    const fetchCarsAndRedirect = async () => {
      try {
        const { data } = await axios.get('/api/car-booking?');

        const items = JSON.parse(data);

        if (items.length > 0) {

          const itemId = items[0].id;
          router.push(`${routes.mainRoutes[1].path}/${itemId}/booking`);
        } else {
          console.error('No items available');
        }
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    };
    setLoading(true);
    fetchCarsAndRedirect();
  }, [router]);

  return null;
}
