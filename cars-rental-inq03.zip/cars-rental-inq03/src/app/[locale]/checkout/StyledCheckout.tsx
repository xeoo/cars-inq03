import { font60 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledCheckout = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${THEME.white};
  ${font60}
`;
