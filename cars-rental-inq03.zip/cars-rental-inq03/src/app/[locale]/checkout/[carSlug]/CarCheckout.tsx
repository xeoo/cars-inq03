"use client";

import Button from "@/components/UI/Button/Button";
import { StyledBooking } from "./StyledBooking";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";
import Link from "next/link";
import { routes } from "@/constants/routes";
import { SlugType } from "@/type/type";

export default function CarCheckout({ params }: SlugType) {
    const { t } = useTranslation();

    return (
        <StyledBooking>
            {t("Book a car")}
            {params.carSlug}
            <Link href={`${routes.mainRoutes[1].path}/${params.carSlug}/booking`}>
                <Button title={t("Next Step")} />
            </Link>
        </StyledBooking>
    );
}
