import Additions from './Additions'
import {Metadata} from "next";
import {SlugType} from "@/type/type";

export const metadata: Metadata = {
  title: 'Customize Your Booking - ProDrive Nürburg Booking',
  description: 'Select options like insurance, helmet, video recording, and ticket packages to enhance your car rental experience.'
}

export default function AdditionsPage({ params }: SlugType){
  return <Additions params={params}/>;
}
