"use client";

import axios from "axios";
import Checkout from "@/components/Checkout/CheckoutPath";
import { SlugType } from "@/type/type";
import { checkoutPath } from "@/constants/checkoutPath";

import AdditionCheckout from "@/components/AdditionCheckout/AdditionCheckout";
import { useEffect, useState } from "react";
import { useLoading } from "@/context/LoadingContext";
import { useOrder } from "@/context/OrderContext";
import { TAddition } from "@/types/order";
import { useLanguage } from "@/context/LanguageContext";
import { redirect } from "next/navigation";

const sortAdditions = (additions: TAddition[]): TAddition[] => {
  const packageAdditions = additions.filter(
    (addition) => addition.type === "package"
  );
  const insuranceAdditions = additions.filter(
    (addition) => addition.type === "insurance"
  );
  const otherAdditions = additions.filter(
    (addition) => addition.type !== "package" && addition.type !== "insurance"
  );
  return [...packageAdditions, ...insuranceAdditions, ...otherAdditions];
};

export default function Additions({ params }: SlugType) {
  const { setLoading } = useLoading();
  const { order } = useOrder();
  const { language } = useLanguage();

  const [additions, setAdditions] = useState<TAddition[]>([]);

  useEffect(() => {
    if (!order.car) {
      redirect("/checkout");
    }
  }, []);

  const getCarAdditions = async () => {
    try {
      const { data } = await axios.get(
        `/api/car-additions?carId=${params.carSlug}&laps=${order.car.checkedLaps}&isFullPrice=${order.car.isFullPrice}&language=${language}`
      );

      const arrayData: TAddition[] = JSON.parse(data);

      const sortedData = sortAdditions(arrayData);

      setAdditions(sortedData);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    getCarAdditions();
  }, [language]);

  if (!order.car) return null;

  return (
    <>
      <Checkout
        checkoutPath={checkoutPath}
        activeIndex={2}
        carSlug={params.carSlug}
      />
      <AdditionCheckout additions={additions} carSlug={params.carSlug} />
    </>
  );
}
