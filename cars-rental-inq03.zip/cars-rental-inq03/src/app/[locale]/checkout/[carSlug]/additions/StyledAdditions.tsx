'use client';

import styled from "styled-components";
import { font16 } from '@/utils/fonts'
import { THEME } from "@/utils/theme";

export const StyledBooking = styled.div`
  width: 1170px;
  margin: 0 auto;
  border: 1px solid ${THEME.grey100};
  border-radius: 12px;
  display: flex;
  justify-content: center;
`;

export const StyledTable = styled.table`
  color: ${THEME.white};
  ${font16}
  border-collapse: separate;
  border-spacing: 2px;
  td {
    width: 100px;
  }
`
