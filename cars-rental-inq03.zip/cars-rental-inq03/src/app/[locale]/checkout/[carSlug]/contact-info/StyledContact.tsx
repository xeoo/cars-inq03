'use client';

import styled from "styled-components";

export const StyledContact = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
