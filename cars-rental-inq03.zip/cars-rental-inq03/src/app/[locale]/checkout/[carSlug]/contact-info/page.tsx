import { StyledContact } from "./StyledContact";
import Checkout from "@/components/Checkout/CheckoutPath";
import { SlugType } from "@/type/type";
import { checkoutPath } from "@/constants/checkoutPath";
import ContactCheckout from "@/components/ContactCheckout/ContactCheckout";
import {Metadata} from "next";


export const metadata: Metadata = {
    title: 'Your Contact Information - ProDrive Nürburg Booking',
    description: 'Provide your contact information for the ProDrive Nürburg car rental booking process. Ensure accurate details for seamless communication.'
}

export default function Contact({ params }: SlugType) {
  return (
    <>
      <Checkout
        checkoutPath={checkoutPath}
        activeIndex={3}
        carSlug={params.carSlug}
      />
      <StyledContact>
        <ContactCheckout params={params} />
      </StyledContact>
    </>
  );
}
