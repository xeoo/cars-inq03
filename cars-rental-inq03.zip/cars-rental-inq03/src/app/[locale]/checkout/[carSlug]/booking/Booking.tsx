"use client";
import { useEffect, useState } from "react";
import axios from "axios";
import {
  CalenderWrapper,
  CarsCheckoutViewWrapper,
  Divider,
  DividerWrapper,
  BookingDayTimeWrapper,
  StyledBooking,
  StyledTable,
  StyledTR,
  BookingLapsItemWrapper,
} from "./StyledBooking";
import Checkout from "@/components/Checkout/CheckoutPath";
import { SlugType } from "@/type/type";
import { checkoutPath } from "@/constants/checkoutPath";
import Calendar from "@/components/Calendar/Calendar";
import { Car } from "@/types/car";
import NextStepButton from "@/components/NextStepButton/NextStepButton";
import CarsCheckoutView from "@/components/CarsCheckoutView/CarsCheckoutView";
import { useTranslation } from "react-i18next";
import CheckMark from "@/assets/icon/check_mark.svg";
import XIcon from "@/assets/icon/x.svg";
import MorningIcon from "@/assets/icon/morning.svg";
import EveningIcon from "@/assets/icon/evening.svg";
import { useLoading } from "@/context/LoadingContext";
import { getFormattedDates } from "@/utils/common";
import { useCars } from "@/context/CarsContext";
import { useCar } from "@/context/CarContext";
import { useLanguage } from "@/context/LanguageContext";

const getDayFromDate = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};

function toBerlinTime(date?: string) {
  const berlinOffset = new Date(date || new Date()).toLocaleString("en-US", {
    timeZone: "Europe/Berlin",
  });
  const berlinDate = new Date(berlinOffset);
  return berlinDate;
}

const findClosestNextDate = (dates: Array<string>) => {
  const today = toBerlinTime();
  let closestDate: Date = toBerlinTime();

  dates.forEach((dateString) => {
    const date = toBerlinTime(dateString);
    if (date > today && today >= closestDate) {
      closestDate = date;
    }
  });

  return closestDate;
};

export default function Booking({ params }: SlugType) {
  const { cars, setCars } = useCars();
  const { car, setCar } = useCar();
  const [activeCarIndex, setActiveCarIndex] = useState<number | null>(null); // only for the slider

  const [availableDates, setAvailableDates] = useState<{
    [k: string]: { [k: string]: any };
  }>({});
  const [date, setDate] = useState(new Date());
  const { t } = useTranslation();
  const { setLoading, loading } = useLoading();
  const { language } = useLanguage();

  useEffect(() => {
    if (cars.length > 0) {
      const carIndex = cars.findIndex(({ id }) => id == params.carSlug);
      setActiveCarIndex(carIndex);
    }
  }, [cars]);

  const getCarOrdered = async () => {
    try {
      const { data } = await axios.get(
        `/api/car-orders?&carId=${params.carSlug}`
      );
      const unavailableDates = JSON.parse(data);

      const formattedDates = getFormattedDates({
        orderedDates: unavailableDates,
        unAvailableDates: car?.unAvailableDates,
        quantity: car?.quantity,
      });

      setDate(findClosestNextDate(Object.keys(formattedDates)));
      setAvailableDates(formattedDates);
      setLoading(false);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (car) {
      getCarOrdered();
    }
  }, [car]);

  const getCars = async () => {
    try {
      const { data } = await axios.get(
        `/api/car-booking?&language=${language}`
      );

      setCar(JSON.parse(data).find((car: Car) => car.id == params.carSlug));
      setCars(JSON.parse(data));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    setLoading(true);
    getCars();
  }, [language]);

  if (loading && cars.length === 0) return;

  const tileDisabled = ({ date }: { date: Date }) => {
    if (!Object.keys(availableDates).includes(getDayFromDate(date))) {
      return true;
    }
    return false;
  };

  type DayTime = "morning" | "afternoon";

  const calculateBookingLaps = (dayTime: DayTime): JSX.Element[] => {
    switch (dayTime) {
      case "morning":
        return car?.priceOptions?.map(({ laps }) => (
          <BookingLapsItemWrapper key={laps}>
            {availableDates[getDayFromDate(date)].morning &&
            laps <= availableDates[getDayFromDate(date)].morningLaps ? (
              <CheckMark />
            ) : (
              <XIcon />
            )}
          </BookingLapsItemWrapper>
        ));

      case "afternoon":
        return car?.priceOptions?.map(({ laps }) => (
          <BookingLapsItemWrapper key={laps}>
            {availableDates[getDayFromDate(date)].evening &&
            laps <= availableDates[getDayFromDate(date)].eveningLaps ? (
              <CheckMark />
            ) : (
              <XIcon />
            )}
          </BookingLapsItemWrapper>
        ));
    }
  };

  return (
    <>
      <Checkout
        checkoutPath={checkoutPath}
        activeIndex={1}
        carSlug={params.carSlug}
      />
      <StyledBooking>
        <CalenderWrapper>
          {date && (
            <Calendar
              setDate={setDate}
              date={date}
              tileDisabled={tileDisabled}
            />
          )}
          <Divider />
          {availableDates[getDayFromDate(date)] && (
            <StyledTable>
              <StyledTR>
                <div></div>
                {car?.priceOptions?.map(({ laps }) => (
                  <div key={laps}>{t("laps", { count: laps })}</div>
                ))}
              </StyledTR>
              <StyledTR>
                <BookingDayTimeWrapper>
                  <MorningIcon />
                  {t("Morning")}
                </BookingDayTimeWrapper>
                {calculateBookingLaps("morning")}
              </StyledTR>
              <StyledTR>
                <BookingDayTimeWrapper>
                  <EveningIcon />
                  {t("Evening")}
                </BookingDayTimeWrapper>
                {calculateBookingLaps("afternoon")}
              </StyledTR>
            </StyledTable>
          )}
        </CalenderWrapper>
        <CarsCheckoutViewWrapper>
          {availableDates[getDayFromDate(date)] &&
            car &&
            activeCarIndex !== null && (
              <CarsCheckoutView
                car={car}
                activeCarIndex={activeCarIndex}
                cars={cars}
                dateData={availableDates[getDayFromDate(date)]}
                date={getDayFromDate(date)}
              />
            )}
          <NextStepButton params={params} step="additions" />
          <DividerWrapper>
            <Divider />
          </DividerWrapper>
        </CarsCheckoutViewWrapper>
      </StyledBooking>
    </>
  );
}
