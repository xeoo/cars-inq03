"use client";

import styled from "styled-components";
import { font16 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import { DEVICE } from "@/utils/device";

export const StyledBooking = styled.div`
  margin: 0 auto;
  display: flex;

  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
    flex-direction: column;
    margin-top: 200px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
    flex-direction: column;
    margin-top: 200px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
    border: 1px solid ${THEME.grey100};
    border-radius: 12px;
    justify-content: center;
  }
`;

export const StyledTable = styled.div`
  color: ${THEME.white};
  ${font16}
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-top: 30px;
`;

export const StyledTR = styled.div`
  margin-bottom: 30px;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  justify-items: center;
  align-items: center;
  @media (max-width: ${DEVICE.medium}px) {
    grid-template-columns: 105px repeat(4, 1fr);
  }
`;

export const CalenderWrapper = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    padding: 30px;
  }
`;

export const CarsCheckoutViewWrapper = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    border-left: 1px solid ${THEME.grey100};
    padding: 30px;
  }
`;

export const Divider = styled.div`
  height: 1px;
  background: ${THEME.grey100};

  @media (max-width: ${DEVICE.medium}px) {
    margin: 20px 0px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    margin: 30px 0px;
  }
  @media (min-width: ${DEVICE.large}px) {
    margin: 30px -30px;
  }
`;

export const DividerWrapper = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    display: none;
  }
`;

export const BookingDayTimeWrapper = styled.div`
  display: flex;
  gap: 14px;
  justify-self: flex-start;
  @media (max-width: ${DEVICE.medium}px) {
    gap: 5px;
  }
`;

export const BookingLapsItemWrapper = styled.div`
  display: flex;
`;
