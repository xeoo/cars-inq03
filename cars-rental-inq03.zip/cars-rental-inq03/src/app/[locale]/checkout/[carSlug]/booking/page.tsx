import Booking from './Booking'
import {Metadata} from "next";
import {SlugType} from "@/type/type";

export const metadata: Metadata = {
  title: 'Select Date - ProDrive Nürburg Booking',
  description: 'View available dates and cars. Book your race car for the Nürburgring track.'
}

export default function BookingPage({ params }: SlugType){
  return <Booking params={params}/>;
}
