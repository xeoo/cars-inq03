import CarCheckout from './CarCheckout'
import {Metadata} from "next";
import {SlugType} from "@/type/type";

export const metadata: Metadata = {
    title: '',
    description: '' // TODO add title and description
}

export default function CheckoutPage({params}: SlugType){
    return <CarCheckout  params={params}/>;
}
