'use client'

import axios from 'axios';

import Checkout from "@/components/Checkout/CheckoutPath";
import { SlugType } from "@/type/type";
import { checkoutPath } from "@/constants/checkoutPath";
import { TPayment } from '@/types/order';

import PaymentView from "@/components/PaymentView/PaymentView";
import { useEffect, useState } from "react";
import { useLoading } from '@/context/LoadingContext';
import { useLanguage } from '@/context/LanguageContext';

export default function Payment({ params }: SlugType) {
  const { setLoading } = useLoading();
  const [payments, setPayments] = useState<TPayment[]>([])
  const { language } = useLanguage();
  
  const getCarPaymentType = async () => {
    try {
      const { data } = await axios.get(`/api/car-payments?carId=${params.carSlug}&language=${language}`);

      setPayments(JSON.parse(data));
      setLoading(false)
    } catch (err) {
      console.error(err);
      setLoading(false)
    }
  }

  useEffect(() => {
    setLoading(true)
    getCarPaymentType()
  }, [language])
  
  return (
    <>
      <Checkout
        checkoutPath={checkoutPath}
        activeIndex={4}
        carSlug={params.carSlug}
      />
      {payments.length > 0 && <PaymentView payments={payments} carSlug={params.carSlug} />}
    </>
  );
}