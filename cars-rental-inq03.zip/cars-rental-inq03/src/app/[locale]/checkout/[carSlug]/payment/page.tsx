import { Metadata } from "next";
import { SlugType } from "@/type/type";
import Payment from "./Payment";

export const metadata: Metadata = {
  title: 'Payment - ProDrive Nürburg Booking',
  description: '' // TODO add title and description
}

export default function PaymentPage({ params }: SlugType) {
  return <Payment params={params} />;
}
