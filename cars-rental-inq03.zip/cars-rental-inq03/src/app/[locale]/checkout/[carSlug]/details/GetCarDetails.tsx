'use client';
import { SlugType } from "@/type/type";
import axios from 'axios';
import Details from "./Details";

import { useEffect, useState } from "react";
import { useLoading } from "@/context/LoadingContext";
import { Car, CarDetail } from "@/types/car";
import { FaqType } from "@/types/util";
import { useLanguage } from "@/context/LanguageContext";

const MINIMIZED_FAQ_LIST_QUANTITY = 5;

export default function DetailsPage({ params }: SlugType) {
  const { setLoading } = useLoading();
  const [car, setCar] = useState<CarDetail | null>(null);
  const { language } = useLanguage();
  const [carList, setCarList] = useState<Array<Car>>([]);
  const [FAQList, setFAQList] = useState<{ minimizedFaqList: FaqType[], maximizedFaqList: FaqType[] }>({ minimizedFaqList: [], maximizedFaqList: [] })

  const getCars = async () => {
    try {
      const { data } = await axios.get(`/api/car?carId=${params.carSlug}&language=${language}`);
      const { data: cars } = await axios.get(`/api/cars-catalog?language=${language}`);
      const { car } = JSON.parse(data);

      const { data: FAQ } = await axios.get(`/api/faq?language=${language}`);
      const faqList = JSON.parse(FAQ);
      const minimizedFaqList = faqList.slice(0, MINIMIZED_FAQ_LIST_QUANTITY)
      setFAQList({ minimizedFaqList, maximizedFaqList: faqList });

      setCar(car);
      setCarList(JSON.parse(cars).map((carSlide: Partial<Car>) => {
        delete carSlide.characteristics;
        return ({ ...carSlide })
      }
      ));
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  }

  useEffect(() => {
    setLoading(true);
    getCars()
  }, [language])

  return (
    <Details car={car} carList={carList} FAQList={FAQList} />
  );
}
