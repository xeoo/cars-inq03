import { DEVICE } from "@/utils/device";
import {
  font14,
  font16,
  font20,
  font20_400_26,
  font28_600_36,
  font48,
  font56,
} from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledDetails = styled.div`
  margin-top: -100px;
  margin: 0 auto;
  @media (max-width: ${DEVICE.small}px) {
    width: ${DEVICE.small}px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
  }
`;

export const StyledLogoPage = styled.div`
  @media (max-width: ${DEVICE.large}px) {
    display: none;
  }
  height: 800px;
  width: 100vw;
  position: absolute;
  left: 0;
  z-index: 0;
  background-size: cover;
  background: linear-gradient(0deg, ${THEME.dark}, rgba(6, 4, 5, 0.8)),
    linear-gradient(180deg, rgba(26, 15, 20, 0) 77.5%, #1a0f14 100%),
    linear-gradient(253.21deg, rgba(26, 15, 20, 0) 43.97%, #1a0f14 62.33%),
    url(/image/mainHeaderLogo.png), 0;
  background-repeat: round;
  margin-top: -100px;
`;

export const SliderWrapper = styled.div``;

export const Title = styled.h3`
  ${font56}
  color: ${THEME.white};
  text-align: center;
  @media (max-width: ${DEVICE.medium}px) {
    ${font28_600_36};
    margin-top: 60px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font48};
  }
`;

export const SpecificationsWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 60px 0px 60px 0px;
  @media (max-width: ${DEVICE.medium}px) {
    width: 320px;
    margin: 0 auto;
    flex-wrap: wrap;
  }
`;

export const SpecificationsMainWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 120px;
  @media (min-width: ${DEVICE.large}px) {
    margin-top: 60px;
    height: auto;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 320px;
    margin: 0 auto;
  }
`;

export const BtnWrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 60px;
  margin-bottom: 60px;
`;

export const TableWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 60px;
  margin-top: 60px;
  div:first-child {
    div:first-child {
      border-radius: 8px 0px 0px 0px;
    }
    div:last-child {
      border-radius: 0px 0px 0px 8px;
    }
  }
  div:last-child {
    div:first-child {
      border-radius: 0px 8px 0px 0px;
    }
    div:last-child {
      border-radius: 0px 0px 8px 0px;
    }
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 100%;
    flex-direction: column;
    margin: 0 auto 60px auto;
    padding: 0 20px;
    div:first-child {
      div:first-child {
        border-radius: 8px 0px 0px 0px;
      }
      div:last-child {
        border-radius: 0px 8px 0px 0px;
      }
    }
    div:last-child {
      div:first-child {
        border-radius: 0px 0px 0px 8px;
      }
      div:last-child {
        border-radius: 0px 0px 8px 0px;
      }
    }
  }
`;

export const ColumWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: -webkit-fill-available;
  @media (max-width: ${DEVICE.medium}px) {
    flex-direction: row;
    width: 100%;
  }
`;

export const PricingWrapper = styled.div`
  div {
    table {
      margin: 3px 3px 0px 0px;
      @media (max-width: ${DEVICE.medium}px) {
        width: ${DEVICE.small}px;
        margin: 30px auto;
        tbody {
          display: flex;
          flex-direction: row;
          justify-content: center;
        }
        tr {
          display: flex;
          flex-direction: column;
          flex: 1;
        }
        tr:first-child {
          td {
            color: ${THEME.white};
            background: ${THEME.red200};
          }
          td:last-child {
            border-bottom-left-radius: 8px;
          }
          td:first-child {
            border-top-left-radius: 8px;
          }
        }
        tr:last-child {
          td:last-child {
            border-bottom-right-radius: 8px;
          }
          td:first-child {
            border-top-right-radius: 8px;
          }
        }
        td {
          display: flex;
          align-items: center;
          justify-content: center;
          color: ${THEME.grey};
          background: ${THEME.grey600};
          margin: 3px 3px 0px 0px;
        }
      }
      @media (min-width: ${DEVICE.medium}px) {
        width: ${DEVICE.large}px;
        margin: 60px auto;
      }
      @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
        width: ${DEVICE.medium}px;
        margin: 60px auto;
      }
      ${font20_400_26};

      @media (min-width: ${DEVICE.medium}px) {
        tr:first-child {
          color: ${THEME.white};
          background: ${THEME.red200};
          td:last-child {
            border-top-right-radius: 8px;
          }
          td:first-child {
            border-top-left-radius: 8px;
          }
        }
        tr:last-child {
          td:last-child {
            border-bottom-right-radius: 8px;
          }
          td:first-child {
            border-bottom-left-radius: 8px;
          }
        }
        tr {
          color: ${THEME.grey};
          background: ${THEME.grey600};
        }
        td {
          height: 68px;
          text-align: center;
          @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
            ${font16}
          }
        }
      }
      td {
        @media (max-width: ${DEVICE.medium}px) {
          ${font14}
          height: 44px;
        }
      }
    }
    ul {
      color: ${THEME.grey};
      li {
        padding: 8px 0;
        a {
          color: ${THEME.red};
          text-decoration: none;
        }
      }
      li::marker {
        content: "-   ";
        font-size: 1.2em;
        color: ${THEME.red};
      }
      @media (max-width: ${DEVICE.medium}px) {
        width: ${DEVICE.small}px;
        margin: auto;
        ${font14};
        li {
          width: 320px;
        }
      }
      @media (min-width: ${DEVICE.medium}px) {
        width: ${DEVICE.large}px;
        margin: auto;
        ${font20}
      }
      @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
        width: ${DEVICE.medium}px;
        margin: auto;
        ${font16};
      }
    }
  }
`;
