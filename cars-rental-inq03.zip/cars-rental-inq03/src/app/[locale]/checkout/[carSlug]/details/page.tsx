import GetCarDetails from './GetCarDetails'
import { Metadata } from "next";
import { SlugType } from "@/type/type";

export const metadata: Metadata = {
  title: 'ProDrive Nürburg - Car Rental Nürburgring',
  description: 'Explore high-performance car rentals at ProDrive Nürburg and drive on the Nürburgring track. Detailed specs and services.'
}

export default function DetailsPage({ params }: SlugType) {
  return <GetCarDetails params={params} />;
}
