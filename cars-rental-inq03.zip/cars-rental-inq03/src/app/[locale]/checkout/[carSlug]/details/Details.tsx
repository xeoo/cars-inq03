"use client";

import MainSlider from "@/components/MainSlider/MainSlider";
import {
  SliderWrapper,
  SpecificationsWrapper,
  StyledDetails,
  StyledLogoPage,
  Title,
  SpecificationsMainWrapper,
  BtnWrapper,
  PricingWrapper,
} from "./StyledDetails";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";
import CarCart from "@/components/CarCart/CarCart";
import Faq from "@/components/Faq/Faq";
import SpecificationsInfo from "@/components/UI/SpecificationsInfo/SpecificationsInfo";
import SpecificationsMain from "@/components/UI/SpecificationsMain/SpecificationsMain";
import Link from "next/link";
import { routes } from "@/constants/routes";
import Button from "@/components/UI/Button/Button";

import { IFAQList } from "@/types/util";
import { Car, CarDetail } from "@/types/car";
import { useParams } from "next/navigation";
import { useLoading } from "@/context/LoadingContext";

type DetailsProps = {
  carList: Array<Car>;
  car: CarDetail | null;
  FAQList: IFAQList;
};

export default function Details({ car, carList, FAQList }: DetailsProps) {
  const { carSlug } = useParams<any>();
  const { loading } = useLoading();

  const { t } = useTranslation();

  if (loading) return null;

  return (
    <StyledDetails>
      <StyledLogoPage />
      <SliderWrapper>
        <MainSlider
          activeCarIndex={carList.findIndex(({ id }) => id == carSlug) || 0}
          cars={carList}
        >
          {carList.map((carItem, index) => (
            <div key={carItem.id}>
              <CarCart
                key={carItem.id}
                {...carItem}
                iconRight={index % 2 !== 0}
                showMaskGroup={false}
              />
            </div>
          ))}
        </MainSlider>
      </SliderWrapper>
      <Title>{t("Specifications")}</Title>
      <SpecificationsWrapper>
        {car?.characteristics.map(({ title, description }, index) => (
          <SpecificationsInfo
            key={title}
            index={index}
            label={title}
            title={description}
          />
        ))}
      </SpecificationsWrapper>
      <SpecificationsMainWrapper>
        {car?.specifications.map((el, index) => (
          <SpecificationsMain
            key={index}
            label={el.label}
            title={el.title}
            icon={el.icon}
            index={index}
            description={el.description}
            color={index % 2 !== 0}
          />
        ))}
      </SpecificationsMainWrapper>
      <Title>{t("Pricing")}</Title>
      {car && (
        <PricingWrapper
          dangerouslySetInnerHTML={{ __html: car.descriptionHtml }}
        ></PricingWrapper>
      )}
      <BtnWrapper>
        <Link href={`${routes.mainRoutes[1].path}/${car?.id}/booking`}>
          <Button title={t("bookNow")} width="320px" />
        </Link>
      </BtnWrapper>
      <Faq FAQList={FAQList} />
    </StyledDetails>
  );
}
