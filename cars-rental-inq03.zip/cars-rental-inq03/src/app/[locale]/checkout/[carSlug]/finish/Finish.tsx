"use client";

import {
    AdditionalQuestions,
    QuestionsWrapper,
    ReachOut,
    ResultInfo,
    Results,
    StyledFinish,
    StyledFinishWrapper,
    Title,
} from "./StyledFinish";
import "@/localization/i18n";
import { SlugType } from "@/type/type";
import { useTranslation } from "react-i18next";
import ThankYouIcon from "@/assets/icon/thankYouIcon.svg";
import Recommendation from "@/components/UI/Recommendation/Recommendation";
import Arriving from "@/assets/icon/arriving.svg";
import License from "@/assets/icon/license.svg";
import GetReady from "@/assets/icon/getReady.svg";
import { useEffect } from "react";
import { useOrder } from "@/context/OrderContext";
import { useLoading } from "@/context/LoadingContext";

const RESULTS = {
    time: "17:00 - 02.04.2024",
    place: "Auf d. Struth 9, 53539 Kelberg",
};

const RECOMENDATION = [
    {
        icon: <Arriving />,
        title:
            "To ensure a smooth departure, we recommend arriving 20 minutes early.",
    },
    {
        icon: <License />,
        title: "Please remember to bring your driver's license and passport/ID.",
    },
    {
        icon: <GetReady />,
        title: "Get ready for an unforgettable experience!",
    },
];
export default function Finish({ params }: SlugType) {
    const { t } = useTranslation();
    const { order: { car } } = useOrder();
    const { loading, setLoading} = useLoading()

    useEffect(() => {
        try {
            const session = sessionStorage.getItem("sessionId");

            if (session) {
                const {sessionId, orderId} = JSON.parse(session)
                fetch("/api/order-mutate", {
                    method: "PUT",
                    body: JSON.stringify({ sessionId, orderId, payment_status: "paid" }),
                });

                sessionStorage.removeItem("sessionId");
                setLoading(false);
            }
        } catch (err) {
            console.error(err);
        }
    }, []);

    if(loading) return null;

    return (
        <StyledFinishWrapper>
            <StyledFinish>
                <ThankYouIcon />
                <Title>
                    {t(
                        "Thank you for choosing ProDrive Nürburg for your upcoming adventure!"
                    )}
                </Title>
                <Results>
                    {t("Your car will be ready at")}{" "}
                    {car && car.time && <ResultInfo>{car.time.split('-')[0] + ' - ' + car.date}</ResultInfo>} {t("at")}{" "}
                    <ResultInfo>{RESULTS.place}</ResultInfo>
                </Results>
                {RECOMENDATION.map((el, index) => (
                    <Recommendation key={index} icon={el.icon} title={t(el.title)} />
                ))}
            </StyledFinish>
            <QuestionsWrapper>
                <AdditionalQuestions>
                    {t("If you have any additional questions,")}
                </AdditionalQuestions>{" "}
                <ReachOut>{t("feel free to reach out.")}</ReachOut>
            </QuestionsWrapper>
        </StyledFinishWrapper>
    );
}
