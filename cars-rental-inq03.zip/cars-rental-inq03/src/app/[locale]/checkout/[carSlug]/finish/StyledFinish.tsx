import { DEVICE } from "@/utils/device";
import { font12, font14, font16, font20, font20_600_28 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledFinishWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  margin-top: 85px;
  @media (max-width: ${DEVICE.large}px) {
    margin-top: 0px;
    border: 1px solid ${THEME.grey100};
  }
`;

export const StyledFinish = styled.div`
  padding: 60px 45px 45px 45px;
  gap: 45px;
  border-radius: 12px;
  border: 1px solid ${THEME.grey100};
  background: ${THEME.grey700};
  text-align: center;
  max-width: 745px;
  @media (max-width: ${DEVICE.large}px) {
    border-radius: 0px;
    background: ${THEME.dark};
    border: none;
  }
  @media (mim-width: ${DEVICE.large}px) {
    width: 443px;
  }
`;

export const Title = styled.div`
  ${font20_600_28}
  color: ${THEME.white};
  text-align: center;
  margin-top: 45px;
  margin-bottom: 40px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font16}
  }
`;

export const Results = styled.div`
  display: inline-block;
  height: 54px;
  padding: 24px 30px 24px 30px;
  gap: 10px;
  border-radius: 8px;
  background: ${THEME.red300};
  border: 1px solid ${THEME.red50};
  ${font20};
  color: ${THEME.grey};
  margin-bottom: 45px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
    padding: 16px 20px;
  }
`;

export const ResultInfo = styled.span`
  color: ${THEME.white};
`;

export const AdditionalQuestions = styled.span`
  ${font16}
  color: ${THEME.grey};
  @media (max-width: ${DEVICE.medium}px) {
    ${font12}
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font14}
  }
`;

export const ReachOut = styled.span`
  ${font16}
  color: ${THEME.red};
  @media (max-width: ${DEVICE.medium}px) {
    ${font12}
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font14}
  }
`;

export const QuestionsWrapper = styled.div`
  padding-top: 60px;
  @media (max-width: ${DEVICE.medium}px) {
    padding-bottom: 60px;
    padding-top: 0px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    padding-bottom: 60px;
    padding-top: 0px;
  }
`;
