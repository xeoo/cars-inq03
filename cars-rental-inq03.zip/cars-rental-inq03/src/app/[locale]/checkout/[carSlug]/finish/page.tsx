import Finish from './Finish'
import {Metadata} from "next";
import {SlugType} from "@/type/type";

export const metadata: Metadata = {
  title: 'Booking Confirmation - ProDrive Nürburg Booking',
  description: 'Your ProDrive Nürburg car rental booking is confirmed. Get ready for an unforgettable experience.'
}

export default function FinishPage({ params }: SlugType){
  return <Finish params={params}/>;
}
