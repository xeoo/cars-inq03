import Checkout from './Checkout'
import {Metadata} from "next";

export const metadata: Metadata = {
  title: 'ProDrive - Car Rental Nürburgring',
  description: '' // TODO add title and description
}

export default function CheckoutPage(){
  return <Checkout />;
}
