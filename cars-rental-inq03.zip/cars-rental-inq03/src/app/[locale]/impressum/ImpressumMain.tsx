"use client"

import React from 'react';
import Impressum from "./Impressum";

const ImressumMain = () => {
    return (
        <div>
            <Impressum />
        </div>
    );
};

export default ImressumMain;
