import { StyledImpressum, InfoWrapper, Text } from "./StyledImpressum";

const Impressum = () => {
    const content = `
    <h1>Impressum</h1>
    <div>
  <p>ProDrive Nürburg GmbH</p>
  <p>Auf der Korst 5</p>
  <p>53539 Kelberg</p>
  <p>Germany</p>

  <p>Telefon: +49 15118997222</p>
  <p>Email: privacy@prodrivenurburg.de></a></p>
  <br>
  <p>Registernummer: HRB 46863</p>
  <p>Registergericht: Amtsgericht Andernach</p>
  <br>
  <p>Geschäftsführer: Petras Rimas</p>
    </div>

    `;

    return (
        <StyledImpressum>
            <InfoWrapper>
                <Text>
                    <div dangerouslySetInnerHTML={{__html: content}}/>
                </Text>
            </InfoWrapper>

        </StyledImpressum>
    );
};

export default Impressum;
