import ImpressumMain from './ImpressumMain'
import {Metadata} from "next";

export const metadata: Metadata = {
    title: '',
    description: '' // TODO add title and description
}

export default function ImpressumPage(){
    return <ImpressumMain />;
}
