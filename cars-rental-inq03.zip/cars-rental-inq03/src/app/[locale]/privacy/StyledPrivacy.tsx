import { DEVICE } from "@/utils/device";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import { font14, font16, font20 } from "@/utils/fonts";

export const StyledPrivacy = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 100px;
 
  text-align: left;

  a {
    color: ${THEME.grey};
    text-decoration: none;
    padding: 0 10px;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;
export const InfoWrapper = styled.div`
  flex: 0.7;
  padding: 30px;
  gap: 30px;
  border-radius: 12px 12px 12px 12px;
  border-width: 1px 1px 1px 1px;
  border-style: solid;
  border-color: ${THEME.grey100};
`;


export const Text = styled.div`
  width: 950px;
  text-align: left;
  padding-top: 30px;
  padding-bottom: 30px;
  ${font16}
  color: ${THEME.grey};
  
  @media (max-width: ${DEVICE.large}px) {
    ${font20};
    width: 80%;
    padding-bottom: 40px;
    padding-top: 40px;
  }
  
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
    width: 90%;
    padding-bottom: 30px;
    padding-top: 30px;
  }
  
  @media (max-width: ${DEVICE.small}px) {
    ${font14};
    width: 90%;
    padding-bottom: 30px;
    padding-top: 30px;
  }
`;
