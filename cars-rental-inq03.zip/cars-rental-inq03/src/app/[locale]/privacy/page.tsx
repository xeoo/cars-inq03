import PrivacyPolicyMain from './PrivacyPolicyMain'
import {Metadata} from "next";

export const metadata: Metadata = {
    title: '',
    description: '' // TODO add title and description
}

export default function PrivacyPolicyPage(){
    return <PrivacyPolicyMain />;
}
