"use client"

import React from 'react';
import PrivacyPolicy from './PrivacyPolicy';

const Page = () => {
    return (
        <div>
            <PrivacyPolicy />
        </div>
    );
};

export default Page;
