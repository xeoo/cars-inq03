import { StyledPrivacy, InfoWrapper, Text } from "./StyledPrivacy";

const PrivacyPolicy = () => {
    const content = `
    <div>
      <a href="#german">German</a> | <a href="#english">English</a>
    </div>
    <br>
    <div id="german">
    <h1>Datenschutzerklärung der ProDrive Nurburg GmbH</h1>
    <p>Letzte Aktualisierung: 16. April 2024</p>
    <p>Diese Datenschutzerklärung beschreibt, wie die ProDrive Nurburg GmbH (die "Website", "wir", "uns" oder "unser") Ihre persönlichen Daten sammelt, verwendet und offenlegt, wenn Sie unsere Dienstleistungen nutzen oder einen Kauf auf prodrivenurburg.de (die "Website") tätigen oder anderweitig mit uns kommunizieren (zusammen die "Dienstleistungen"). Für Zwecke dieser Datenschutzerklärung bedeuten "Sie" und "Ihr" Sie als Nutzer der Dienstleistungen, unabhängig davon, ob Sie ein Kunde, ein Besucher der Website oder eine andere Person sind, deren Informationen wir gemäß dieser Datenschutzerklärung gesammelt haben. Bitte lesen Sie diese Datenschutzerklärung sorgfältig durch. Durch die Nutzung und den Zugang zu den Dienstleistungen stimmen Sie der Sammlung, Nutzung und Offenlegung Ihrer Informationen wie in dieser Datenschutzerklärung beschrieben zu. Wenn Sie dieser Datenschutzerklärung nicht zustimmen, nutzen oder greifen Sie bitte nicht auf die Dienstleistungen zu.</p>
    <h2>Änderungen dieser Datenschutzerklärung</h2>
    <p>Wir können diese Datenschutzerklärung von Zeit zu Zeit aktualisieren, um Änderungen unserer Praktiken oder aus anderen betrieblichen, rechtlichen oder regulatorischen Gründen widerzuspiegeln. Wir werden die überarbeitete Datenschutzerklärung auf der Website veröffentlichen, das Datum der "Letzten Aktualisierung" aktualisieren und alle weiteren gesetzlich vorgeschriebenen Schritte unternehmen.</p>
    <h2>Wie wir Ihre persönlichen Daten sammeln und verwenden</h2>
    <p>Um die Dienstleistungen bereitzustellen, sammeln wir persönliche Daten über Sie aus verschiedenen Quellen, wie unten aufgeführt. Die Informationen, die wir sammeln und verwenden, variieren je nachdem, wie Sie mit uns interagieren. Neben den unten aufgeführten spezifischen Verwendungen können wir Informationen, die wir über Sie sammeln, verwenden, um mit Ihnen zu kommunizieren, die Dienstleistungen bereitzustellen, gesetzliche Verpflichtungen zu erfüllen, geltende Nutzungsbedingungen durchzusetzen und die Dienstleistungen, unsere Rechte und die Rechte unserer Nutzer oder anderer zu schützen oder zu verteidigen.</p>
    <h2>Welche persönlichen Daten wir sammeln</h2>
    <p>Die Arten von persönlichen Daten, die wir über Sie sammeln, hängen davon ab, wie Sie mit unserer Website interagieren und unsere Dienstleistungen nutzen. Wenn wir den Begriff "persönliche Daten" verwenden, beziehen wir uns auf Informationen, die Sie identifizieren, sich auf Sie beziehen, Sie beschreiben oder mit Ihnen in Verbindung gebracht werden können. Die folgenden Abschnitte beschreiben die Kategorien und spezifischen Arten von persönlichen Daten, die wir sammeln.</p>
    <p>Informationen, die wir direkt von Ihnen sammeln</p>
    <p>Informationen, die Sie uns direkt über unsere Dienstleistungen übermitteln, können Folgendes umfassen:</p>
    <ul>
      <li>Grundlegende Kontaktdaten wie Ihr Name, Ihre Adresse, Telefonnummer, E-Mail-Adresse.</li>
      <li>Bestellinformationen wie Ihr Name, Rechnungsadresse, Lieferadresse, Zahlungsbestätigung, E-Mail-Adresse, Telefonnummer.</li>
      <li>Einkaufsinformationen wie die Artikel, die Sie ansehen, in Ihren Warenkorb legen oder auf Ihre Wunschliste setzen.</li>
      <li>Kundensupport-Informationen wie die Informationen, die Sie in Kommunikationsmitteilungen mit uns einschließen, zum Beispiel, wenn Sie eine Nachricht über die Dienstleistungen senden.</li>
    </ul>
    <p>Einige Funktionen der Dienstleistungen erfordern möglicherweise, dass Sie uns bestimmte Informationen über sich direkt zur Verfügung stellen. Sie können sich dafür entscheiden, diese Informationen nicht zu übermitteln, aber dies kann dazu führen, dass Sie diese Funktionen nicht nutzen oder darauf zugreifen können.</p>
    <p>Informationen, die wir durch Cookies sammeln</p>
    <p>Wir sammeln auch automatisch bestimmte Informationen über Ihre Interaktion mit den Dienstleistungen ("Nutzungsdaten"). Dazu können wir Cookies, Pixel und ähnliche Technologien ("Cookies") verwenden. Nutzungsdaten können Informationen darüber umfassen, wie Sie auf unsere Website und Ihr Konto zugreifen und diese nutzen, einschließlich Geräteinformationen, Browserinformationen, Informationen über Ihre Netzwerkverbindung, Ihre IP-Adresse und andere Informationen über Ihre Interaktion mit den Dienstleistungen.</p>
    <p>Informationen, die wir von Dritten erhalten</p>
    <p>Schließlich können wir Informationen über Sie von Dritten erhalten, einschließlich von Anbietern und Dienstleistern, die möglicherweise Informationen in unserem Auftrag sammeln, wie zum Beispiel:</p>
    <ul>
      <li>Unternehmen, die unsere Website und Dienstleistungen unterstützen, wie Shopify.</li>
      <li>Unsere Zahlungsabwickler, die Zahlungsinformationen (z. B. Bankkonto, Kredit- oder Debitkartendaten, Rechnungsadresse) sammeln, um Ihre Zahlung zu verarbeiten, um Ihre Bestellungen zu erfüllen und Ihnen die von Ihnen angeforderten Produkte oder Dienstleistungen bereitzustellen, um unseren Vertrag mit Ihnen zu erfüllen.</li>
      <li>Wenn Sie unsere Website besuchen, E-Mails, die wir Ihnen senden, öffnen oder anklicken oder mit unserem Dienst interagieren, können wir oder Dritte, mit denen wir zusammenarbeiten, automatisch bestimmte Informationen mithilfe von Online-Tracking-Technologien wie Pixeln, Web-Beacons, Softwareentwickler-Kits, Drittanbieter-Bibliotheken und Cookies sammeln.</li>
    </ul>
    <p>Alle Informationen, die wir von Dritten erhalten, werden gemäß dieser Datenschutzerklärung behandelt. Wir sind nicht verantwortlich oder haftbar für die Genauigkeit der Informationen, die uns von Dritten zur Verfügung gestellt werden, und sind nicht verantwortlich für die Richtlinien oder Praktiken von Dritten.</p>
    <p>Bitte beachten Sie, dass die Anwendung Drittanbieterdienste nutzt, die ihre eigene Datenschutzerklärung über den Umgang mit Daten haben. Nachfolgend finden Sie die Links zur Datenschutzerklärung der von der Dienstleistung genutzten Drittanbieterdienste:</p>
    <ul>
      <li><a href="https://support.google.com/analytics/answer/7318509">Google Analytics</a></li>
      <li><a href="https://stripe.com/privacy">Stripe</a></li>
      <li><a href="https://www.shopify.com/legal/privacy">Shopify</a></li>
    </ul>
    <h2>Wie wir Ihre persönlichen Daten verwenden</h2>
    <p>Bereitstellung von Produkten und Dienstleistungen. Wir verwenden Ihre persönlichen Daten, um Ihnen die Dienstleistungen bereitzustellen, um unseren Vertrag mit Ihnen zu erfüllen, einschließlich der Bearbeitung Ihrer Zahlungen, der Erfüllung Ihrer Bestellungen, der Zusendung von Benachrichtigungen an Sie in Bezug auf Ihr Konto, Käufe, Rücksendungen, Umtausch oder andere Transaktionen, der Erstellung, Pflege und sonstigen Verwaltung Ihres Kontos, der Organisation des Versands, der Erleichterung von Rücksendungen und Umtausch und der Ermöglichung, Bewertungen zu posten.</p>
    <p>Marketing und Werbung. Wir verwenden Ihre persönlichen Daten für Marketing- und Werbezwecke, wie zum Beispiel das Versenden von Marketing-, Werbe- und Promotion-Kommunikationen per E-Mail, SMS oder Post und das Anzeigen von Werbung für Produkte oder Dienstleistungen. Dies kann die Verwendung Ihrer persönlichen Daten umfassen, um die Dienstleistungen und Werbung auf unserer Website und anderen Websites besser auf Sie zuzuschneiden.</p>
    <p>Sicherheit und Betrugsprävention. Wir verwenden Ihre persönlichen Daten, um mögliche betrügerische, illegale oder bösartige Aktivitäten zu erkennen, zu untersuchen oder Maßnahmen zu ergreifen. Wenn Sie sich entscheiden, die Dienstleistungen zu nutzen und ein Konto zu registrieren, sind Sie verantwortlich für die Sicherheit Ihrer Kontodaten. Wir empfehlen dringend, Ihre Benutzername, Passwort oder andere Zugangsdaten nicht mit anderen zu teilen. Wenn Sie glauben, dass Ihr Konto kompromittiert wurde, kontaktieren Sie uns bitte umgehend.</p>
    <p>Kommunikation mit Ihnen. Wir verwenden Ihre persönlichen Daten, um Ihnen Kundensupport zu bieten und unsere Dienstleistungen zu verbessern. Dies liegt in unserem berechtigten Interesse, um auf Sie zu reagieren, Ihnen effektive Dienstleistungen zu bieten und unsere Geschäftsbeziehung mit Ihnen aufrechtzuerhalten.</p>
    <h2>Cookies</h2>
    <p>Wir verwenden Cookies, um unsere Website und unsere Dienstleistungen zu betreiben und zu verbessern (einschließlich zur Speicherung Ihrer Handlungen und Präferenzen), um Analysen durchzuführen und die Benutzerinteraktion mit den Dienstleistungen besser zu verstehen (in unserem berechtigten Interesse, die Dienstleistungen zu verwalten, zu verbessern und zu optimieren). Wir können auch Dritten und Dienstleistern gestatten, Cookies auf unserer Website zu verwenden, um die Dienstleistungen, Produkte und Werbung auf unserer Website und anderen Websites besser auf Sie zuzuschneiden.</p>
    <p>Die meisten Browser akzeptieren Cookies standardmäßig automatisch, aber Sie können Ihren Browser so einstellen, dass Cookies entfernt oder abgelehnt werden. Bitte beachten Sie, dass das Entfernen oder Blockieren von Cookies Ihre Benutzererfahrung negativ beeinflussen und dazu führen kann, dass einige der Dienstleistungen, einschließlich bestimmter Funktionen und allgemeiner Funktionalität, nicht mehr korrekt funktionieren oder nicht mehr verfügbar sind.</p>
    <h2>Wie wir Ihre persönlichen Daten weitergeben</h2>
    <p>Wir können Ihre Daten an Drittanbieter, Dienstleister, Auftragnehmer oder Agenten ("Dritte") weitergeben, die Dienstleistungen für uns oder in unserem Auftrag erbringen und Zugang zu solchen Informationen benötigen, um diese Arbeiten auszuführen.</p>
    <p>Die Kategorien von Dritten, mit denen wir persönliche Daten teilen können, sind wie folgt:</p>
    <ul>
      <li>Shopify</li>
      <li>Datenanalysedienste</li>
    </ul>
    <p>Wenn wir Google Analytics verwenden. Wir können Ihre Informationen mit Google Analytics teilen, um die Nutzung der Dienstleistungen zu verfolgen und zu analysieren. Die Google Analytics-Werbefunktionen, die wir möglicherweise verwenden, umfassen: Remarketing mit Google Analytics. Um sich davon abzumelden, von Google Analytics über die Dienstleistungen verfolgt zu werden, besuchen Sie https://tools.google.com/dlpage/gaoptout. Sie können die Google Analytics-Werbefunktionen über die Einstellungen für Anzeigen und die Einstellungen für mobile Apps deaktivieren. Weitere Abmeldeoptionen sind http://optout.networkadvertising.org/ und http://www.networkadvertising.org/mobile-choice. Weitere Informationen zu den Datenschutzpraktiken von Google finden Sie auf der Seite Google Datenschutz & Nutzungsbedingungen.</p>
    <h2>Wie lange bewahren wir Ihre Informationen auf</h2>
    <p>Wir bewahren Ihre persönlichen Daten nur so lange auf, wie es für die in dieser Datenschutzerklärung beschriebenen Zwecke erforderlich ist, es sei denn, gesetzliche Bestimmungen verlangen oder erlauben eine längere Aufbewahrungsfrist aufgrund von Steuer-, Buchhaltungs- oder anderen rechtlichen Gründen.</p>
    <p>Wenn es keinen legitimen Geschäftszweck mehr gibt, um Ihre persönlichen Daten zu verarbeiten, werden wir sie entweder löschen oder anonymisieren. Wenn eine Löschung oder Anonymisierung nicht möglich ist (z. B. weil Ihre Daten in Sicherungsarchiven gespeichert sind), werden wir Ihre Informationen sicher aufbewahren und jede weitere Verarbeitung verhindern, bis eine Löschung möglich ist.</p>
    <h2>Ihre Datenschutzrechte</h2>
    <p>In bestimmten Bereichen wie dem EWR, dem Vereinigten Königreich und der Schweiz gewähren Ihnen die geltenden Datenschutzgesetze spezifische Rechte. Diese Rechte können Folgendes umfassen: (i) das Recht, Zugang zu Ihren persönlichen Daten zu erhalten und eine Kopie davon zu erhalten, (ii) die Möglichkeit, Ihre persönlichen Daten zu korrigieren oder zu löschen; (iii) das Recht, die Verarbeitung Ihrer persönlichen Daten zu beschränken; (iv) die Möglichkeit, Ihre Daten zu übertragen, falls zutreffend; und (v) das Recht, nicht ausschließlich automatisierten Entscheidungen unterworfen zu werden. Unter bestimmten Umständen haben Sie möglicherweise auch das Recht, der Verarbeitung Ihrer persönlichen Daten zu widersprechen. Sie können diese Rechte ausüben, indem Sie uns per E-Mail kontaktieren.</p>
    <p>Wir werden auf jede Anfrage antworten und diese gemäß den geltenden Datenschutzgesetzen bearbeiten.</p>
    <p>Wenn Sie Ihre Einwilligung zur Verarbeitung Ihrer persönlichen Daten widerrufen möchten, können Sie dies jederzeit tun. Widerrufen Sie einfach Ihre Einwilligung, indem Sie uns über die angegebene E-Mail-Adresse kontaktieren.</p>
    <p>In Bezug auf Cookies und ähnliche Technologien: Die meisten Internetbrowser akzeptieren Cookies standardmäßig. Sie können Ihre Browsereinstellungen jedoch in der Regel so ändern, dass Cookies gelöscht oder blockiert werden. Wenn Sie sich entscheiden, Cookies zu entfernen oder abzulehnen, kann dies die Funktionalität bestimmter Aspekte unserer Dienstleistungen beeinträchtigen. Weitere Einzelheiten finden Sie in unserer Cookie-Hinweis auf cookies.com.</p>
    <h2>Kontaktieren Sie uns</h2>
    <p>Wenn Sie Fragen zum Datenschutz bei der Nutzung des Dienstes haben oder Fragen zu den Praktiken haben, wenden Sie sich bitte per E-Mail an den Dienstanbieter unter privacy@prodrivenurburg.de</p>
 
 
 
    <br><br><br>
    <div id="english">
    <h2>ProDrive Nürburg GmbH Privacy Policy</h2>
    <p>Last updated: 16 Apr 2024</p>
    <p>This Privacy Policy describes how ProDrive Nürburg GmbH (the "Site", "we", "us", or "our") collects, uses, and discloses your personal information when you visit, use our services, or make a purchase from prodrivenurburg.de (the "Site") or otherwise communicate with us (collectively, the "Services"). For purposes of this Privacy Policy, "you" and "your" means you as the user of the Services, whether you are a customer, website visitor, or another individual whose information we have collected pursuant to this Privacy Policy. Please read this Privacy Policy carefully. By using and accessing any of the Services, you agree to the collection, use, and disclosure of your information as described in this Privacy Policy. If you do not agree to this Privacy Policy, please do not use or access any of the Services.</p>
    <h2>Changes to This Privacy Policy</h2>
    <p>We may update this Privacy Policy from time to time, including to reflect changes to our practices or for other operational, legal, or regulatory reasons. We will post the revised Privacy Policy on the Site, update the "Last updated" date and take any other steps required by applicable law.</p>
    <h2>How We Collect and Use Your Personal Information</h2>
    <p>To provide the Services, we collect personal information about you from a variety of sources, as set out below. The information that we collect and use varies depending on how you interact with us. In addition to the specific uses set out below, we may use information we collect about you to communicate with you, provide the Services, comply with any applicable legal obligations, enforce any applicable terms of service, and to protect or defend the Services, our rights, and the rights of our users or others.</p>
    <h2>What Personal Information We Collect</h2>
    <p>The types of personal information we obtain about you depends on how you interact with our Site and use our Services. When we use the term "personal information", we are referring to information that identifies, relates to, describes or can be associated with you. The following sections describe the categories and specific types of personal information we collect.</p>
    <p>Information We Collect Directly from You</p>
    <p>Information that you directly submit to us through our Services may include:</p>
    <ul>
      <li>Basic contact details including your name, address, phone number, email.</li>
      <li>Order information including your name, billing address, shipping address, payment confirmation, email address, phone number.</li>
      <li>Shopping information including the items you view, put in your cart or add to your wishlist.</li>
      <li>Customer support information including the information you choose to include in communications with us, for example, when sending a message through the Services.</li>
    </ul>
    <p>Some features of the Services may require you to directly provide us with certain information about yourself. You may elect not to provide this information, but doing so may prevent you from using or accessing these features.</p>
    <p>Information We Collect through Cookies</p>
    <p>We also automatically collect certain information about your interaction with the Services ("Usage Data"). To do this, we may use cookies, pixels and similar technologies ("Cookies"). Usage Data may include information about how you access and use our Site and your account, including device information, browser information, information about your network connection, your IP address, and other information regarding your interaction with the Services.</p>
    <p>Information We Obtain from Third Parties</p>
    <p>Finally, we may obtain information about you from third parties, including from vendors and service providers who may collect information on our behalf, such as:</p>
    <ul>
      <li>Companies who support our Site and Services, such as Shopify.</li>
      <li>Our payment processors, who collect payment information (e.g., bank account, credit or debit card information, billing address) to process your payment in order to fulfill your orders and provide you with products or services you have requested, in order to perform our contract with you.</li>
      <li>When you visit our Site, open or click on emails we send you, or interact with our Service we, or third parties we work with, may automatically collect certain information using online tracking technologies such as pixels, web beacons, software developer kits, third-party libraries, and cookies.</li>
    </ul>
    <p>Any information we obtain from third parties will be treated in accordance with this Privacy Policy. We are not responsible or liable for the accuracy of the information provided to us by third parties and are not responsible for any third party's policies or practices.</p>
    <p>Please note that the Application utilizes third-party services that have their own Privacy Policy about handling data. Below are the links to the Privacy Policy of the third-party service providers used by the Service:</p>
    <ul>
      <li><a href="https://support.google.com/analytics/answer/7318509">Google Analytics</a></li>
      <li><a href="https://stripe.com/privacy">Stripe</a></li>
    </ul>
    <h2>How We Use Your Personal Information</h2>
    <p>Providing Products and Services. We use your personal information to provide you with the Services in order to perform our contract with you, including to process your payments, fulfill your orders, to send notifications to you related to you account, purchases, returns, exchanges or other transactions, to create, maintain and otherwise manage your account, to arrange for shipping, facilitate any returns and exchanges and to enable you to post reviews.</p>
    <p>Marketing and Advertising. We use your personal information for marketing and promotional purposes, such as to send marketing, advertising and promotional communications by email, text message or postal mail, and to show you advertisements for products or services. This may include using your personal information to better tailor the Services and advertising on our Site and other websites.</p>
    <p>Security and Fraud Prevention. We use your personal information to detect, investigate or take action regarding possible fraudulent, illegal or malicious activity. If you choose to use the Services and register an account, you are responsible for keeping your account credentials safe. We highly recommend that you do not share your username, password, or other access details with anyone else. If you believe your account has been compromised, please contact us immediately.</p>
    <p>Communicating with you. We use your personal information to provide you with customer support and improve our Services. This is in our legitimate interests in order to be responsive to you, to provide effective services to you, and to maintain our business relationship with you.</p>
    <h2>Cookies</h2>
    <p>We use Cookies to power and improve our Site and our Services (including to remember your actions and preferences), to run analytics and better understand user interaction with the Services (in our legitimate interests to administer, improve and optimize the Services). We may also permit third parties and services providers to use Cookies on our Site to better tailor the services, products and advertising on our Site and other websites.</p>
    <p>Most browsers automatically accept Cookies by default, but you can choose to set your browser to remove or reject Cookies through your browser controls. Please keep in mind that removing or blocking Cookies can negatively impact your user experience and may cause some of the Services, including certain features and general functionality, to work incorrectly or no longer be available.</p>
    <h2>How we share your personal information</h2>
    <p>We may share your data with third-party vendors, service providers, contractors, or agents ('third parties') who perform services for us or on our behalf and require access to such information to do that work.</p>
    <p>The categories of third parties we may share personal information with are as follows:</p>
    <ul>
      <li>Data Analytics Services</li>
    </ul>
    <p>When we use Google Analytics. We may share your information with Google Analytics to track and analyse the use of the Services. The Google Analytics Advertising Features that we may use include: Remarketing with Google Analytics. To opt out of being tracked by Google Analytics across the Services, visit https://tools.google.com/dlpage/gaoptout. You can opt out of Google Analytics Advertising Features through Ads Settings and Ad Settings for mobile apps. Other opt out means include http://optout.networkadvertising.org/ and http://www.networkadvertising.org/mobile-choice. For more information on the privacy practices of Google, please visit the Google Privacy & Terms page.</p>
    <h2>How long do we keep your information</h2>
    <p>We retain your personal data only as long as needed for the objectives outlined in this privacy notice, unless laws mandate or allow for a longer storage duration due to tax, accounting, or other legal reasons.</p>
    <p>If there is no longer a legitimate business reason to process your personal information, we will either delete or anonymize it. If deletion or anonymization is not feasible (e.g., because your data is preserved in backup archives), we will securely safeguard your information and prevent any further processing until deletion can be accomplished.</p>
    <h2>Your privacy rights</h2>
    <p>In certain areas such as the EEA, UK, and Switzerland, applicable data protection laws provide you with specific rights. These rights might include (i) the ability to access and obtain a copy of your personal information, (ii) the option to correct or delete your personal information; (iii) the right to limit how your personal information is processed; (iv) the possibility of transferring your data, if relevant; and (v) the right to not be subject to decisions made solely by automated processes. Under certain conditions, you might also have the right to object to the processing of your personal data. You can exercise these rights by contacting us via email.</p>
    <p>We will respond to and process every request following the relevant data protection legislation.</p>
    <p>If you wish to retract your consent for us to process your personal information, you can do so at any time. Simply withdraw your consent by reaching out to us through the specified email.</p>
    <p>Regarding cookies and similar technologies: Most internet browsers accept cookies by default. However, you can typically modify your browser settings to delete or block cookies if you choose. Opting to remove or reject cookies may impact the functionality of certain aspects of our Services. For more details, please refer to our Cookie Notice at cookies.com.</p>
    <h2>Contact Us</h2>
    <p>If you have any questions regarding privacy while using the Service, or have questions about the practices, please contact the Service Provider via email at privacy@prodrivenurburg.de</p>
  `;

    return (
        <StyledPrivacy>
            <InfoWrapper>
                <Text><div dangerouslySetInnerHTML={{ __html: content }} /></Text>
            </InfoWrapper>

        </StyledPrivacy>
    );
};

export default PrivacyPolicy;
