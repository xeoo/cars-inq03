"use client";
import { StyledClear } from "./StyledTerms";

export default function Terms() {
    return <StyledClear></StyledClear>;
}
