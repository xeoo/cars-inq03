"use client";

import { StyledSafetyRules } from "./StyledSafetyRules";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

export default function Catalog() {
    const { t } = useTranslation();
    return <StyledSafetyRules>{t("Safety & Rules")}</StyledSafetyRules>;
}
