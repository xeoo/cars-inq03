import styled from "styled-components";

export const StyledSafetyRules = styled.div`
  height: 500px;
  width: 1920px;
  display: flex;
  align-items: center;
  justify-content: center;
`;
