import Catalog from './catalog'
import {Metadata} from "next";

export const metadata: Metadata = {
  title: 'Our Cars - ProDrive Nürburg Car Rental',
  description: 'Browse our cars available for rental at Nürburgring. Choose your perfect car and enjoy your drive.'
}

export default function CatalogPage(){
  return <Catalog />;
}
