'use client';

import MainPage from "../../components/MainPage/MainPage";

export default function Home() {
  return <MainPage />;
}
