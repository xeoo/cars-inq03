'use client';

import { LoadingProvider } from "@/context/LoadingContext";
import Loader from "./Loader";
import { CarsProvider } from "@/context/CarsContext";
import { CarProvider } from "@/context/CarContext";
import { OrderProvider } from "@/context/OrderContext";
import Header from "@/components/MainHeader/MainHeader";
import Footer from "@/components/MainFooter/MainFooter";
import { LanguageProvider } from "@/context/LanguageContext";

export default function MainLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <LoadingProvider>
      <CarsProvider>
        <CarProvider>
          <OrderProvider>
            <LanguageProvider>
              <Loader />
              <div className="app-wrapper">
                <Header />
                <main className="content-wrapper">{children}</main>
                <Footer />
              </div>
            </LanguageProvider>
          </OrderProvider>
        </CarProvider>
      </CarsProvider>
    </LoadingProvider>
  )
}