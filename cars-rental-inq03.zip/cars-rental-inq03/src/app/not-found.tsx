"use client";

import { StyledError } from "./StyledShared";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

export default function NotFind() {
  const { t } = useTranslation();

  return <StyledError>{t("Please try again later.")}</StyledError>;
}
