import { usePathname } from "next/navigation";
import {
  DivFlex,
  HeaderWrapper,
  LogoWrapper,
  MenuMobileWrapper,
  NavigationItem,
  NavigationItemPointer,
  NavigationMobile,
  SmallDevice,
  StyledMainHeader,
  MediaButtonWrapper,
  SelectWrapper,
  MenuWrapper,
  MenuImageWrapper,
  HeaderContainer,
} from "./StyledMainHeader";
import { routes } from "@/constants/routes";
import StyledSelect from "@/components/Language/Language";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

import { useState } from "react";
import { IconWrapper } from "../MainFooter/StyledMainFooter";
import ButtonIcon from "../UI/ButtonIcon/ButtonIcon";
import { THEME } from "@/utils/theme";

export default function Header() {
  const pathname = usePathname();
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);

  const navigationRoutes = routes.mainRoutes;

  const handeleOpenMenu = () => {
    setOpen((prev) => !prev);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <HeaderContainer>
      <SmallDevice $open={open}>
        <NavigationItemPointer
          key={routes.mainPage.id}
          href={routes.mainPage.path}
        >
          <LogoWrapper
            src="/icon/headerLogo.svg"
            alt="Logo"
            width={145}
            height={30}
            priority
          />
        </NavigationItemPointer>
        <MenuWrapper>
          {!open && (
            <StyledSelect background={THEME.dark} isMobileDevice={true} />
          )}
          <MenuImageWrapper
            src={open ? "/icon/menuClose.svg" : "/icon/menu.svg"}
            alt="menu"
            width={24}
            height={24}
            priority
            onClick={handeleOpenMenu}
            suppressHydrationWarning
          />
        </MenuWrapper>
      </SmallDevice>
      {open && (
        <MenuMobileWrapper>
          <NavigationMobile>
            {navigationRoutes.map((route) => (
              <NavigationItem
                suppressHydrationWarning
                onClick={handleClose}
                key={route.id}
                href={
                  route.path === routes.mainRoutes[1].path
                    ? `${routes.mainRoutes[1].path}`
                    : route.path
                }
                className={
                  pathname && pathname.startsWith(route.path)
                    ? "active"
                    : undefined
                }
              >
                {t(route.name)}
              </NavigationItem>
            ))}
          </NavigationMobile>
          <SelectWrapper>
            <StyledSelect background={THEME.dark} />
          </SelectWrapper>
          <MediaButtonWrapper>
            <IconWrapper>
              {routes.mediaRoutes.map((route) => (
                <a key={route.id} href={route.path} target="_blank">
                  <ButtonIcon icon={<route.icon />} />
                </a>
              ))}
            </IconWrapper>
          </MediaButtonWrapper>
        </MenuMobileWrapper>
      )}

      <StyledMainHeader>
        <HeaderWrapper>
          <DivFlex>
            <NavigationItemPointer
              key={routes.mainPage.id}
              href={routes.mainPage.path}
            >
              <LogoWrapper
                src="/icon/headerLogo.svg"
                alt="Logo"
                width={145}
                height={30}
                priority
                suppressHydrationWarning
              />
            </NavigationItemPointer>
            <nav>
              {navigationRoutes.map((route) => (
                <NavigationItem
                  key={route.id}
                  href={
                    route.path === routes.mainRoutes[1].path
                      ? `${routes.mainRoutes[1].path}`
                      : route.path
                  }
                  className={
                    pathname && pathname.startsWith(route.path)
                      ? "active"
                      : undefined
                  }
                >
                  {t(route.name)}
                </NavigationItem>
              ))}
            </nav>
          </DivFlex>
          <StyledSelect />
        </HeaderWrapper>
      </StyledMainHeader>
    </HeaderContainer>
  );
}
