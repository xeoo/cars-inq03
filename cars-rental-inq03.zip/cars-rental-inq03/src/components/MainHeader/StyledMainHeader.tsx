import styled from "styled-components";
import { font16, font14 } from "../../utils/fonts";
import { THEME } from "@/utils/theme";
import Image from "next/image";
import Link from "next/link";
import { DEVICE } from "@/utils/device";

export const StyledMainHeader = styled.header`
  position: relative;
  z-index: 10;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  @media (min-width: ${DEVICE.medium}px) {
    width: ${DEVICE.medium}px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
  }
`;

export const HeaderWrapper = styled.div`
  display: flex;
  height: 100px;
  justify-content: space-between;
  align-items: center;
`;

export const NavigationItem = styled(Link)`
  ${font14}

  padding-right: 45px;
  text-decoration: none;
  cursor: pointer;
  &:hover {
    color: ${THEME.red};
  }
  @container (max-width: ${DEVICE.medium}px) {
    padding: 30px 0px;
    border-bottom: 1px solid ${THEME.grey100};
    width: 100%;
    text-align: center;
  }

  @container (min-width: ${DEVICE.large}px) {
    padding-right: 60px;
    ${font16}
  }

  color: ${THEME.grey};

  &.active {
    color: ${THEME.white};
  }
`;

export const NavigationItemPointer = styled(Link)`
  cursor: pointer;
`;

export const LogoWrapper = styled(Image)`
  padding-right: 75px;
`;

export const DivFlex = styled.div`
  display: flex;
`;

export const SmallDevice = styled.div<{ $open?: boolean }>`
  position: relative;
  display: flex;
  height: 76px;
  padding: 0 24px 0 24px;
  align-items: center;
  justify-content: space-between;
  z-index: 10;
  background: ${(props) => (props.$open ? THEME.dark : "transparent ")};
`;

export const MenuMobileWrapper = styled.div`
  width: 100%;
  height: 527px;
  background: ${THEME.dark};
  position: absolute;
  z-index: 10;
`;

export const NavigationMobile = styled.nav`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid ${THEME.grey100};
`;

export const SelectWrapper = styled.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin: 40px 0px;
`;

export const MediaButtonWrapper = styled.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin-bottom: 40px;
`;

export const MenuWrapper = styled.div`
  display: flex;
`;

export const MenuImageWrapper = styled(Image)`
  margin-left: 24px;
`;

export const HeaderContainer = styled.div`
  container-type: inline-size;
  z-index: 2;

  @container (min-width: ${DEVICE.medium}px) {
    ${SmallDevice},${MenuMobileWrapper} {
      display: none;
    }
  }

  @container (max-width: ${DEVICE.medium}px) {
    ${StyledMainHeader} {
      display: none;
    }
  }
`;
