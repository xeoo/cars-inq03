"use client";

import styled from "styled-components";
import { font16 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import { DEVICE } from "@/utils/device";

export const StyledBooking = styled.div`
  margin: 0 auto;
  display: flex;
  justify-content: center;
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
    flex-direction: column;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
    flex-direction: column;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
    border: 1px solid ${THEME.grey100};
    border-radius: 12px;
  }
`;

export const StyledTable = styled.table`
  color: ${THEME.white};
  ${font16}
  border-collapse: separate;
  border-spacing: 2px;
  td {
    width: 100px;
  }
`;
export const OrderSummaryWrapper = styled.div`
  padding: 30px;
  @media (min-width: ${DEVICE.large}px) {
    border-left: 1px solid ${THEME.grey100};
  }
  @media (max-width: ${DEVICE.medium}px) {
    padding: 0 20px 20px 20px;;
  }
`;

export const ContactOrderFormWrapper = styled.div`
  flex: 1;
  padding: 30px 30px 0 30px;
  @media (max-width: ${DEVICE.medium}px) {
    padding: 20px;
  }
`;
