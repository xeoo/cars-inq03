"use client";
import axios from "axios";
import { useTranslation } from "react-i18next";
import NextStepButton from "../NextStepButton/NextStepButton";
import OrderSummary from "../OrderSummary/OrderSummary";
import {
  ContactOrderFormWrapper,
  OrderSummaryWrapper,
  StyledBooking,
} from "./StyledContactCheckout";
import { useEffect, useRef } from "react";
import { redirect } from "next/navigation";
import { SlugType } from "@/type/type";
import ContactOrderForm from "../ContactOrderForm/ContactOrderForm";
import { useForm } from "react-hook-form";
import {
  OrderSummaryTitle,
  StyledDivider,
} from "../OrderSummary/StyledOrderSummary";
import { useOrder } from "@/context/OrderContext";
import { Contacts } from "@/types/order";
import { useWindowDimensions } from "@/hooks/useWindowDimensions";

export default function ContactCheckout({ params }: SlugType) {
  const { t } = useTranslation();
  const {
    order: { car, totalPrice, addons, contacts },
    setOrder,
  } = useOrder();
  const formRef = useRef<HTMLDivElement>(null);
  const { isSmallScreen } = useWindowDimensions();

  const {
    control,
    trigger,
    setValue,
    getValues,
    formState: { errors, isValid },
  } = useForm();

  useEffect(() => {
    if (!addons && !car && !totalPrice) {
      redirect("/checkout");
    }
  }, []);

  useEffect(() => {
    if (contacts?.email) {
      Object.keys(contacts).forEach((key) => {
        // @ts-ignore
        setValue(key, contacts[key], {
          shouldValidate: true,
          shouldDirty: true,
        });
      });
    }
  }, [contacts]);

  const addDataClient = async () => {
    const contacts = getValues();
    let clientId: number;
    const { data } = await axios.get(`/api/client?email=${contacts.email}`);
    const client = JSON.parse(data);
    if (client.clientId) {
      await axios.put(`/api/client?clientId=${client.clientId}`, contacts);
      clientId = client?.clientId || 0;
    } else {
      const { data } = await axios.post(`/api/client`, contacts);
      const client = JSON.parse(data);
      clientId = client?.clientId || 0;
    }

    setOrder((order) => ({
      ...order,
      contacts: {
        ...contacts,
        clientId,
      } as Contacts,
    }));
  };

  const onSubmit = async () => {
    trigger();
    if (isValid) {
      await addDataClient();
    } else {
      formRef?.current?.scrollIntoView();
    }
    return !isValid;
  };

  return (
    <StyledBooking>
      <ContactOrderFormWrapper>
        <OrderSummaryTitle>Contact Information</OrderSummaryTitle>
        <StyledDivider />
        <ContactOrderForm control={control} errors={errors} formRef={formRef} />
      </ContactOrderFormWrapper>
      <OrderSummaryWrapper>
        {car.checkedTime && !isSmallScreen && (
          <OrderSummary addons={addons} totalPrice={totalPrice} carInfo={car} />
        )}
        <NextStepButton
          params={params}
          step="payment"
          onSubmit={onSubmit}
          title={t("Proceed to Checkout")}
        />
      </OrderSummaryWrapper>
    </StyledBooking>
  );
}
