import { font16_600_28, font16, font14, font28_600_36 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import ArrowRightCheckout from "@/assets/icon/arrowRightCheckoutSlider.svg";
import ArrowLeftCheckout from "@/assets/icon/arrowLeftCheckoutSlider.svg";
import Slider from "react-slick";
import CheckmarkIcon from "@/assets/icon/checked.svg";
import Image from "next/image";
import { DEVICE } from "@/utils/device";

export const StyledSlider = styled(Slider)`
  &.slick-slider {
    position: relative;
    height: 180px;
    @media (max-width: ${DEVICE.medium}px) {
      width: ${DEVICE.small}px;
      position: absolute;
      top: 280px;
    }
    @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
      width: ${DEVICE.medium}px;
      position: absolute;
      top: 280px;
      height: 230px;
    }
    @media (min-width: ${DEVICE.large}px) {
      width: 410px;
    }
    overflow: hidden;
    & > .slick-list {
      & > .slick-track {
        display: flex;
      }
    }
    &.slick-slide {
      height: auto;
    }
  }
`;

export const StyledRightArrowCheckout = styled(ArrowRightCheckout)`
  position: absolute;
  left: 0;
  top: 30%;
  z-index: 4;
`;

export const StyledLeftArrowCheckout = styled(ArrowLeftCheckout)`
  position: absolute;
  right: 0;
  top: 30%;
  z-index: 4;
`;

export const StyledSlideWrapper = styled.div`
  display: flex !important;
  align-items: center;
  flex-direction: column;
`;

export const StyledCarTitle = styled.div`
  ${font16_600_28};
  color: ${THEME.white};
  margin-top: 30px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font28_600_36};
    margin-top: 15px;
    height: 50px;
  }
`;

export const StyledDivider = styled.div`
  height: 1px;
  background-color: ${THEME.white};
  opacity: 0.1;
  @media (max-width: ${DEVICE.medium}px) {
    margin: 0px 0px 20px 0px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    margin: 0px 0px 30px 0px;
  }
  @media (min-width: ${DEVICE.large}px) {
    margin: 0px 0px 30px 0px;
  }
`;

export const StyledInfo = styled.div`
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
    margin-top: 20px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
    display: flex;
    align-items: flex-start;
    border-bottom: 1px solid ${THEME.grey100};
    border-top: 1px solid ${THEME.grey100};
    margin-bottom: 30px;
    margin-top: 30px;
    justify-content: space-between;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: 410px;
  }
`;

export const StyledCheckbox = styled.input`
  appearance: none;
  width: 24px;
  height: 24px;
  border: 1px solid ${THEME.white10opacity};
  background-color: ${THEME.white5opacity};
  border-radius: 4px;
  outline: none;
  margin-right: 10px;
  cursor: pointer;
  &:checked {
    background-color: ${THEME.green15opacity};
    border-color: ${THEME.green35opacity};
  }
`;

export const StyledLapsLabel = styled.div`
  ${font16};
  color: ${THEME.white};
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
  }
`;

export const CheckboxWrapper = styled.div`
  display: flex;
  flex-direction: column;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    margin-top: 30px;
    width: 350px;
  }
`;

export const StyledCheckboxButtonItemWrapper = styled.label`
  display: flex;
  position: relative;
  align-items: center;
  @media (max-width: ${DEVICE.medium}px) {
    margin-bottom: 20px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    margin-bottom: 30px;
  }
  @media (min-width: ${DEVICE.large}px) {
    margin-bottom: 30px;
  }
  cursor: pointer;
`;

export const StyledCheckmarkIcon = styled(CheckmarkIcon)`
  position: absolute;
  transform: translate(63%);
`;

export const ImageWrapper = styled(Image)`
  height: auto;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 311px;
  }
`;

export const VerticalLine = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 1px;
    height: 260px;
    background: ${THEME.grey100};
  }
`;
