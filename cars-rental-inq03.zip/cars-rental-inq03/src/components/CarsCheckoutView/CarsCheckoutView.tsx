"use client";

import { Car } from "@/types/car";
import { useRouter } from "next/navigation";
import {
  StyledLeftArrowCheckout,
  StyledSlideWrapper,
  StyledInfo,
  StyledCheckmarkIcon,
  StyledCheckboxButtonItemWrapper,
  StyledDivider,
  StyledCarTitle,
  StyledRightArrowCheckout,
  StyledSlider,
  CheckboxWrapper,
  StyledCheckbox,
  StyledLapsLabel,
  ImageWrapper,
  VerticalLine,
} from "./StyledCarsCheckoutView";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useOrder } from "@/context/OrderContext";

export default function CarsCheckoutView({
  car,
  cars,
  dateData,
  date,
  activeCarIndex,
}: {
  car: Car;
  cars: Car[];
  activeCarIndex: number;
  dateData: any;
  date: string;
}) {
  const { t } = useTranslation();
  const { setOrder } = useOrder();
  const router = useRouter();
  const [checkedLaps, setCheckedLaps] = useState<number>(
    car.priceOptions[0].laps
  );
  const [checkedTime, setCheckedTime] = useState<string>(dateData.defaultTime);
  const [isPartDay, setIsPartDay] = useState<boolean>(true);
  const [time, setTime] = useState<string>("");

  useEffect(() => {
    setCheckedTime(dateData.defaultTime);
  }, [dateData]);

  useEffect(() => {
    setCheckedLaps(car.priceOptions[0].laps);
    setIsPartDay(true);
  }, [car, dateData]);

  const handleChangeLaps = (event: React.ChangeEvent<HTMLInputElement>) => {
    const laps = event.currentTarget.value;
    const lapsCount = parseInt(laps, 10);
    setCheckedLaps(lapsCount);
    if (lapsCount > 5 && dateData.isFullDayAvailable) {
      setIsPartDay(false);
      setCheckedTime("morning+evening");
    } else {
      checkedTime === "morning+evening" && setCheckedTime(dateData.defaultTime);
      setIsPartDay(true);
    }
  };

  const handleChangeTime = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCheckedTime(event.currentTarget.value);
  };

  const handleChangeCar = (index: number) => {
    router.push(`/checkout/${cars[index].id}/booking`);
  };

  useEffect(() => {
    const { title, priceOptions, image, id } = car;
const time = checkedTime === "morning+evening" ? `${dateData.open_time} - ${dateData.close_time}` : dateData[checkedTime];
    const basePrice = priceOptions.find(({ laps }) => laps === checkedLaps);
    const carDetail = {
      ...car,
      checkedLaps,
      carDetail: title,
      basePrice:
        basePrice && dateData.isFullPrice
          ? basePrice.fullPrice
          : basePrice?.price || "0",
      image: image,
      checkedTime,
      isFullPrice: dateData.isFullPrice,
      time,
      date,
      carId: id,
    };

    setOrder((order) => {
      return { ...order, car: carDetail };
    });
  }, [
    checkedLaps,
    checkedTime,
    car,
    date,
    dateData.open_time,
    dateData.close_time,
    dateData.isFullPrice,
    setOrder,
    dateData.evening,
    dateData.morning,
    time,
  ]);

  const settings = {
    infinite: true,
    speed: 500,
    initialSlide: activeCarIndex,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <StyledLeftArrowCheckout />,
    prevArrow: <StyledRightArrowCheckout />,
    afterChange: handleChangeCar,
  };

  return (
    <StyledInfo>
      <StyledSlider {...settings}>
        {cars.map((car) => (
          <StyledSlideWrapper key={car.id}>
            <ImageWrapper
              src={car.image}
              alt={car.title}
              width={240}
              height={140}
              priority
            />
            <StyledCarTitle>{car.title}</StyledCarTitle>
          </StyledSlideWrapper>
        ))}
      </StyledSlider>
      <StyledDivider />
      <CheckboxWrapper>
        {car.priceOptions.map((option) => {
          if (option.laps > dateData.morningLaps + dateData.eveningLaps)
            return null;
          return (
            <StyledCheckboxButtonItemWrapper key={option.laps}>
              <StyledCheckbox
                type="checkbox"
                value={option.laps}
                checked={checkedLaps === option.laps}
                onChange={handleChangeLaps}
              />
              {checkedLaps === option.laps && <StyledCheckmarkIcon />}
              <StyledLapsLabel>
                {option.laps} {t("laps")} /{" "}
                {dateData.isFullPrice && option.fullPrice
                  ? option.fullPrice
                  : option.price}{" "}
                {t("euro")}
              </StyledLapsLabel>
            </StyledCheckboxButtonItemWrapper>
          );
        })}
      </CheckboxWrapper>
      <StyledDivider />
      <VerticalLine />
      <CheckboxWrapper>
        {isPartDay || !dateData.isFullDayAvailable ? (
          <>
            {dateData.morning && (
              <StyledCheckboxButtonItemWrapper>
                <StyledCheckbox
                  type="checkbox"
                  value="morning"
                  checked={checkedTime === "morning"}
                  onChange={handleChangeTime}
                />
                {checkedTime === "morning" && <StyledCheckmarkIcon />}
                <StyledLapsLabel>Morning / {dateData.morning}</StyledLapsLabel>
              </StyledCheckboxButtonItemWrapper>
            )}
            {dateData.evening && (
              <StyledCheckboxButtonItemWrapper>
                <StyledCheckbox
                  type="checkbox"
                  value="evening"
                  checked={checkedTime === "evening"}
                  onChange={handleChangeTime}
                />
                {checkedTime === "evening" && <StyledCheckmarkIcon />}
                <StyledLapsLabel>
                  Afternoon / {dateData.evening}
                </StyledLapsLabel>
              </StyledCheckboxButtonItemWrapper>
            )}
          </>
        ) : (
          <StyledCheckboxButtonItemWrapper>
            <StyledCheckbox
              type="checkbox"
              value="full_day"
              checked={checkedTime === "full_day"}
              onChange={handleChangeTime}
            />
            <StyledCheckmarkIcon />
            <StyledLapsLabel>
              Full day /{" "}
              {dateData.fullDay
                ? dateData.fullDay
                : `${dateData.open_time} - ${dateData.close_time}`}
            </StyledLapsLabel>
          </StyledCheckboxButtonItemWrapper>
        )}
      </CheckboxWrapper>
      <StyledDivider />
    </StyledInfo>
  );
}
