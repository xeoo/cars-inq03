import { DEVICE } from "@/utils/device";
import { font12, font14, font16, font20_600_28 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import Line from "@/assets/icon/line.svg";
import LineMiddle from "@/assets/icon/lineMiddle.svg";

export const StyledBookingPathWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 30px;
  @media (min-width: ${DEVICE.large}px) {
    height: 200px;
  }
`;

export const StyledBookingPath = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
  }
`;

export const Label = styled.div`
  ${font16}
  color: ${THEME.grey};
  padding-bottom: 7px;
  @media (max-width: ${DEVICE.large}px) {
    ${font12}
  }
  @media (max-width: ${DEVICE.medium}px) {
    text-align: center;
  }
`;

export const Title = styled.div`
  ${font20_600_28}
  color:${THEME.white};
  @media (max-width: ${DEVICE.large}px) {
    ${font14}
  }
  @media (max-width: ${DEVICE.medium}px) {
    text-align: center;
  }
`;

export const StepWrapper = styled.div`
  display: flex;
  @media (max-width: ${DEVICE.medium}px) {
    flex-direction: column;
    width: 135px;
    align-items: center;
    margin-bottom: 70px;
  }
`;

export const TextWrapper = styled.div`
  padding-left: 20px;
  @media (min-width: ${DEVICE.large}px) {
    width: 237px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 131px;
    padding-left: 16px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    padding: 0px;
  }
`;

export const LineWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-around;
  width: ${DEVICE.large}px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    justify-content: space-around;
    width: ${DEVICE.medium}px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    display: none;
  }
`;

export const PathWrapper = styled.div`
  display: flex;
  margin-bottom: 30px;
  @media (min-width: ${DEVICE.large}px) {
    margin-left: 17px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-around;
    height: 260px;
    margin-top: 40px;
  }
`;

export const EllipseWrapper = styled.div`
  margin: 0px 10px;
`;

export const LineIcon = styled(Line)`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 177px;
  }
`;

export const LineMiddleIcon = styled(LineMiddle)`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 110px;
  }
`;

export const StepMiddleMobile = styled.div`
  @media (min-width: ${DEVICE.medium}px) {
    display: none;
  }
  position: absolute;
  bottom: 160px;
`;

export const StepTopMobile = styled.div`
  @media (min-width: ${DEVICE.medium}px) {
    display: none;
  }
  position: absolute;
  bottom: 285px;
  svg {
    width: 100px;
  }
  path {
    stroke-opacity: 0.1;
    width: 100px;
  }
`;

export const StepBottomMobile = styled.div`
  @media (min-width: ${DEVICE.medium}px) {
    display: none;
  }
  position: absolute;
  bottom: 111px;
  svg {
    width: 100px;
  }
  path {
    stroke-opacity: 0.1;
  }
`;
