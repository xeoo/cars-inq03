"use client";

import {
  EllipseWrapper,
  Label,
  LineWrapper,
  PathWrapper,
  StepWrapper,
  StyledBookingPath,
  StyledBookingPathWrapper,
  TextWrapper,
  Title,
  LineIcon,
  StepMiddleMobile,
  StepBottomMobile,
  StepTopMobile,
  LineMiddleIcon,
} from "./StyledBookingPath";
import StepOneIcon from "@/assets/icon/stepOne.svg";
import StepTwoIcon from "@/assets/icon/stepTwo.svg";
import StepThreeIcon from "@/assets/icon/stepThree.svg";
import StepFourIcon from "@/assets/icon/stepFour.svg";
import EllipseIcon from "@/assets/icon/ellipse.svg";
import LineShortIcon from "@/assets/icon/lineShort.svg";
import StepMiddleMobileIcon from "@/assets/icon/stepMiddleMobile.svg";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

export default function BookingPath() {
  const { t } = useTranslation();
  return (
    <StyledBookingPathWrapper>
      {/*<StepTopMobile>*/}
      {/*  <LineIcon />*/}
      {/*</StepTopMobile>*/}
      {/*<StepMiddleMobile>*/}
      {/*  <StepMiddleMobileIcon />*/}
      {/*</StepMiddleMobile>*/}
      {/*<StepBottomMobile>*/}
      {/*  <LineIcon />*/}
      {/*</StepBottomMobile>*/}
      <StyledBookingPath>
        <PathWrapper>
          <StepWrapper>
            <StepOneIcon />
            <TextWrapper>
              <Label>{t("stepOne")}</Label>
              <Title>{t("stepOneTitle")}</Title>
            </TextWrapper>
          </StepWrapper>
          <StepWrapper>
            <StepTwoIcon />
            <TextWrapper>
              <Label>{t("stepTwo")}</Label>
              <Title>{t("stepTwoTitle")}</Title>
            </TextWrapper>
          </StepWrapper>
          <StepWrapper>
            <StepThreeIcon />
            <TextWrapper>
              <Label>{t("stepThree")}</Label>
              <Title>{t("stepThreeTitle")}</Title>
            </TextWrapper>
          </StepWrapper>
          <StepWrapper>
            <StepFourIcon />
            <TextWrapper>
              <Label>{t("stepFour")}</Label>
              <Title>{t("stepFourTitle")}</Title>
            </TextWrapper>
          </StepWrapper>
        </PathWrapper>
        <LineWrapper>
          <LineShortIcon />
          <EllipseWrapper>
            <EllipseIcon />
          </EllipseWrapper>
          <LineIcon />
          <EllipseWrapper>
            <EllipseIcon />
          </EllipseWrapper>
          <LineIcon />
          <EllipseWrapper>
            <EllipseIcon />
          </EllipseWrapper>
          <LineIcon />
          <EllipseWrapper>
            <EllipseIcon />
          </EllipseWrapper>
          <LineMiddleIcon />
        </LineWrapper>
      </StyledBookingPath>
    </StyledBookingPathWrapper>
  );
}
