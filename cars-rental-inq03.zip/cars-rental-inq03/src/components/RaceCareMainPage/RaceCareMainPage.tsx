"use client";
import {
  StyledRaceCareMainPage,
  Title,
  Text,
  InfoWrapper,
} from "./StyledRaceCareMainPage";
import Button from "../UI/Button/Button";
import Link from "next/link";
import { routes } from "@/constants/routes";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

export default function RaceCareMainPage() {
  const { t } = useTranslation();
  return (
    <StyledRaceCareMainPage>
      <InfoWrapper itemScope itemType="http://schema.org/WebSite">
          <meta itemProp="url" content="https://prodrivenurburg.de/" />
        <Title itemProp="name">{t("raceCarRentalNurburg")}</Title>
        <Text itemProp="description">{t("rentalCompany")}</Text>
        <Link href={routes.mainRoutes[0].path}>
          <Button title={t("Our cars")} />
        </Link>
      </InfoWrapper>
    </StyledRaceCareMainPage>
  );
}
