import styled from "styled-components";
import { THEME } from "@/utils/theme";
import {font14, font16, font20, font24, font26, font32, font40, font48, font60} from "@/utils/fonts";
import { DEVICE } from "@/utils/device";

export const StyledRaceCareMainPage = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  @media (min-width: ${DEVICE.large}px) {
    justify-content: center;
    height: 580px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    height: 550px;
  }
`;

export const Title = styled.h1`
  ${font60}
  color: ${THEME.white};
  text-align: center;
  width: 90%;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font40}
    padding: 0px 0 0px 0;
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font32}
    padding: 60px 0px 0px 0px;
  }
  @media (min-width: ${DEVICE.large}px) {
    
  }
 
`;

export const Text = styled.h2`
  width: 950px;
  text-align: center;
  padding-top: 30px;
  padding-bottom: 30px;
  ${font20}
  color: ${THEME.grey};
  
  @media (max-width: ${DEVICE.large}px) {
    ${font20};
    width: 80%;
    padding-bottom: 40px;
    padding-top: 40px;
  }
  
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
    width: 90%;
    padding-bottom: 30px;
    padding-top: 30px;
  }
  
  @media (max-width: ${DEVICE.small}px) {
    ${font14};
    width: 90%;
    padding-bottom: 30px;
    padding-top: 30px;
  }
  
`;

export const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  @media (min-width: ${DEVICE.medium}px) {
    height: 288px;
  }
`;
