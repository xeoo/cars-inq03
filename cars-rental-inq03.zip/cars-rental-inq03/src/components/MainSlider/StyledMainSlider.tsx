import styled from "styled-components";
import ArrowLeftSlider from "@/assets/icon/arrowLeftSlider.svg";
import ArrorRightSlider from "@/assets/icon/arrorRightSlider.svg";
import { THEME } from "@/utils/theme";
import { DEVICE } from "@/utils/device";

export const SliderMainWrapper = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    width: ${DEVICE.medium}px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    width: ${DEVICE.large}px;
  }
  margin: 0px auto;
`;

export const StyledMainSlider = styled.div<{ $buttonPossition?: boolean }>`
  @media (max-width: ${DEVICE.medium}px) {
    top: ${(props) => (props.$buttonPossition ? "50%" : "30%")};
    width: 80px;
    height: 300px;
    z-index: 1;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    top: 20%;
    width: 80px;
    z-index: 1;
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    z-index: 1;
    margin-left: -60px;
    top: 35%;
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    height: 250px;
    z-index: 1;
    margin-left: -150px;
    margin-right: -100px;
  }

  &:before {
    content: none !important;
  }
  &:hover {
    cursor: pointer;
  }
`;

export const StyledArrowLeftSlider = styled(ArrowLeftSlider)`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    rect {
      fill: transparent;
    }
  }
  @media (max-width: ${DEVICE.medium}px) {
    rect {
      fill: transparent;
    }
  }
  &:hover {
    cursor: pointer;
    rect {
      fill-opacity: 15%;
    }
    path {
      stroke: ${THEME.white};
    }
  }
`;

export const StyledArrorRightSlider = styled(ArrorRightSlider)`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    rect {
      fill: transparent;
    }
  }
  @media (max-width: ${DEVICE.medium}px) {
    rect {
      fill: transparent;
    }
  }
  &:hover {
    cursor: pointer;
    rect {
      fill-opacity: 15%;
    }
    path {
      stroke: ${THEME.white};
    }
  }
`;
