"use client";
import React from "react";
import Slider, { Settings } from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {
  SliderMainWrapper,
  StyledArrorRightSlider,
  StyledArrowLeftSlider,
  StyledMainSlider,
} from "./StyledMainSlider";
import { usePathname, useRouter } from "next/navigation";
import { Car } from "@/types/car";

type MainSliderProps = {
  children: React.ReactNode;
  activeCarIndex?: number;
  cars?: Car[];
};

export default function MainSlider({
  children,
  activeCarIndex = 0,
  cars,
}: MainSliderProps) {
  const pathname = usePathname();
  const router = useRouter();

  const handleChangeCar = (_: number, index: number) => {
    if (cars) {
      router.push(`/checkout/${cars[index].id}/details`);
    }
  };

  function NextArrow(props: any) {
    const { className, onClick } = props;
    return (
      <StyledMainSlider
        className={className}
        onClick={onClick}
        $buttonPossition={pathname?.endsWith("details")}
      >
        <StyledArrorRightSlider />
      </StyledMainSlider>
    );
  }

  function PrevArrow(props: any) {
    const { className, onClick } = props;
    return (
      <StyledMainSlider
        className={className}
        onClick={onClick}
        $buttonPossition={pathname?.endsWith("details")}
      >
        <StyledArrowLeftSlider />
      </StyledMainSlider>
    );
  }

  const settings: Settings = {
    infinite: (children as Array<React.ReactNode>)?.length > 1,
    speed: 500,
    initialSlide: activeCarIndex,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    beforeChange: handleChangeCar,
  };

  return (
    <SliderMainWrapper className="slider-container">
      <Slider {...settings}>{children}</Slider>
    </SliderMainWrapper>
  );
}
