"use client";

import {
  StyledInfo,
  StyledDivider,
  StyledItem,
  OrderSummaryTitle,
  StyledItemTitle,
  StyledItemLabel,
  StyledItemTotal,
  StyledItemTotalPrice,
  StyledDividerWrapper,
} from "./StyledOrderSummary";

import { TAddons } from "../AdditionCheckout/AdditionCheckout";
import { CarOrder } from "@/types/order";

interface IOrderSummary {
  addons: TAddons[];
  totalPrice: number;
  carInfo: CarOrder;
  paymentPercentage?: number;
}

export default function OrderSummary({
  addons,
  totalPrice,
  carInfo,
  paymentPercentage,
}: IOrderSummary) {
  return (
    <StyledInfo>
      <StyledDividerWrapper>
        <StyledDivider />
      </StyledDividerWrapper>
      <OrderSummaryTitle>Order Summary</OrderSummaryTitle>
      <StyledDivider />
      <StyledItem>
        <StyledItemTitle>Car details</StyledItemTitle>{" "}
        <StyledItemLabel>{carInfo.carDetail}</StyledItemLabel>
      </StyledItem>
      <StyledItem>
        <StyledItemTitle>Event type</StyledItemTitle>
        <StyledItemLabel>
          {carInfo.checkedTime.charAt(0).toUpperCase() +
            carInfo.checkedTime.slice(1)}{" "}
          - {carInfo.checkedLaps} laps
        </StyledItemLabel>
      </StyledItem>
      <StyledItem>
        <StyledItemTitle>Event date</StyledItemTitle>{" "}
        <StyledItemLabel>
          {carInfo.date} / {carInfo.time}
        </StyledItemLabel>
      </StyledItem>
      <StyledDivider />
      <StyledItem>
        <StyledItemTitle>Base price</StyledItemTitle>{" "}
        <StyledItemLabel>{carInfo.basePrice} €</StyledItemLabel>
      </StyledItem>
      {addons.map(({ id, isSelected, title, price }) => {
        if (!isSelected) return;
        return (
          <StyledItem key={id}>
            <StyledItemTitle>{title}</StyledItemTitle>{" "}
            <StyledItemLabel>{price} €</StyledItemLabel>
          </StyledItem>
        );
      })}
      <StyledDivider />
      <StyledItem>
        <StyledItemTotal>Total Amount</StyledItemTotal>{" "}
        <StyledItemTotalPrice
          $isFullAmount={Boolean(paymentPercentage && paymentPercentage < 100)}
        >
          {totalPrice} €
        </StyledItemTotalPrice>
      </StyledItem>
      {paymentPercentage && paymentPercentage < 100 && (
        <StyledItem>
          <StyledItemTotal>To pay</StyledItemTotal>{" "}
          <StyledItemTotalPrice>
            {(totalPrice * paymentPercentage) / 100} €
          </StyledItemTotalPrice>
        </StyledItem>
      )}
      <StyledDivider />
    </StyledInfo>
  );
}
