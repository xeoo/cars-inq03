import { font16_600_28, font16, font20, font14 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import ArrowRightCheckout from "@/assets/icon/arrowRightCheckoutSlider.svg";
import ArrowLeftCheckout from "@/assets/icon/arrowLeftCheckoutSlider.svg";
import Slider from "react-slick";
import CheckmarkIcon from "@/assets/icon/checked.svg";
import { DEVICE } from "@/utils/device";

export const StyledSlider = styled(Slider)`
  &.slick-slider {
    position: relative;
    height: 180px;
    @media (max-width: ${DEVICE.medium}px) {
      width: ${DEVICE.small}px;
    }
    @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
      width: ${DEVICE.medium}px;
    }
    @media (min-width: ${DEVICE.large}px) {
      width: 410px;
    }
    overflow: hidden;
    & > .slick-list {
      & > .slick-track {
        display: flex;
      }
    }
    &.slick-slide {
      height: auto;
    }
  }
`;

export const StyledRightArrowCheckout = styled(ArrowRightCheckout)`
  position: absolute;
  left: 0;
  top: 50%;
  z-index: 4;
`;

export const StyledLeftArrowCheckout = styled(ArrowLeftCheckout)`
  position: absolute;
  right: 0;
  top: 50%;
  z-index: 4;
`;

export const StyledSlideWrapper = styled.div`
  display: flex !important;
  align-items: center;
  flex-direction: column;
`;

export const StyledCarTitle = styled.div`
  ${font16_600_28};
  color: ${THEME.white};
`;

export const StyledDivider = styled.div`
  margin: 30px 0;
  height: 1px;
  background-color: ${THEME.white};
  opacity: 0.1;
`;

export const StyledItem = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
`;

export const StyledInfo = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    width: 410px;
  }
  color: ${THEME.white};
`;

export const StyledRadio = styled.input`
  appearance: none;
  width: 24px;
  height: 24px;
  border: 1px solid ${THEME.white};
  opacity: 0.1;
  border-radius: 4px;
  outline: none;
  margin-right: 10px;
  cursor: pointer;

  &:checked {
    background-color: ${THEME.green15opacity};
    border-color: ${THEME.green35opacity};
  }
`;

export const StyledLapsLabel = styled.div`
  ${font16};
  color: ${THEME.white};
`;

export const RadioButtonLabel = styled.label`
  display: flex;
  flex-direction: column;
`;

export const StyledRadioButtuonItemWrapper = styled.div`
  display: flex;
  position: relative;
`;

export const StyledCheckMarkWrapper = styled.span`
  position: absolute;
  top: 50%;
  left: 4%;
  transform: translate(-50%, -50%);
`;

export const StyledCheckmarkIcon = styled(CheckmarkIcon)``;

export const OrderSummaryTitle = styled.div`
  ${font20};
  color: ${THEME.white};
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
    text-align: center;
  }
`;

export const StyledItemTitle = styled.span`
  ${font16};
  color: ${THEME.grey};
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
  }
`;

export const StyledItemLabel = styled.span`
  ${font16};
  color: ${THEME.white};
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
  }
`;

export const StyledItemTotal = styled.span`
  ${font16};
  color: ${THEME.white};
`;

export const StyledItemTotalPrice = styled.span<{ $isFullAmount?: boolean }>`
  ${font20};
  color: ${(props) => (props.$isFullAmount ? THEME.white : THEME.red)};
  // color: ${THEME.red};
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
  }
`;

export const StyledDividerWrapper = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    display: none;
  }
`;
