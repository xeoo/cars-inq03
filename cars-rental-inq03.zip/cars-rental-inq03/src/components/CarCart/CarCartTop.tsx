import {
  BookCar,
  CarDescription,
  CarPrice,
  CarTitle,
  InfoWrapper,
  Laps,
  MoreInfo,
  CarIcon,
  IconCarWrapper,
  InfoTopWrapper,
  CarPriceWrapper,
  BtnWrapper,
  BackIconWrapper,
  InfoWrapperRight,
  ImageMaskGroup,
  MobileIconCarWrapper,
} from "./StyledCarCart";
import Button from "../UI/Button/Button";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";
import Link from "next/link";
import { routes } from "@/constants/routes";
import Image from "next/image";

import Hidden from "../UI/Hidden/Hidden";

type CarCartProps = {
  id: string | number;
  title: string;
  description: string;
  price: number;
  laps: string;
  icon: string;
  iconRight: boolean;
  characteristics?: boolean;
  showMaskGroup?: boolean;
};

export default function CarCartTop({
  id,
  title,
  description,
  price,
  laps,
  icon,
  iconRight,
  characteristics,
  showMaskGroup = true,
}: CarCartProps) {
  const { t } = useTranslation();

  return (
    <div>
      <Hidden mediumButtonSliderDown>
        {iconRight ? (
          <InfoTopWrapper>
            <IconCarWrapper>
              <CarIcon
                src={icon}
                alt="car"
                width={728}
                height={483}
                priority

              />
              {showMaskGroup && (
                <Image
                  src="/image/maskGroup.png"
                  alt="car"
                  width={585}
                  height={585}
                  priority
                />
              )}
            </IconCarWrapper>
            <InfoWrapperRight>
              <BookCar
                >
                {t("bookYour")}
              </BookCar>
              <CarTitle itemProp="name">{title}</CarTitle>
              <CarDescription>
                {description}
              </CarDescription>
              <CarPriceWrapper>
                <CarPrice>
                  {price} {t("euro")}
                </CarPrice>
                <Laps>
                  {t("forLaps")} {t("laps", { count: Number(laps) })}
                </Laps>
              </CarPriceWrapper>
              <BtnWrapper>
                <Link href={`${routes.mainRoutes[1].path}/${id}/booking`}>
                  <Button title={t("bookNow")} />
                </Link>
                {characteristics && (
                  <MoreInfo href={`${routes.mainRoutes[1].path}/${id}/details`}>
                    {t("moreInfo")}
                  </MoreInfo>
                )}
              </BtnWrapper>
            </InfoWrapperRight>
          </InfoTopWrapper>
        ) : (
          <InfoTopWrapper>
            <InfoWrapper>
              <BookCar
                >
                {t("bookYour")}
              </BookCar>
              <CarTitle >{title}</CarTitle>
              <CarDescription>
                {description}
              </CarDescription>

              <CarPriceWrapper>
                <CarPrice>
                  {price} {t("euro")}
                </CarPrice>
                <Laps>
                  {t("forLaps")} {t("laps", { count: Number(laps) })}
                </Laps>
              </CarPriceWrapper>
              <BtnWrapper>
                <Link href={`${routes.mainRoutes[1].path}/${id}/booking`}>
                  <Button title={t("bookNow")} />
                </Link>
                {characteristics && (
                  <MoreInfo href={`${routes.mainRoutes[1].path}/${id}/details`}>
                    {t("moreInfo")}
                  </MoreInfo>
                )}
              </BtnWrapper>
            </InfoWrapper>
            <IconCarWrapper>
              <CarIcon
                src={icon}
                alt="car"
                width={728}
                height={483}
                priority

              />
              <BackIconWrapper>
                {showMaskGroup && (
                  <Image
                    src="/image/maskGroup.png"
                    alt="car"
                    width={585}
                    height={585}
                    priority
                  />
                )}
              </BackIconWrapper>
            </IconCarWrapper>
          </InfoTopWrapper>
        )}
      </Hidden>
      <Hidden mediumButtonSliderUp>
        <InfoTopWrapper>
          <MobileIconCarWrapper>
            <CarIcon
              src={icon}
              alt="car"
              width={728}
              height={483}
              priority

            />
            <ImageMaskGroup
              src="/image/maskGroup.png"
              alt="car"
              width={480}
              height={480}
              priority
            />
          </MobileIconCarWrapper>
          <CarPriceWrapper
            $iconRight={iconRight}
            >
            <CarPrice>
              {price} {t("euro")}
            </CarPrice>
            <Laps>
              {t("forLaps")} {laps} {t("laps")}
            </Laps>
          </CarPriceWrapper>
          <BookCar
            >
            {t("bookYour")}
          </BookCar>
          <CarTitle >{title}</CarTitle>
          <CarDescription>{description}</CarDescription>

          <BtnWrapper>
            <Link href={`${routes.mainRoutes[1].path}/${id}/booking`}>
              <Button title={t("bookNow")} />
            </Link>
            {characteristics && (
              <MoreInfo href={`${routes.mainRoutes[1].path}/${id}/details`}>
                {t("moreInfo")}
              </MoreInfo>
            )}
          </BtnWrapper>
        </InfoTopWrapper>
      </Hidden>
    </div>
  );
}
