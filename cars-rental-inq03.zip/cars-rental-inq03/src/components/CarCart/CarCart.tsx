'use client'

import { Characteristic } from "@/types/car";
import { StyledCarCart } from "./StyledCarCart";
import CarCartBottom from "./CarCartBottom";
import CarCartTop from "./CarCartTop";

type CarCartProps = {
  id: string | number;
  title: string;
  description: string;
  price: number;
  laps: string;
  icon: string;
  iconRight: boolean;
  characteristics?: Array<Characteristic>;
  showMaskGroup?: boolean;
};

export default function CarCart({
  characteristics,
  showMaskGroup,
  ...otherProps
}: CarCartProps) {
  return (
    <StyledCarCart $height={Boolean(characteristics)}>
      <CarCartTop
        {...otherProps}
        characteristics={characteristics && characteristics.length > 0}
        showMaskGroup={showMaskGroup}
      />
      {characteristics && characteristics.length > 0 && (
        <CarCartBottom characteristics={characteristics} />
      )}
    </StyledCarCart>
  );
}
