import { DEVICE } from "@/utils/device";
import {
  font12,
  font14,
  font16,
  font20,
  font20_400_26,
  font24,
  font28_600_36,
  font40,
  font44_600_52,
  font48,
  font56,
} from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import Link from "next/link";
import styled from "styled-components";
import Image from "next/image";

export const StyledCarCart = styled.div<{ $height: boolean }>`
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    width: ${DEVICE.medium}px;
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    width: ${DEVICE.mediumSliderButton}px;
    height: ${(props) => (props.$height ? "882px" : "700px")};
  }
  gap: 100px;
`;

export const CharacteristicsWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  height: 114px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    margin-bottom: 80px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    height: 96px;
    margin-bottom: 80px;
  }

  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    margin-top: 30px;
  }
`;

export const Characteristics = styled.div`
  width: 210px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    width: 128px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 110px;
  }
`;

export const CharacteristicsTitle = styled.div`
  ${font20_400_26}
  color: ${THEME.grey};
  text-align: center;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    ${font16}
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font12}
  }
`;

export const CharacteristicsDescription = styled.div`
  ${font28_600_36}
  color: ${THEME.white};
  text-align: center;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    ${font24}
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font16}
  }
`;

export const InfoWrapper = styled.div`
  width: 440px;
  height: 418px;
  display: flex;
  flex-direction: column;
  margin-top: 90px;
`;

export const InfoWrapperRight = styled.div`
  width: 370px;
  height: 418px;
  display: flex;
  flex-direction: column;
  margin-top: 90px;
  margin-left: 70px;
`;

export const BookCar = styled.div`
  ${font20}
  color: ${THEME.grey};
  margin-bottom: 10px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font12}
  }
`;

export const CarTitle = styled.h2`
  ${font56}
  color: ${THEME.white};
  margin-bottom: 10px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    ${font48}
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font24}
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    min-height: 120px;
  }
`;

export const CarDescription = styled.span`
  ${font20}
  color: ${THEME.grey200};
  margin: 20px 0;
  text-align: center;
  @media (max-width: ${DEVICE.medium}px) {
    text-align: center;
    ${font14};
  }
  @media (min-width: ${DEVICE.mediumSliderButton}px) {
    text-align: left;
    min-height: 95px;
  }
`;

export const CarPriceWrapper = styled.div<{ $iconRight?: boolean | undefined }>`
  display: flex;
  align-items: baseline;
  margin-bottom: 40px;
  @media (max-width: ${DEVICE.mediumSliderButton}px) {
    flex-direction: column;
    position: absolute;
    left: ${(props) => (props.$iconRight ? "20%" : "72%")};
    top: 3%;
  }
  @media (max-width: ${DEVICE.medium}px) {
    left: ${(props) => (props.$iconRight ? "68%" : "12%")};
    top: 3%;
  }
`;

export const CarPrice = styled.div`
  ${font44_600_52}
  color: ${THEME.white};
  margin-right: 16px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    ${font40}
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font24}
  }
`;

export const Laps = styled.div`
  ${font20}
  color: ${THEME.grey};
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
  }
`;

export const MoreInfo = styled(Link)`
  background: transparent;
  ${font16}
  color: ${THEME.red};
  cursor: pointer;
  text-decoration: underline;
  margin-top: 16px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
  }
`;

export const CarIcon = styled(Image)`
  position: absolute;
  width: 728px;
  height: auto;
  bottom: 100px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.mediumSliderButton}px) {
    width: 510px;
    bottom: 50px;
    height: auto;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 210px;
    height: auto;
    bottom: 20px;
  }
`;

export const MobileIconCarWrapper = styled.div`
  position: relative;
`;

export const IconCarWrapper = styled.div`
  width: 728px;
  position: relative;
`;

export const InfoTopWrapper = styled.div`
  display: flex;
  height: 668px;
  @media (max-width: ${DEVICE.mediumSliderButton}px) {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 850px;
    position: relative;
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
    height: 495px;
  }
`;

export const BtnWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  width: min-content;
`;

export const BackIconWrapper = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  height: 585px;
  width: 585px;
  z-index: -1;
  margin-left: 20px;
`;

export const CharacteristicsTopMobile = styled.div`
  display: flex;
  border-top: 1px solid ${THEME.grey100};
  padding-top: 20px;
  justify-content: center;
`;

export const CharacteristicsBottomMobile = styled.div`
  display: flex;
  border-bottom: 1px solid ${THEME.grey100};
  padding: 20px 0px;
  margin-bottom: 60px;
  justify-content: center;
`;

export const ImageMaskGroup = styled(Image)`
  @media (max-width: ${DEVICE.medium}px) {
    width: 200px;
    height: 200px;
  }
`;
