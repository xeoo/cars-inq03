import {
  Characteristics,
  CharacteristicsBottomMobile,
  CharacteristicsDescription,
  CharacteristicsTitle,
  CharacteristicsTopMobile,
  CharacteristicsWrapper,
} from "./StyledCarCart";
import "@/localization/i18n";

import React from "react";
import { Characteristic } from "@/types/car";
import { useWindowDimensions } from "@/hooks/useWindowDimensions";
import Hidden from "../UI/Hidden/Hidden";

type CarCartBottomProps = {
  characteristics: Array<Characteristic>;
};

export default function CarCartBottom({ characteristics }: CarCartBottomProps) {
  const { isSmallScreen } = useWindowDimensions();

  return (
    <>
      <Hidden smallUp>
        <CharacteristicsTopMobile>
          {characteristics.map(
            ({ title, description }, index) =>
              index < 3 && (
                <Characteristics key={`characteristics-${index}`}>
                  <CharacteristicsTitle>{title}</CharacteristicsTitle>
                  <CharacteristicsDescription>
                    {description.split("\\n").map((line, index) => (
                      <React.Fragment key={index}>
                        {line} <br />
                      </React.Fragment>
                    ))}
                  </CharacteristicsDescription>
                </Characteristics>
              )
          )}
        </CharacteristicsTopMobile>
        <CharacteristicsBottomMobile>
          {characteristics.map(
            ({ title, description }, index) =>
              index > 2 && (
                <Characteristics key={`characteristics-${index}`}>
                  <CharacteristicsTitle>{title}</CharacteristicsTitle>
                  <CharacteristicsDescription>
                    {description.split("\\n").map((line, index) => (
                      <React.Fragment key={index}>
                        {line} <br />
                      </React.Fragment>
                    ))}
                  </CharacteristicsDescription>
                </Characteristics>
              )
          )}
        </CharacteristicsBottomMobile>
      </Hidden>
      <Hidden smallDown>
        <CharacteristicsWrapper>
          {characteristics.map(({ title, description }) => (
            <Characteristics key={`characteristics-${title}`}>
              <CharacteristicsTitle>{title}</CharacteristicsTitle>
              <CharacteristicsDescription>
                {description.split("\\n").map((line, index) => (
                  <React.Fragment key={index}>
                    {line} <br />
                  </React.Fragment>
                ))}
              </CharacteristicsDescription>
            </Characteristics>
          ))}
        </CharacteristicsWrapper>
      </Hidden>
    </>
  );
}
