"use client";

import { StyledPayment, StyledImage, StyledTitle, StyledDescription, StyledCheckMarkWrapper, StyledCheckmarkIcon, StyledCheckMarkIconWrapper, StyledHighlight } from './StyledPaymentType'
import { TPayment } from '@/types/order';

interface IPayment {
  payments: TPayment[];
  selectedPayment: string;
  handleTogglePayment: (paymentOption: TPayment) => void;
}

export default function PaymentType({ payments, selectedPayment, handleTogglePayment }: IPayment) {
  return (
    <>
      {payments.map((payment) => { 
        const {id, image, title, description, payment_percentage} = payment;
        const isSelected = selectedPayment === id
        return (
        <StyledPayment $isSelected={isSelected} key={id} onClick={() => handleTogglePayment(payment)}>
          <StyledCheckMarkWrapper $isSelected={isSelected}>
            {isSelected && <StyledCheckMarkIconWrapper>
              <StyledCheckmarkIcon />
            </StyledCheckMarkIconWrapper>}
          </StyledCheckMarkWrapper>
          <StyledImage
            src={image}
            alt={title}
            width={60}
            height={60}
            priority
          />
          <div>
		  <StyledTitle>{title}</StyledTitle>
          <StyledDescription>
            {description}
            <StyledHighlight>
              {payment_percentage}%
            </StyledHighlight>
          </StyledDescription>
		  </div>
        </StyledPayment>
      )})}

    </>
  )
}