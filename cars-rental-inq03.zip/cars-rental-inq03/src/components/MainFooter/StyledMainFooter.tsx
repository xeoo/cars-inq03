import styled from "styled-components";
import { font14, font16, font20_600 } from "../../utils/fonts";
import { THEME } from "@/utils/theme";
import Link from "next/link";
import { DEVICE } from "@/utils/device";

export const StyledMainFooter = styled.div`
  @media (max-width: ${DEVICE.medium}px) {
    margin-top: 10px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
    height: 404px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
    height: 404px;
  }
  margin-left: auto;
  margin-right: auto;
  margin-top: 60px;
  background: ${THEME.dark};
`;

export const FooterTop = styled.div`
  display: flex;
  padding: 40px 0px;
  @media (max-width: ${DEVICE.medium}px) {
    flex-direction: column;
    align-items: center;
  }
`;

export const FooterBottom = styled.div`
  display: flex;
  align-items: center;
  height: 80px;
  ${font14}
  color: ${THEME.grey200};
`;

export const NavigationItem = styled(Link)<{ $active: boolean }>`
  ${font16}
  color:${(props) => (props.$active ? THEME.white : THEME.grey)};
  text-decoration: none;
  cursor: pointer;
  &:hover {
    color: ${THEME.red};
  }
  margin: 10px 0px;
`;

export const LinkTitle = styled.div`
  ${font20_600}
  color: ${THEME.white};
  margin-bottom: 20px;
  margin-top: 20px;
`;

export const LinkWrapper = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  @media (max-width: ${DEVICE.medium}px) {
    align-items: center;
  }
`;

export const MediaButtonWrapper = styled.div`
  display: flex;
  flex: 1;
  justify-content: flex-end;
  margin-top: 20px;
`;

export const ImageWrapper = styled.div`
  display: flex;
  flex: 1;
  margin-top: 20px;
`;

export const IconWrapper = styled.div`
  width: 144px;
  display: flex;
  justify-content: space-between;
`;
