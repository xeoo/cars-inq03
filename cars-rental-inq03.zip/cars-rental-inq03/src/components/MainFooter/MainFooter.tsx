"use client";

import {
  FooterBottom,
  FooterTop,
  IconWrapper,
  ImageWrapper,
  LinkTitle,
  LinkWrapper,
  MediaButtonWrapper,
  NavigationItem,
  StyledMainFooter,
} from "./StyledMainFooter";
import Image from "next/image";
import ButtonIcon from "../UI/ButtonIcon/ButtonIcon";
import { usePathname } from "next/navigation";
import { routes } from "@/constants/routes";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";
import { NavigationItemPointer } from "../MainHeader/StyledMainHeader";

export default function Footer() {
  const { t } = useTranslation();
  const pathname = usePathname();
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();

  return (
    <StyledMainFooter>
      <FooterTop>
        <ImageWrapper>
          <NavigationItemPointer
            key={routes.mainPage.id}
            href={routes.mainPage.path}
          >
            <Image
              src="/icon/headerLogo.svg"
              alt="Vercel Logo"
              width={145}
              height={30}
              priority
            />
          </NavigationItemPointer>
        </ImageWrapper>
        <LinkWrapper>
          <LinkTitle>{t("main")}</LinkTitle>
          {routes.mainRoutes.map(
            (route) =>
              route.name && (
                <NavigationItem
                  key={route.id}
                  href={
                    route.path === routes.mainRoutes[1].path
                      ? `${routes.mainRoutes[1].path}`
                      : route.path
                  }
                  $active={pathname ? pathname.includes(route.path) : false}
                >
                  {t(route.name)}
                </NavigationItem>
              )
          )}
        </LinkWrapper>
        <LinkWrapper>
          <LinkTitle>{t("second")}</LinkTitle>
          {routes.secondRoutes.map((route) => (
            <NavigationItem
              key={route.id}
              href={route.path}
              $active={route.path === pathname ? true : false}
              target="_blank"
            >
              {t(route.name)}
            </NavigationItem>
          ))}
        </LinkWrapper>
        <MediaButtonWrapper>
          <IconWrapper>
            {routes.mediaRoutes.map((route) => (
              <a key={route.id} href={route.path} target="_blank">
                <ButtonIcon icon={<route.icon />} />
              </a>
            ))}
          </IconWrapper>
        </MediaButtonWrapper>
      </FooterTop>
      <FooterBottom>
        {t("proDriveNurburg")} {currentYear} {t("allRightsReserved")}
      </FooterBottom>
    </StyledMainFooter>
  );
}
