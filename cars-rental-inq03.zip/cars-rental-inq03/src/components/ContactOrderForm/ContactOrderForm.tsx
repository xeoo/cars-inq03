"use client";

import PhoneInputComponent from "@/components/UI/PhoneInput/PhoneInput";
import {
  FormWrapper,
  InputPadding,
  InputWrapper,
  StyledContactForm,
} from "./StyledContactOrderForm";
import InputComponent from "@/components/UI/Input/Input";
import TextAreaComponent from "@/components/UI/TextArea/TextArea";
import { Control, Controller, FieldErrors, FieldValues } from "react-hook-form";
import { isEmail, isNumber } from "@/helpers/validation";
import { t } from "i18next";

interface IContactOrder {
  control: Control<FieldValues, any>;
  errors: FieldErrors<FieldValues>;
  formRef: React.RefObject<HTMLDivElement>;
}

export default function ContactOrderForm({
  control,
  errors,
  formRef,
}: IContactOrder) {
  return (
    <StyledContactForm ref={formRef}>
      <FormWrapper>
        <InputWrapper>
          <Controller
            control={control}
            name="firstName"
            defaultValue=""
            rules={{
              required: { value: true, message: "Required" },
            }}
            render={({ field: { ref, ...field } }) => (
              <InputComponent
                field={field}
                inputRef={ref}
                isError={errors.firstName}
                errorMessage={errors.firstName?.message?.toString()}
                label="Name"
                placeholder={t("Your Name")}
              />
            )}
          />
          <InputPadding />
          <Controller
            control={control}
            name="lastName"
            defaultValue={""}
            rules={{
              required: { value: true, message: "Required" },
            }}
            render={({ field: { ref, ...field } }) => (
              <InputComponent
                field={field}
                inputRef={ref}
                isError={errors.lastName}
                errorMessage={errors.lastName?.message?.toString()}
                label="Surname"
                placeholder={t("Your Surname")}
              />
            )}
          />
        </InputWrapper>
        <Controller
          control={control}
          name="email"
          defaultValue={""}
          rules={{
            required: { value: true, message: "Required" },
            validate: isEmail,
          }}
          render={({ field: { ref, ...field } }) => (
            <InputComponent
              field={field}
              inputRef={ref}
              isError={errors.email}
              errorMessage={errors.email?.message?.toString()}
              label="Email"
              placeholder="name@example.com"
            />
          )}
        />
        <Controller
          control={control}
          name="phone"
          rules={{
            required: { value: true, message: "Required" },
            minLength: { value: 10, message: "Min Length" },
            validate: isNumber,
          }}
          render={({ field: { ref, ...field } }) => (
            <PhoneInputComponent
              field={field}
              phoneRef={ref}
              isError={errors.phone}
              errorMessage={errors.phone?.message?.toString()}
              label={"Phone"}
            />
          )}
        />
        <Controller
          control={control}
          name="notes"
          render={({ field: { ref, ...field } }) => (
            <TextAreaComponent
              label="Notes"
              placeholder="Your Notes"
              field={field}
              inputRef={ref}
            />
          )}
        />
      </FormWrapper>
    </StyledContactForm>
  );
}
