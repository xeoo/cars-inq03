"use client";

import { TAddition } from "@/types/order";
import { TAddons } from "../AdditionCheckout/AdditionCheckout";
import {
  StyledAddition,
  StyledImage,
  StyledTitle,
  StyledDescription,
  StyledHighlight,
  StyledCheckMarkWrapper,
  StyledCheckMarkIconWrapper,
  StyledCheckmarkIcon,
  StyledTextWrapper,
} from "./StyledAdditions";

interface IAdditions {
  additions: TAddition[];
  addons: TAddons[];
  handleToggleAddon: (addition: TAddition) => void;
}

const findLastAdditionInGroup = (
  additions: TAddition[],
  type: string
): TAddition | null => {
  const group = additions.filter((addition) => addition.type === type);
  return group.length > 0 ? group[group.length - 1] : null;
};

const isLastInGroup = (
  addition: TAddition,
  additions: TAddition[],
  type: string
): boolean => {
  const lastAddition = findLastAdditionInGroup(additions, type);
  return lastAddition !== null && addition.id === lastAddition.id;
};

const calculateAdditionalMargin = (
  addition: TAddition,
  additions: TAddition[]
): string => {
  if (
    isLastInGroup(addition, additions, "package") ||
    isLastInGroup(addition, additions, "insurance")
  ) {
    return "20px";
  }
  return "0";
};

export default function Additions({
  additions,
  addons,
  handleToggleAddon,
}: IAdditions) {
  return (
    <>
      {additions.map((addition) => {
        const { id, image, title, description, descriptionHtml } = addition;
        const isSelected = Boolean(
          addons.find((addon) => addon.id === id && addon.isSelected)
        );
        return (
          <StyledAddition
            $isSelected={isSelected}
            key={id}
            onClick={() => handleToggleAddon(addition)}
            $additionalMarginBottom={calculateAdditionalMargin(
              addition,
              additions
            )}
          >
            <StyledCheckMarkWrapper $isSelected={isSelected}>
              {isSelected && (
                <StyledCheckMarkIconWrapper>
                  <StyledCheckmarkIcon />
                </StyledCheckMarkIconWrapper>
              )}
            </StyledCheckMarkWrapper>
            <StyledImage
              src={image}
              alt={title}
              width={60}
              height={60}
              priority
            />
            <StyledTextWrapper>
              <StyledTitle>{title}</StyledTitle>
              <StyledDescription>
                <StyledHighlight>{description}</StyledHighlight>{" "}
                {descriptionHtml}
              </StyledDescription>
            </StyledTextWrapper>
          </StyledAddition>
        );
      })}
    </>
  );
}
