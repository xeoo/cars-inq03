import styled from "styled-components";
import Image from "next/image";
import { THEME } from "@/utils/theme";
import { font12, font14, font16 } from "@/utils/fonts";
import { DEVICE } from "@/utils/device";
import CheckmarkIcon from "@/assets/icon/checked.svg";

export const StyledAddition = styled.div<{
  $isSelected: boolean;
  $additionalMarginBottom: string;
}>`
  position: relative;
  padding: 20px;
  display: flex;
  align-items: center;
  box-sizing: border-box;
  @media (max-width: ${DEVICE.medium}px) {
    width: 320px;
    border: 1px solid ${THEME.grey100};
    padding: 20px;
	margin-bottom:  ${(props) => props.$additionalMarginBottom}
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    border: 1px solid ${THEME.grey100};
    height: 248px;
    width: 233px;
    flex-direction: column;
  }
  @media (min-width: ${DEVICE.large}px) {
    border: 1px solid ${THEME.grey100};
    height: 248px;
    width: 233px;
    flex-direction: column;
  border: 1px solid ${({ $isSelected }) =>
    $isSelected ? THEME.green : THEME.grey100};
  box-sizing: border-box;
  &:hover {
    cursor: pointer;
    border: 1px solid ${THEME.green};
  }
`;

export const StyledImage = styled(Image)`
  margin: 20px 0;
  @media (max-width: ${DEVICE.medium}px) {
    width: 40px;
    height: 40px;
    margin: 20px;
  }
`;

export const StyledTitle = styled.div`
  ${font16}
  color: ${THEME.white};
  margin-bottom: 6px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
  }
  @media (min-width: ${DEVICE.medium}px) {
    text-align: center;
  }
`;

export const StyledDescription = styled.div`
  ${font14};
  color: ${THEME.grey};
  text-align: center;
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
    text-align: inherit;
  }

  @media (min-width: ${DEVICE.medium}px) {
    display: flex;
    flex-direction: column;
  }
`;

export const StyledHighlight = styled.span`
  ${font14}
  color: ${THEME.red};
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
  }
`;

export const StyledCheckMarkWrapper = styled.p<{ $isSelected: boolean }>`
  position: absolute;
  top: 20px;
  right: 20px;
  border: 1px solid
    ${({ $isSelected }) => ($isSelected ? THEME.green35opacity : THEME.grey100)};
  background: ${({ $isSelected }) =>
    $isSelected ? THEME.green15opacity : "transparent"};
  border-radius: 4px;
  width: 24px;
  height: 24px;
  margin: 0;
`;

export const StyledCheckMarkIconWrapper = styled.span`
  position: absolute;
  left: 50%;
  transform: translate(-50%, -50%);
  top: 50%;
`;

export const StyledCheckmarkIcon = styled(CheckmarkIcon)``;

export const StyledTextWrapper = styled.div`
  @media (max-width: ${DEVICE.medium}px) {
    width: 168px;
  }
`;
