import { font16, font20_600 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledContactInfo = styled.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  justify-content: space-around;
`;

export const InfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const Divider = styled.div`
  width: 100%;
  height: 1px;
  background: ${THEME.grey100};
`;

export const Title = styled.div`
  ${font20_600}
  color:${THEME.white};
  padding: 30px 0 12px 0px;
`;

export const Location = styled.div`
  ${font16}
  color:${THEME.grey}
`;

export const Email = styled.a`
  ${font16}
  color:${THEME.grey};
  text-decoration: underline;
`;

export const Phone = styled.div`
  ${font16}
  color:${THEME.grey};
  text-decoration: underline;
`;
