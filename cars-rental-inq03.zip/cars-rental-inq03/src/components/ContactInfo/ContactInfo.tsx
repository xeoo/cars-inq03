import {
  Divider,
  InfoWrapper,
  StyledContactInfo,
  Location,
  Title,
  Email,
  Phone,
} from "./StyledContactInfo";
import PhoneContacts from "@/assets/icon/phoneContacts.svg";
import EmailContacts from "@/assets/icon/emailContacts.svg";
import LocationContacts from "@/assets/icon/locationContacts.svg";
import { useTranslation } from "react-i18next";
import { CONTACTS } from "@/data/contacts";

export default function ContactInfo() {
  const { t } = useTranslation();
  return (
    <StyledContactInfo>
      <InfoWrapper>
        <LocationContacts />
            <Title>{t("Location")}</Title>
            <Location>{CONTACTS.address}</Location>
        </InfoWrapper>
        <Divider />
        <InfoWrapper itemScope itemType="http://schema.org/ContactPoint">
            <EmailContacts />
            <Title>{t("Email")}</Title>
            <Email itemProp="email">{CONTACTS.email}</Email>
        </InfoWrapper>
        <Divider />
        <InfoWrapper itemScope itemType="http://schema.org/ContactPoint">
            <PhoneContacts />
            <Title>{t("Phone")}</Title>
            <Phone itemProp="telephone">{CONTACTS.phone}</Phone>
        </InfoWrapper>
    </StyledContactInfo>
  );
}
