"use client";
import { STORIES } from "@/constants/stories";
import {
  ColumWrapper,
  ColumWrapperLast,
  ColumWrapperMiddle,
  IconWrapper,
  Pro,
  SliderImage,
  StoriesWrapper,
  StyledStories,
  StyledStoriesSlider,
  SvgWrapper,
  Title,
  Winner,
  WinnerWrapper,
  WinnerWrapperIcon,
} from "./StyledStories";
import { DATA_STORIES } from "@/data/stories";
import StoriesIcon from "@/assets/icon/storiesIcon.svg";
import StoriesMobileIcon from "@/assets/icon/storiesIconMobile.svg";

import StoriesSlider from "./StoriesSlider";
import Hidden from "../UI/Hidden/Hidden";
import { useWindowDimensions } from "@/hooks/useWindowDimensions";

export default function Stories() {
  const { isMediumScreen } = useWindowDimensions();

  return (
    <>
      <Hidden largeDown>
        <StyledStories>
          <ColumWrapper>
            <Title>{STORIES.yourRideStories}</Title>
            <Pro>{STORIES.proDriveNurb}</Pro>
            {DATA_STORIES[0] && (
              <IconWrapper
                key={`image-${0}`}
                $urlLink={DATA_STORIES[0].image}
                $altText={DATA_STORIES[0].alt}
              />
            )}
            <SvgWrapper>
              <StoriesIcon />
            </SvgWrapper>
            <Winner>{STORIES.winner}</Winner>
            <Pro>{STORIES.autor}</Pro>
          </ColumWrapper>
          <ColumWrapperMiddle>
            {DATA_STORIES[1] && (
              <IconWrapper
                $urlLink={DATA_STORIES[1].image}
                $altText={DATA_STORIES[1].alt}
              />
            )}
            {DATA_STORIES[2] && (
              <IconWrapper
                $urlLink={DATA_STORIES[2].image}
                $altText={DATA_STORIES[2].alt}
              />
            )}
          </ColumWrapperMiddle>
          <ColumWrapperLast>
            {DATA_STORIES[3] && (
              <IconWrapper
                $urlLink={DATA_STORIES[3].image}
                $altText={DATA_STORIES[3].alt}
              />
            )}
            {DATA_STORIES[4] && (
              <IconWrapper
                $urlLink={DATA_STORIES[4].image}
                $altText={DATA_STORIES[4].alt}
              />
            )}
          </ColumWrapperLast>
        </StyledStories>
      </Hidden>

      <Hidden largeUp>
        <StoriesWrapper>
          <Title>{STORIES.yourRideStories}</Title>
          <Pro>{STORIES.proDriveNurb}</Pro>
          <StyledStoriesSlider>
            <StoriesSlider>
              {DATA_STORIES.map((el, index) => (
                <div key={index}>
                  <SliderImage
                    src={el.image} // Access the image URL from the object
                    alt={el.alt || ""} // Access the alt text from the object, default to an empty string if not present
                    width={isMediumScreen ? "440" : "230"}
                    height={isMediumScreen ? "440" : "230"}
                  />
                </div>
              ))}
            </StoriesSlider>
          </StyledStoriesSlider>
          <WinnerWrapper>
            <WinnerWrapperIcon>
              {isMediumScreen ? <StoriesIcon /> : <StoriesMobileIcon />}
            </WinnerWrapperIcon>
            <Winner>{STORIES.winner}</Winner>
          </WinnerWrapper>
          <Pro>{STORIES.autor}</Pro>
        </StoriesWrapper>
      </Hidden>
    </>
  );
}
