import { DEVICE } from "@/utils/device";
import {
  font12,
  font14,
  font20,
  font28_600_36,
  font48,
  font56,
} from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import ArrowLeftSlider from "@/assets/icon/arrowLeftSlider.svg";
import ArrorRightSlider from "@/assets/icon/arrorRightSlider.svg";
import Image from "next/image";

export const StyledStories = styled.div`
  height: 1000px;
  display: flex;
  justify-content: space-between;
  width: ${DEVICE.large}px;
  margin: auto;
`;

export const Title = styled.div`
  ${font56}
  color: ${THEME.white};
  margin-bottom: 20px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font28_600_36}
    margin-top: 80px;
    margin-bottom: 10px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font48};
    margin-bottom: 15px;
  }
`;

export const Pro = styled.div`
  ${font20}
  color:${THEME.grey};
  margin-bottom: 41px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
    margin-bottom: 30px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font20}
  }
`;

export const Winner = styled.div`
  ${font20}
  color:${THEME.white};
  @media (min-width: ${DEVICE.large}px) {
    margin-top: -38px;
    margin-bottom: 20px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
    width: 247px;
    margin-bottom: 5px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 353px;
    margin-bottom: 15px;
  }
`;

export const SvgWrapper = styled.div`
  margin-left: -30px;
  margin-top: 41px;
`;

export const IconWrapper = styled.div<{ $urlLink: string, $altText: string }>`
  width: 370px;
  height: 385px;
  gap: 30px;
  background: ${(props) => `url(${props.$urlLink})`};
  background-size: cover;
  margin-top: 30px;

  span {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    border: 0;
  }
`;

export const ColumWrapper = styled.div`
  width: 370px;
`;

export const ColumWrapperMiddle = styled.div`
  width: 370px;
  margin-top: 70px;
`;

export const ColumWrapperLast = styled.div`
  width: 370px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
`;

export const SliderMainWrapper = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 440px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 230px;
  }
  margin: 0px auto;
`;

export const StyledArrorRightSlider = styled(ArrorRightSlider)`
  @media (max-width: ${DEVICE.medium}px) {
    rect {
      fill: transparent;
    }
  }
  &:hover {
    cursor: pointer;
    rect {
      fill-opacity: 15%;
    }
    path {
      stroke: ${THEME.white};
    }
  }
`;

export const StyledArrowLeftSlider = styled(ArrowLeftSlider)`
  @media (max-width: ${DEVICE.medium}px) {
    rect {
      fill: transparent;
    }
  }
  &:hover {
    cursor: pointer;
    rect {
      fill-opacity: 15%;
    }
    path {
      stroke: ${THEME.white};
    }
  }
`;

export const StyledMainSliderLeft = styled.div<{ $buttonPossition?: boolean }>`
  @media (max-width: ${DEVICE.medium}px) {
    left: -80px;
    top: 40%;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    left: -118px;
  }
  &:before {
    content: none !important;
  }
  &:hover {
    cursor: pointer;
  }
`;

export const StyledMainSliderRight = styled.div<{ $buttonPossition?: boolean }>`
  @media (max-width: ${DEVICE.medium}px) {
    top: 40%;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    right: -60px;
  }
  &:before {
    content: none !important;
  }
  &:hover {
    cursor: pointer;
  }
`;

export const StyledStoriesSlider = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 440px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 230px;
  }
  margin: auto;
`;

export const SliderImage = styled(Image)`
  border-radius: 8px;
`;

export const StoriesWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
    margin-bottom: 40px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: ${DEVICE.small}px;
    margin-bottom: 50px;
  }
  margin: auto;
`;

export const WinnerWrapper = styled.div`
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    position: relative;
    margin-top: 60px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    margin-top: 30px;
    position: relative;
  }
`;

export const WinnerWrapperIcon = styled.div`
  @media (max-width: ${DEVICE.medium}px) {
    position: absolute;
    top: -12px;
    left: -16px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    position: absolute;
    left: -30px;
    top: -30px;
  }
`;
