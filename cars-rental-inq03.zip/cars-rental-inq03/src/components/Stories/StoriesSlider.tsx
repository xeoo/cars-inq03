import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {
  SliderMainWrapper,
  StyledArrorRightSlider,
  StyledArrowLeftSlider,
  StyledMainSliderLeft,
  StyledMainSliderRight,
} from "./StyledStories";
import { usePathname } from "next/navigation";

type StoriesSliderProps = {
  children: React.ReactNode;
};

export default function StoriesSlider({ children }: StoriesSliderProps) {
  const pathname = usePathname();
  function NextArrow(props: any) {
    const { className, onClick } = props;
    return (
      <StyledMainSliderRight
        className={className}
        onClick={onClick}
        $buttonPossition={pathname?.endsWith("details")}
      >
        <StyledArrorRightSlider />
      </StyledMainSliderRight>
    );
  }

  function PrevArrow(props: any) {
    const { className, onClick } = props;
    return (
      <StyledMainSliderLeft
        className={className}
        onClick={onClick}
        $buttonPossition={pathname?.endsWith("details")}
      >
        <StyledArrowLeftSlider />
      </StyledMainSliderLeft>
    );
  }

  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
  };

  return (
    <SliderMainWrapper className="slider-container">
      <Slider {...settings}>{children}</Slider>
    </SliderMainWrapper>
  );
}
