"use client";

import { font12, font14, font14_24, font16_600_28 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";
import EllipseIcon from "@/assets/icon/checkoutEllipse.svg";
import LineIcon from "@/assets/icon/checkoutLine.svg";
import LineMiddleIcon from "@/assets/icon/checkoutLineMiddle.svg";
import { DEVICE } from "@/utils/device";

export const StyledBookingPathWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 200px;
  @media (max-width: ${DEVICE.medium}px) {
    overflow-x: scroll;
    justify-content: start;
    width: ${DEVICE.small}px;
    margin: auto;
  }
`;

export const StyledCheckout = styled.div`
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
  }
`;

export const Label = styled.div<{ $isActive: boolean; $isNext: boolean }>`
  ${font16_600_28}
  color:${(props) =>
    props.$isActive || !props.$isNext ? THEME.white : THEME.grey};
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font14};
    margin-top: 5px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
    margin-top: 10px;
  }
`;

export const Title = styled.div<{ $isActive: boolean; $isNext: boolean }>`
  ${font14_24};
  color: ${(props) =>
    props.$isActive || !props.$isNext ? THEME.grey : THEME.grey200};
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font12};
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
  }
`;

export const StepWrapper = styled.div`
  display: flex;
`;

export const TextWrapper = styled.div`
  height: 57px;
  width: 110px;
  padding-left: 24px;
  padding-right: 68px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 90px;
    padding-left: 15px;
    padding-right: 3px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    padding-left: 10px;
    padding-right: 3px;
  }
`;

export const LineWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
`;

export const PathWrapper = styled.div`
  display: flex;
  margin-bottom: 30px;
`;

export const EllipseWrapper = styled.div`
  margin: 0px 10px;
`;

export const StyledEllipseNewIcon = styled(EllipseIcon)<{
  $isActive: boolean;
  $isNext: boolean;
}>`
  circle {
    fill-opacity: ${(props) =>
      props.$isNext ? 0.1 : props.$isActive ? 0.25 : 0.5};
    fill: ${(props) =>
      props.$isActive || props.$isNext ? THEME.white : THEME.green};
  }
`;

export const StyledLineNewIcon = styled(LineIcon)<{
  $isNext: boolean;
  $isActive: boolean;
}>`
  path {
    stroke-opacity: ${(props) =>
      props.$isNext ? 0.1 : props.$isActive ? 0.25 : 0.5};
    stroke: ${(props) =>
      props.$isActive || props.$isNext ? THEME.white : THEME.green};
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 133px;
    path {
      width: 133px;
    }
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 147px;
    path {
      width: 147px;
    }
  }
`;

export const StyledLineMiddleIcon = styled(LineMiddleIcon)`
  path {
    stroke-opacity: 0.1;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 304px;
    path {
      width: 304px;
      d: path("M 0 1 h 304");
    }
  }
  @media (min-width: ${DEVICE.large}px) {
    width: 120px;
    path {
      width: 120px;
      d: path("M 0 1 h 120");
    }
  }
`;

export const StyledStepIcon = (Icon: any) => styled(Icon)<{
  $isActive: boolean;
  $isNext: boolean;
}>`
  cursor: pointer;
  rect {
    fill: ${(props) =>
      props.$isActive || props.$isNext ? THEME.white : THEME.green};
    fill-opacity: ${(props) =>
      props.$isActive ? 0.25 : props.$isNext ? 0.1 : 0.15};
  }
  path {
    fill: ${(props) =>
      props.$isActive || props.$isNext ? THEME.white : THEME.green};
  }
`;
