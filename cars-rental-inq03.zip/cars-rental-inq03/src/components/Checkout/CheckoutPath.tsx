'use client';

import {
  EllipseWrapper,
  Label,
  LineWrapper,
  PathWrapper,
  StepWrapper,
  StyledCheckout,
  StyledBookingPathWrapper,
  TextWrapper,
  Title,
  StyledLineMiddleIcon,
  StyledStepIcon,
  StyledEllipseNewIcon,
  StyledLineNewIcon,
} from "./StyledCheckoutPath";
import LineShortIcon from "@/assets/icon/checkoutLineShort.svg";
import { useTranslation } from "react-i18next";
import "@/localization/i18n";
import { Fragment, useEffect } from "react";
import Link from "next/link";
import { routes } from "@/constants/routes";

type CheckoutStatus = {
  icon: JSX.Element;
  title: string;
  label: string;
  link?: string;
};

type CheckoutPathType = {
  checkoutPath: Array<CheckoutStatus>;
  activeIndex: number;
  carSlug?: string;
};
export default function CheckoutPath({
  checkoutPath,
  activeIndex,
  carSlug,
}: CheckoutPathType) {
  const { t } = useTranslation();

  useEffect(() => {
    const activItem = document.getElementById("booking");
    if (activItem) {
      activItem.scrollLeft = activeIndex * 167;
    }
  });
  
  return (
    <StyledBookingPathWrapper id="booking">
      <StyledCheckout>
        <PathWrapper>
          {checkoutPath.map((item, index) => {
            const Icon = StyledStepIcon(item.icon);
            const isActive = activeIndex === index;
            const isNext = activeIndex < index;
            return (
              <StepWrapper key={index}>
                {item.link && index < activeIndex ? (
                  <Link
                    href={`${routes.mainRoutes[1].path}/${carSlug}/${item.link}`}
                  >
                    <Icon $isActive={isActive} $isNext={isNext} />
                  </Link>
                ) : (
                  <Icon $isActive={isActive} $isNext={isNext} />
                )}
                <TextWrapper>
                  <Title $isActive={isActive} $isNext={isNext}>
                    {t(item.title)}
                  </Title>
                  <Label $isActive={isActive} $isNext={isNext}>
                    {t(item.label)}
                  </Label>
                </TextWrapper>
              </StepWrapper>
            );
          })}
        </PathWrapper>
        <LineWrapper>
          <LineShortIcon />
          {checkoutPath.map((_, index) => {
            return (
              <Fragment key={index}>
                <EllipseWrapper>
                  <StyledEllipseNewIcon
                    $isActive={activeIndex === index}
                    $isNext={activeIndex < index}
                  />
                </EllipseWrapper>
                {index !== checkoutPath.length - 1 && (
                  <StyledLineNewIcon
                    $isActive={activeIndex - 1 === index}
                    $isNext={activeIndex - 1 < index}
                  />
                )}
              </Fragment>
            );
          })}
          <StyledLineMiddleIcon />
        </LineWrapper>
      </StyledCheckout>
    </StyledBookingPathWrapper>
  );
}
