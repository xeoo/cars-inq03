import styled from "styled-components";
import { THEME } from "@/utils/theme";
import { font12, font16 } from "@/utils/fonts";
import { DEVICE } from "@/utils/device";

export const StyledRecommendation = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  width: initial;
  padding: 20px 30px;
  gap: 26px;
  background: ${THEME.grey600};
  margin-top: 3px;
  @media (max-width: ${DEVICE.medium}px) {
    padding: 16px 20px;
  }
  @media (min-width: ${DEVICE.large}px) {
    height: 88px;
  }
`;

export const Info = styled.div`
  ${font16}
  color: ${THEME.grey};
  text-align: start;
  @media (max-width: ${DEVICE.medium}px) {
    ${font12}
  }
`;
