import { Info, StyledRecommendation } from "./StyledRecommendation";

type RecommendationProps = {
  icon: JSX.Element;
  title: string;
};

export default function Recommendation({ icon, title }: RecommendationProps) {
  return (
    <StyledRecommendation>
      <div>{icon}</div>
      <Info>{title}</Info>
    </StyledRecommendation>
  );
}
