import styled from "styled-components";
import { THEME } from "@/utils/theme";

export const StyledButtonIcon = styled.button`
  width: 40px;
  height: 40px;
  padding: 12px;
  border-radius: 4px;
  gap: 16px;
  background: ${THEME.dark50};
  border: 1px solid ${THEME.dark50};
  &:hover {
    background: ${THEME.red100};
    border: 1px solid ${THEME.red50};
    svg {
      g {
        path {
          fill: ${THEME.red};
        }
      }
    }
  }
`;
