"use client";
import { StyledButtonIcon } from "./StyledButtonIcon";

type ButtonIconProps = {
  icon: JSX.Element;
};

export default function ButtonIcon({ icon }: ButtonIconProps) {
  return <StyledButtonIcon>{icon}</StyledButtonIcon>;
}
