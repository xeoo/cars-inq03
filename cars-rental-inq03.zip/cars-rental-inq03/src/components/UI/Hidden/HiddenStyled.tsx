import { DEVICE } from "@/utils/device";
import styled from "styled-components";

const hiddenElementStyles = `
height: 0;
padding: 0;
overflow: hidden;
`;

export const HiddenStyled = styled.div<{
  $smallDown?: boolean;
  $smallUp?: boolean;
  $mediumDown?: boolean;
  $mediumUp?: boolean;
  $largeDown?: boolean;
  $largeUp?: boolean;
  $mediumButtonSliderDown?: boolean;
  $mediumButtonSliderUp?: boolean;
}>`
  ${(props) =>
    props.$smallDown
      ? ` @media (max-width: ${DEVICE.small}px) {
      		${hiddenElementStyles}
  }`
      : ""}
  ${(props) =>
    props.$smallUp
      ? ` @media (min-width: ${DEVICE.small}px) {
		    ${hiddenElementStyles}
	  }`
      : ""}
    ${(props) =>
    props.$mediumDown
      ? ` @media (max-width: ${DEVICE.medium}px) {
			${hiddenElementStyles}
		  }`
      : ""}
    ${(props) =>
    props.$mediumUp
      ? ` @media (min-width: ${DEVICE.medium}px) {
			${hiddenElementStyles}
			  }`
      : ""}
    ${(props) =>
    props.$largeDown
      ? ` @media (max-width: ${DEVICE.large}px) {
			${hiddenElementStyles}
				  }`
      : ""}
    ${(props) =>
    props.$largeUp
      ? ` @media (min-width: ${DEVICE.large}px) {
			${hiddenElementStyles}
		}`
      : ""}
    ${(props) =>
    props.$mediumButtonSliderDown
      ? ` @media (max-width: ${DEVICE.mediumSliderButton}px) {
				${hiddenElementStyles}
			}`
      : ""}
    ${(props) =>
    props.$mediumButtonSliderUp
      ? ` @media (min-width: ${DEVICE.mediumSliderButton}px) {
				${hiddenElementStyles}
			}`
      : ""};
`;
