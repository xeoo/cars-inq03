import React from "react";
import { HiddenStyled } from "./HiddenStyled";

interface HiddenProps {
  children: React.ReactNode;
  smallDown?: boolean;
  smallUp?: boolean;
  mediumDown?: boolean;
  mediumUp?: boolean;
  largeDown?: boolean;
  largeUp?: boolean;
  mediumButtonSliderDown?: boolean;
  mediumButtonSliderUp?: boolean;
}

const Hidden = (props: HiddenProps) => (
  <HiddenStyled
    $smallDown={props.smallDown}
    $smallUp={props.smallUp}
    $mediumDown={props.mediumDown}
    $mediumUp={props.mediumUp}
    $largeDown={props.largeDown}
    $largeUp={props.largeUp}
    $mediumButtonSliderDown={props.mediumButtonSliderDown}
    $mediumButtonSliderUp={props.mediumButtonSliderUp}
  >
    {props.children}
  </HiddenStyled>
);

export default Hidden;
