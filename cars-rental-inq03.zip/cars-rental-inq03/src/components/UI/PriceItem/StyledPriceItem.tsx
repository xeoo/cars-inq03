import { DEVICE } from "@/utils/device";
import { font16, font20_400_26 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledPriceItem = styled.div<{ $header: boolean }>`
  height: 68px;
  display: flex;
  justify-content: center;
  align-items: center;
  ${font20_400_26}
  color: ${(props) => (props.$header ? THEME.white : THEME.grey)};
  background: ${(props) => (props.$header ? THEME.red200 : THEME.grey600)};
  margin: 3px 3px 0px 0px;
  @media (max-width: ${DEVICE.medium}px) {
    width: 100%;
  }
`;

export const IconWrapper = styled.div`
  position: relative;
  display: inline-block;

  margin-left: 24px;
  margin-top: 8px;
  cursor: pointer;
  &:hover {
    path {
      opacity: 0.5;
    }
    span {
      display: revert;
    }
  }
  @media (max-width: ${DEVICE.medium}px) {
    display: none;
  }
`;

export const InfoTooltip = styled.span`
  display: none;
  position: absolute;
  z-index: 1;
  width: 237px;
  padding: 20px;
  gap: 10px;
  border-radius: 8px;
  border: 1px solid ${THEME.grey100};
  background: ${THEME.dark200};
  margin-left: 8px;
  ${font16}
  color: ${THEME.grey};
`;
