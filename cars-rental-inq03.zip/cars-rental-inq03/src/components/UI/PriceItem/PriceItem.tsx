'use client'
import { IconWrapper, InfoTooltip, StyledPriceItem } from "./StyledPriceItem";
import InfoIcon from "@/assets/icon/infoIcon.svg";

type PriceItemProps = {
  title: string;
  header?: boolean;
  info?: string;
};
export default function PriceItem({
  title,
  header = false,
  info,
}: PriceItemProps) {
  return (
    <StyledPriceItem $header={header}>
      {title}
      {info && (
        <IconWrapper>
          <InfoIcon />
          <InfoTooltip>{info}</InfoTooltip>
        </IconWrapper>
      )}
    </StyledPriceItem>
  );
}
