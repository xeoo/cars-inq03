"use client";
import { StyledButton } from "./StyledButton";

type ButtonProps = {
  title: string;
  width?: string;
  type?: "button" | "submit" | "reset" | undefined;
};

export default function Button(props: ButtonProps) {
  return (
    <StyledButton type={props.type} $width={props.width}>
      {props.title}
    </StyledButton>
  );
}
