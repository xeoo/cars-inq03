import styled from "styled-components";
import { THEME } from "@/utils/theme";
import { font16, font20 } from "@/utils/fonts";
import { DEVICE } from "@/utils/device";

export const StyledButton = styled.button<{ $width?: string }>`
  width: ${(props) => (props.$width ? `${props.$width}` : "auto")};
  white-space: nowrap;
  height: 62px;
  padding: 17px 36px;
  border-radius: 8px;
  gap: 15px;
  background: ${THEME.red};
  ${font20}
  border: none;
  color: ${THEME.white};
  cursor: pointer;
  @media (max-width: ${DEVICE.medium}px) {
    width: ${(props) => (props.$width ? `${props.$width}px` : "auto")};
    height: 62px;
    padding: 13px 26px;
    ${font16};
  }
`;
