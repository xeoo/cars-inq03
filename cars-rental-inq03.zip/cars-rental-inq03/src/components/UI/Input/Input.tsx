import {
  FieldError,
  FieldErrorsImpl,
  Merge,
  Noop,
  RefCallBack,
} from "react-hook-form";
import "@/localization/i18n";
import {
  Label,
  LabelErrorWrapper,
  LabelWrapper,
  Required,
  StyledPhoneInput,
  Error,
} from "../PhoneInput/StyledPhoneInput";
import { Input } from "./StyledInput";
import { useTranslation } from "react-i18next";

type InputProps = {
  field: {
    onChange: (...event: any[]) => void;
    onBlur: Noop;
    value: any;
    disabled?: boolean | undefined;
    name: string;
  };
  inputRef: RefCallBack;
  isError: FieldError | Merge<FieldError, FieldErrorsImpl<any>> | undefined;
  errorMessage?: string;
  placeholder: string;
  label: string;
  width?: string;
};

export default function InputComponent({
  field,
  inputRef,
  isError,
  errorMessage,
  label,
  placeholder,
  width = "100%",
}: InputProps) {
  const { t } = useTranslation();
  return (
    <StyledPhoneInput $width={width}>
      <LabelErrorWrapper>
        <LabelWrapper>
          <Label>{t(label)}</Label>
          <Required>*</Required>
        </LabelWrapper>
        {isError && <Error>{errorMessage && t(errorMessage)}</Error>}
      </LabelErrorWrapper>
      <Input
        $isError={isError}
        placeholder={t(placeholder)}
        {...field}
        ref={inputRef}
      />
    </StyledPhoneInput>
  );
}
