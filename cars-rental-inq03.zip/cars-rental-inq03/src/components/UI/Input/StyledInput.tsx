import { font16 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import { FieldError, FieldErrorsImpl, Merge } from "react-hook-form";
import styled from "styled-components";

export const Input = styled.input<{
  $isError: FieldError | Merge<FieldError, FieldErrorsImpl<any>> | undefined;
}>`
  background: ${(props) => (props.$isError ? THEME.red500 : THEME.grey700)};
  height: 60px;
  border: ${(props) =>
    props.$isError
      ? `1px solid ${THEME.red400}`
      : `1px solid ${THEME.grey100}`};
  color: ${THEME.white};
  border-radius: 8px;
  ${font16};
  box-shadow: none;
  padding: 0px 0px 0px 10px;
  margin: 0px;
  &:hover {
    background: ${THEME.grey600};
    border: 1px solid ${THEME.grey800};
  }
  &:focus {
    outline: none;
    outline-offset: 0px;
  }
  ::placeholder {
    color: ${THEME.grey};
  }
`;
