import styled from "styled-components";
import { THEME } from "@/utils/theme";
import { font12, font14_24, font16, font20_600_28 } from "@/utils/fonts";
import { DEVICE } from "@/utils/device";
import Image from "next/image";

export const StyledSpecificationsMain = styled.div<{
  $color: boolean;
  $index: number;
}>`
  gap: 30px;
  text-align: center;
  padding-top: 50px;
  background: ${(props) => (props.$color ? THEME.grey500 : THEME.grey600)};
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 255px;
    height: 252px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: 390px;
    height: 252px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    width: 160px;
    height: 200px;
    background: ${(props) =>
      props.$index === 0 || props.$index === 3 || props.$index === 4
        ? THEME.grey500
        : THEME.grey600};

    svg {
      width: 40px;
      height: 40px;
      mask {
        width: 40px;
        height: 40px;
        path {
          d: path("M 0 0 h 40 v 40 H 0 Z");
        }
      }
      g {
        path {
          width: 40px;
          height: 40px;
        }
      }
    }
  }
`;

export const Label = styled.div`
  ${font20_600_28}
  color: ${THEME.white};
  margin-top: 30px;
  margin-bottom: 12px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
  }
`;

export const Title = styled.div`
  ${font14_24}
  color: ${THEME.red};
  margin-bottom: 12px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
  }
`;

export const Description = styled.div`
  ${font16}
  padding: 0 14px;
  color: ${THEME.grey};
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
  }
`;

export const ImageSpecification = styled(Image)`
  @media (max-width: ${DEVICE.medium}px) {
    width: 40px;
    height: 40px;
  }
`;
