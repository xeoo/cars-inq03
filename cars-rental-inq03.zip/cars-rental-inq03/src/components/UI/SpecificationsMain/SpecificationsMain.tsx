'use client'
import {
  Description,
  Label,
  StyledSpecificationsMain,
  Title,
  ImageSpecification
} from "./StyledSpecificationsMain";

type SpecificationsInfoProps = {
  label: string;
  title: string;
  description?: string;
  icon: string;
  color: boolean;
  index: number;
};

export default function SpecificationsMain({
  label,
  title,
  description,
  icon,
  color,
  index,
}: SpecificationsInfoProps) {
  return (
    <StyledSpecificationsMain $color={color} $index={index}>
      <ImageSpecification
        src={icon}
        width={60}
        height={60}
        alt="60 of the author"
      />
      <Label>{label}</Label>
      <Title>{title}</Title>
      {description && <Description>{description}</Description>}
    </StyledSpecificationsMain>
  );
}
