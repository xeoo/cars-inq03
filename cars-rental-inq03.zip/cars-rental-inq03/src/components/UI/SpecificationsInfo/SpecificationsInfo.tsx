import React from "react";
import {
  StyledSpecificationsInfo,
  Top,
  Bottom,
} from "./StyledSpecificationsInfo";

type SpecificationsInfoProps = {
  label: string;
  title: string;
  index: number;
};

export default function SpecificationsInfo({
  label,
  title,
  index,
}: SpecificationsInfoProps) {
  return (
    <StyledSpecificationsInfo $index={index}>
      <Top>{label}</Top>
      <Bottom>{title.split("\\n").map((line, index) => (<React.Fragment key={index}>{line} <br /></React.Fragment>))}</Bottom>
    </StyledSpecificationsInfo>
  );
}
