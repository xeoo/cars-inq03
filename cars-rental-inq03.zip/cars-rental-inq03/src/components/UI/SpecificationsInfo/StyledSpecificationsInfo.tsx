import styled from "styled-components";
import { THEME } from "@/utils/theme";
import { font12, font16, font20_600_28 } from "@/utils/fonts";
import { DEVICE } from "@/utils/device";

export const StyledSpecificationsInfo = styled.div<{ $index: number }>`
  height: 167px;
  @media (max-width: ${DEVICE.medium}px) {
    width: ${(props) => (props.$index === 4 ? "100%" : "157px")};
    margin-bottom: 15px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: 146px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: 218px;
  }
`;

export const Top = styled.div`
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px 8px 0px 0px;
  gap: 16px;
  background: #ffffff0a;
  color: ${THEME.grey};
  ${font16}
  @media (max-width: ${DEVICE.medium}px) {
    ${font12};
  }
  margin-bottom: 3px;
`;

export const Bottom = styled.div`
  height: 104px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 0px 0px 8px 8px;
  gap: 16px;
  background: ${THEME.grey600};
  color: ${THEME.white};
  ${font20_600_28};
  @media (max-width: ${DEVICE.medium}px) {
    ${font16};
  }
  text-align: center;
`;
