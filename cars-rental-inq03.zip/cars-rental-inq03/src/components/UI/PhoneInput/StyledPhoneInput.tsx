import { font12, font14_28 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledPhoneInput = styled.div<{ $width: string }>`
  display: flex;
  flex-direction: column;
  width: ${(props) => `${props.$width}`};
  padding-bottom: 30px;
`;

export const LabelErrorWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
`;

export const LabelWrapper = styled.div`
  display: flex;
`;

export const Label = styled.div`
  color: ${THEME.grey};
  ${font14_28}
`;

export const Error = styled.div`
  color: ${THEME.red};
  ${font12}
`;

export const Required = styled.div`
  color: ${THEME.red};
  ${font14_28};
  margin-left: 3px;
`;
