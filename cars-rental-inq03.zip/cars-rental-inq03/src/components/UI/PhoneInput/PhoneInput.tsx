import "react-phone-input-2/lib/material.css";
import ReactPhoneInput from "react-phone-input-2";
import { THEME } from "@/utils/theme";
import { kanit } from "@/utils/fonts";
import {
  Label,
  LabelErrorWrapper,
  LabelWrapper,
  Required,
  StyledPhoneInput,
  Error,
} from "./StyledPhoneInput";
import {
  FieldError,
  FieldErrorsImpl,
  Merge,
  Noop,
  RefCallBack,
} from "react-hook-form";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

type PhoneInputProps = {
  field: {
    onChange: (...event: any[]) => void;
    onBlur: Noop;
    value: any;
    disabled?: boolean | undefined;
    name: string;
  };
  phoneRef: RefCallBack;
  isError: FieldError | Merge<FieldError, FieldErrorsImpl<any>> | undefined;
  errorMessage?: string;
  label: string;
  width?: string;
};

export default function PhoneInputComponent({
  field,
  phoneRef,
  isError,
  errorMessage,
  label,
  width = "100%",
}: PhoneInputProps) {
  const { t } = useTranslation();
  return (
    <StyledPhoneInput $width={width}>
      <LabelErrorWrapper>
        <LabelWrapper>
          <Label>{t(label)}</Label>
          <Required>*</Required>
        </LabelWrapper>
        {isError && <Error>{errorMessage && t(errorMessage)}</Error>}
      </LabelErrorWrapper>
      <ReactPhoneInput
        {...field}
        inputProps={{
          ref: phoneRef,
          // autoFocus: true,
        }}
        placeholder={"___ ___ ____"}
        // countryCodeEditable={false}
        // country={"ca"}
        inputStyle={{
          background: isError ? THEME.red500 : THEME.grey700,
          height: "62px",
          width: "100%",
          border: isError
            ? `1px solid ${THEME.red400}`
            : `1px solid ${THEME.grey100}`,
          color: THEME.white,
          borderRadius: "8px",
          fontFamily: kanit.style.fontFamily,
          fontSize: "16px",
          fontWeight: "400",
          lineHeight: "24px",
          letterSpacing: "0em",
          boxShadow: "none",
        }}
        specialLabel=""
      />
    </StyledPhoneInput>
  );
}
