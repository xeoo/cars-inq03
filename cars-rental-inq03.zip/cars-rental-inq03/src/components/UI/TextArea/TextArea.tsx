import { Noop, RefCallBack } from "react-hook-form";
import {
  Label,
  LabelErrorWrapper,
  StyledPhoneInput,
} from "../PhoneInput/StyledPhoneInput";
import { TextArea } from "./StyledTextArea";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

type TextAreaProps = {
  field: {
    onChange: (...event: any[]) => void;
    onBlur: Noop;
    value: any;
    disabled?: boolean | undefined;
    name: string;
  };
  inputRef: RefCallBack;
  placeholder: string;
  label: string;
  width?: string;
};

export default function TextAreaComponent({
  field,
  inputRef,
  label,
  placeholder,
  width = "100%",
}: TextAreaProps) {
  const { t } = useTranslation();
  return (
    <StyledPhoneInput $width={width}>
      <LabelErrorWrapper>
        <Label>{t(label)}</Label>
      </LabelErrorWrapper>
      <TextArea placeholder={t(placeholder)} {...field} ref={inputRef} />
    </StyledPhoneInput>
  );
}
