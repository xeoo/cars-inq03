import { font16 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const TextArea = styled.textarea`
  background: ${THEME.grey700};
  height: 125px;
  border: 1px solid ${THEME.grey100};
  color: ${THEME.white};
  border-radius: 8px;
  ${font16};
  box-shadow: none;
  padding: 10px 0px 0px 10px;
  margin: 0px;
  resize: none;
  &:focus {
    outline: none;
    outline-offset: 0px;
  }
  ::placeholder {
    color: ${THEME.grey};
  }
  &:hover {
    background: ${THEME.grey600};
    border: 1px solid ${THEME.grey800};
  }
`;
