'use client'
import DashIcon from "@/assets/icon/dashIcon.svg";
import { StyledDashText, Text } from "./StyledDashText";

type DashTextProps = {
  title: string;
};
export function DashText({ title }: DashTextProps) {
  return (
    <StyledDashText>
      <DashIcon />
      <Text>{title}</Text>
    </StyledDashText>
  );
}
