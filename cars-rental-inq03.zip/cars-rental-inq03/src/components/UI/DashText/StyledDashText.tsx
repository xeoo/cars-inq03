import { DEVICE } from "@/utils/device";
import { font14, font16, font16_600_28, font20 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledDashText = styled.div`
  display: flex;
  align-items: center;
  padding: 10px 0px;
  @media (max-width: ${DEVICE.medium}px) {
    padding: 10px 20px;
  }
`;

export const Text = styled.div`
  ${font20}
  color: ${THEME.grey};
  padding-left: 15px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font14};
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font16};
  }
`;
