"use client";

import { useRouter } from "next/navigation";
import Button from "@/components/UI/Button/Button";
import { SlugType } from "@/type/type";
import { useTranslation } from "react-i18next";
import React from "react";

type TNextStepButton = SlugType & {
  step: string;
  onSubmit?: () => boolean | Promise<boolean | undefined> ;
  title?: string;
};

export default function NextStepButton({
  step,
  onSubmit,
  title = "Next Step",
}: TNextStepButton) {
  const { t } = useTranslation();
  const router = useRouter();

  const handleClick = async () => {
    let isError: boolean | undefined = false;

    if (onSubmit) {
      isError = await onSubmit();
    }

    if (!isError) {
      router.push(step);
    }
  };

  return (
    <div onClick={handleClick}>
      <Button title={t(title)} width="100%" />
    </div>
  );
}
