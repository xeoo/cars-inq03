"use client";

import axios from 'axios';
import PhoneInputComponent from "@/components/UI/PhoneInput/PhoneInput";
import {
  ButtonWrapper,
  FormWrapper,
  InputPadding,
  InputWrapper,
  StyledContactForm,
} from "./StyledContactForm";
import InputComponent from "@/components/UI/Input/Input";
import TextAreaComponent from "@/components/UI/TextArea/TextArea";
import { Controller, useForm } from "react-hook-form";
import Button from "@/components/UI/Button/Button";
import { isEmail, isNumber } from "@/helpers/validation";
import { useLoading } from '@/context/LoadingContext';

export default function ContactForm() {
  const { setLoading } = useLoading();
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data: any) => {
    try {
      setLoading(true)
      await axios.post("/api/contact-form", data);
      setLoading(false)
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <StyledContactForm>
      <FormWrapper onSubmit={handleSubmit(onSubmit)}>
        <Controller
          control={control}
          name="fullname"
          defaultValue={""}
          rules={{
            required: { value: true, message: "Required" },
          }}
          render={({ field: { ref, ...field } }) => (
            <InputComponent
              field={field}
              inputRef={ref}
              isError={errors.fullname}
              errorMessage={errors.fullname?.message?.toString()}
              label="Full Name"
              placeholder="Your full name"
            />
          )}
        />
        <InputWrapper>
          <Controller
            control={control}
            name="email"
            defaultValue={""}
            rules={{
              required: { value: true, message: "Required" },
              validate: isEmail,
            }}
            render={({ field: { ref, ...field } }) => (
              <InputComponent
                field={field}
                inputRef={ref}
                isError={errors.email}
                errorMessage={errors.email?.message?.toString()}
                label="Email"
                placeholder="name@example.com"
              />
            )}
          />
          <InputPadding />
          <Controller
            control={control}
            name="phone"
            rules={{
              required: { value: true, message: "Required" },
              minLength: { value: 10, message: "Min Length" },
              validate: isNumber,
            }}
            render={({ field: { ref, ...field } }) => (
              <PhoneInputComponent
                field={field}
                phoneRef={ref}
                isError={errors.phone}
                errorMessage={errors.phone?.message?.toString()}
                label={"Phone"}
              />
            )}
          />
        </InputWrapper>
        <Controller
          control={control}
          name="subject"
          defaultValue={""}
          rules={{
            required: { value: true, message: "Required" },
          }}
          render={({ field: { ref, ...field } }) => (
            <InputComponent
              field={field}
              inputRef={ref}
              isError={errors.subject}
              errorMessage={errors.subject?.message?.toString()}
              label="Subject"
              placeholder="Subject of the email"
            />
          )}
        />
        <Controller
          control={control}
          name="message"
          render={({ field: { ref, ...field } }) => (
            <TextAreaComponent
              label="Message"
              placeholder="Your Message"
              field={field}
              inputRef={ref}
            />
          )}
        />
        <ButtonWrapper>
          <Button type="submit" title="Send us a message" width="241px" />
        </ButtonWrapper>
      </FormWrapper>
    </StyledContactForm>
  );
}
