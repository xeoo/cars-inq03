import { DEVICE } from "@/utils/device";
import styled from "styled-components";

export const StyledContactForm = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;

export const FormWrapper = styled.form`
  width: 100%;
`;

export const InputWrapper = styled.div`
  display: flex;
  @media (max-width: ${DEVICE.medium}px) {
    flex-direction: column;
  }
`;

export const InputPadding = styled.div`
  width: 30px;
`;

export const ButtonWrapper = styled.div`
  display: flex;
  justify-content: center;
`;
