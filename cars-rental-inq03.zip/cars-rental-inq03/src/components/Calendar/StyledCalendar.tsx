import styled from "styled-components";
import ReactCalendar from "react-calendar";
import { kanit } from "@/utils/fonts";

export const StyledReactCalendar = styled(ReactCalendar)`
  &.react-calendar {
    width: unset;
    font-family: ${kanit.style.fontFamily} !important;
    .react-calendar__navigation__label {
      font-family: ${kanit.style.fontFamily} !important;
    }
  }
`;
