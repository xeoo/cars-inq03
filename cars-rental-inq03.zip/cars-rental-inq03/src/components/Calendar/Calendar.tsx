"use client";

import React from "react";
import { StyledReactCalendar } from "./StyledCalendar";
import "./Calendar.css";
import { TileDisabledFunc } from "react-calendar";

interface ICalendar {
  date: Date;
  tileDisabled: TileDisabledFunc;
  setDate: (value: any) => void;
}

type TValuePiece = Date | null;

type TValue = TValuePiece | [TValuePiece, TValuePiece];

const Calendar: React.FC<ICalendar> = ({ tileDisabled, date, setDate }) => {
  const handleDateChange = (value: TValue) => {
    setDate(value);
  };

  const isPastDate = (date: Date): boolean => {
    const today = new Date().setHours(0, 0, 0, 0);
    const validatedDate = date.setHours(0, 0, 0, 0);

    return validatedDate < today;
  };

  const tileClassName = ({
    date,
    view,
  }: {
    date: Date;
    view: string;
  }): string | null => {
    // Add class to past dates
    if (view === "month" && isPastDate(date)) {
      return "past-date";
    }
    return null;
  };

  return (
    <StyledReactCalendar
      value={date}
      onChange={handleDateChange}
      tileDisabled={tileDisabled}
      tileClassName={tileClassName}
      locale="en"
      minDate={new Date()} // Limit to the start of the current year
      maxDate={new Date(new Date().getFullYear(), 11, 31)} // Limit to the end of the current year
      next2Label={null}
      prev2Label={null}
    />
  );
};

export default Calendar;
