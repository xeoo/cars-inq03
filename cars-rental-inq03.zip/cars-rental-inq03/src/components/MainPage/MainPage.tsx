"use client";

import axios from "axios";
import { Car } from "@/types/car";
import { useEffect, useState } from "react";
import { useLoading } from '@/context/LoadingContext';
import { IFAQList } from '@/types/util';
import { useLanguage } from '@/context/LanguageContext';
import MainPageView from "./MainPageView";

const MINIMIZED_FAQ_LIST_QUANTITY = 5;

export default function MainPage() {
  const { loading, setLoading } = useLoading();
  const {language} = useLanguage()
  const [cars, setCars] = useState<Array<Car>>([])
  const [FAQList, setFAQList] = useState<IFAQList>({minimizedFaqList: [], maximizedFaqList:[] })
  
  const getCars = async () => {
    try {
      setLoading(true);
      const { data: cars } = await axios.get(`/api/cars-catalog?language=${language}`);
      setCars(JSON.parse(cars));
      const { data: FAQ } = await axios.get(`/api/faq?language=${language}`);
      const faqList = JSON.parse(FAQ);
      const minimizedFaqList = faqList.slice(0, MINIMIZED_FAQ_LIST_QUANTITY);
      setFAQList({ minimizedFaqList, maximizedFaqList: faqList });
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    getCars()
  }, [language])

  return !loading && <MainPageView cars={cars} FAQList={FAQList} />;
}
