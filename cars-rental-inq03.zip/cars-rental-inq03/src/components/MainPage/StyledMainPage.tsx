'use client'
import { DEVICE } from "@/utils/device";
import styled from "styled-components";

export const StyledMainPage = styled.div`
  height: 900px;
  width: 100vw;
  position: absolute;
  left: 0;
  z-index: 0;
  background-size: cover;
  background: 
  linear-gradient(180deg, rgba(26, 15, 20, 0) 75%, #1A0F14 100%),
    linear-gradient(0deg, rgba(6, 4, 5, 0.8), rgba(6, 4, 5, 0.8)),
    url(/image/mainHeaderLogo.png), 0;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: top;
  margin-top: -100px;
  @media (max-width: ${DEVICE.medium}px) {
    height: 550px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    height: 750px;
  }
`;

export const StyledWrapperFirstScreen = styled.div`
  position: relative;
  z-index: 1;
  height: auto; // default
  margin-bottom: 30px;

  // from the smallest to medium
  @media (max-width: ${DEVICE.medium}px) {
    margin-bottom: 40px;
  }

  // for the medium size screens
  @media (min-width: ${DEVICE.small}px) and (max-width: ${DEVICE.medium}px) {
    margin-bottom: 70px;
  }
  
  // from medium to the big one
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    margin-bottom: 70px;
  }
`;
