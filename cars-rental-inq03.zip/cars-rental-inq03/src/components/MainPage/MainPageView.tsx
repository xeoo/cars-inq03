import React from "react";
import BookingPath from "../BookingPath/BookingPath";
import CarCart from "../CarCart/CarCart";
import Faq from "../Faq/Faq";
import MainSlider from "../MainSlider/MainSlider";
import RaceCareMainPage from "../RaceCareMainPage/RaceCareMainPage";
import Stories from "../Stories/Stories";
import { StyledMainPage, StyledWrapperFirstScreen } from "./StyledMainPage";
import { Car } from "@/types/car";
import Map from "@/components/Map/Map";
import { IFAQList } from "@/types/util";

interface MainPageViewProps {
  cars: Car[];
  FAQList: IFAQList;
}

const MainPageView: React.FC<MainPageViewProps> = (props) => {
  return (
    <>
      <StyledMainPage />
      <StyledWrapperFirstScreen>
        <RaceCareMainPage />
        <BookingPath />
      </StyledWrapperFirstScreen>
      <MainSlider>
        {props.cars.map((car) => (
          <div key={car.id}>
            <CarCart key={car.id} {...car} />
          </div>
        ))}
      </MainSlider>
      <Faq FAQList={props.FAQList} />
      {/* <Stories /> */}
      <Map />
    </>
  );
};

export default MainPageView;
