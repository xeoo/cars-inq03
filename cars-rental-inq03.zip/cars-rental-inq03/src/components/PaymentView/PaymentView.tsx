"use client";

import NextStepButton from "../NextStepButton/NextStepButton";
import OrderSummary from "../OrderSummary/OrderSummary";
import {
  OrderSummaryWrapper,
  PaymentTypeWrapper,
  StyledBooking,
} from "./StyledPaymentView";
import { useEffect, useState } from "react";
import axios from "axios";
import { redirect } from "next/navigation";
import PaymentType from "../PaymentType/PaymentType";
import { loadStripe } from "@stripe/stripe-js";
import { useLoading } from "@/context/LoadingContext";
import { getFormattedDates } from "@/utils/common";
import { useOrder } from "@/context/OrderContext";
import { TPayment } from "@/types/order";

interface IPaymentCheckout {
  payments: TPayment[];
  carSlug: string;
}

const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || ""
);

export default function PaymentCheckout({
  payments,
  carSlug,
}: IPaymentCheckout) {
  const {
    order: { car, addons, totalPrice, contacts, payment: paymentOrder },
    setOrder,
  } = useOrder();
  const [payment, setPayment] = useState<TPayment>(paymentOrder || payments[0]);
  const { setLoading } = useLoading();

  const handleTogglePayment = (payment: TPayment) => {
    setPayment(payment);
  };

  const handlePayment = async () => {
    if (!payment) return false;
    try {
      setLoading(true);

      const addonsWithoutImage = addons.map(({ image, ...formattedAddon }) => {
        return formattedAddon;
      });

      const { data } = await axios.get(`/api/car-orders?carId=${car.id}`);
      const unavailableDates = JSON.parse(data);

      const formattedDates = getFormattedDates({
        orderedDates: unavailableDates,
        unAvailableDates: car.unAvailableDates,
        quantity: car.quantity,
      });

      const date = formattedDates[car.date];

      const slotsToBook = car.checkedTime.split("+");

      const isAvailable =
        date &&
        slotsToBook.reduce(
          // @ts-ignore
          (acc: boolean, slot: string) => (date[slot] ? acc : false),
          true
        );

      // @ts-ignore
      if (!isAvailable) {
        alert("Car is unavailable for this time slot");
        throw new Error("car is booked");
      }

      const { data: session } = await axios.post("/api/checkout_session", {
        car,
        payment,
        totalPrice,
        carSlug,
        contacts,
        addons: addonsWithoutImage,
      });

      const { sessionUrl, sessionId, orderId } = JSON.parse(session);
      
      sessionStorage.setItem(
        "sessionId",
        JSON.stringify({ sessionId, orderId })
      );

      setTimeout(() => {document.location.href = sessionUrl},100);
      
      return true;
    } catch (err) {
      setLoading(false);
      console.error("error payment", err);
      return true;
    }
  };

  useEffect(() => {
    if (payment) {
      setOrder((order) => ({ ...order, payment }));
    }
  }, [payment]);

  useEffect(() => {
    if (!car && !totalPrice && !addons && !contacts) {
      redirect("/checkout");
    }
  }, []);

  return (
    <StyledBooking>
      <PaymentTypeWrapper>
        <PaymentType
          payments={payments}
          selectedPayment={payment?.id}
          handleTogglePayment={handleTogglePayment}
        />
      </PaymentTypeWrapper>
      <OrderSummaryWrapper>
        {car?.checkedTime && (
          <OrderSummary
            addons={addons}
            totalPrice={totalPrice}
            paymentPercentage={payment?.payment_percentage || 100}
            carInfo={car}
          />
        )}
        <NextStepButton
          params={{ carSlug }}
          step=""
          onSubmit={handlePayment}
          title="Complete Payment"
        />
      </OrderSummaryWrapper>
    </StyledBooking>
  );
}
