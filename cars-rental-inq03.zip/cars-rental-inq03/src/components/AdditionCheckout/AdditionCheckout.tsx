"use client";

import Additions from "../Additions/Additions";
import NextStepButton from "../NextStepButton/NextStepButton";
import OrderSummary from "../OrderSummary/OrderSummary";
import {
  StyledBooking,
  AdditionsWrapper,
  OrderSummaryWrapper,
  WrapperAdditions,
} from "./StyledAdditionCheckout";
import { useEffect, useState } from "react";

import { useOrder } from "@/context/OrderContext";
import { TAddition } from "@/types/order";

interface IAdditionCheckout {
  additions: TAddition[];
  carSlug: string;
}

export type TAddons = TAddition & {
  isSelected: boolean;
};

export default function AdditionCheckout({
  additions,
  carSlug,
}: IAdditionCheckout) {
  const { order, setOrder } = useOrder();
  const [addons, setAddons] = useState<TAddons[]>(order?.addons || []);
  const handleToggleAddon = (addon: TAddition) => {
    setAddons((prevAddons) => {
      const addonIndex = prevAddons.findIndex((item) => item.id === addon.id);
      if (addonIndex !== -1) {
        const updatedAddons = [...prevAddons];
        updatedAddons[addonIndex] = {
          ...updatedAddons[addonIndex],
          isSelected: !updatedAddons[addonIndex].isSelected,
        };

        const sameTypeAddons = updatedAddons.filter(
          (item) => item.type === addon.type && item.id !== addon.id
        );
        if (sameTypeAddons.length > 0) {
          sameTypeAddons.forEach((item) => {
            const index = updatedAddons.findIndex(
              (addon) => addon.id === item.id
            );
            if (index !== -1) {
              updatedAddons[index] = {
                ...updatedAddons[index],
                isSelected: false,
              };
            }
          });
        }

        return updatedAddons;
      } else {
        const uniqueTypeAddons = prevAddons.filter(
          (item) => item.type !== addon.type
        );
        return [...uniqueTypeAddons, { ...addon, isSelected: true }];
      }
    });
  };

  useEffect(() => {
    if (additions.length > 1 && !order?.addons) {
      additions.forEach(
        (addition) =>
          addition.isDefault &&
          setAddons((addons) => {
            if (addons.find((addon) => addon.id === addition.id)) {
              return addons;
            }
            return [...addons, { ...addition, isSelected: true }];
          })
      );
    }
  }, [additions]);

  useEffect(() => {
    const total =
      addons.reduce(
        (sum, addon) => (addon.isSelected ? parseInt(addon.price) + sum : sum),
        0
      ) + parseInt(order.car.basePrice);

    setOrder((order) => ({
      ...order,
      totalPrice: total,
      addons: addons.map((addon) => ({ ...addon, id: addon.id })),
    }));
  }, [addons, order.car]);

  return (
    <StyledBooking>
      <AdditionsWrapper>
        {/* <WrapperAdditions> */}
        <Additions
          additions={additions}
          addons={addons}
          handleToggleAddon={handleToggleAddon}
        />
        {/* </WrapperAdditions> */}
      </AdditionsWrapper>
      <OrderSummaryWrapper>
        {order.car.checkedTime && (
          <OrderSummary
            addons={addons}
            totalPrice={order.totalPrice}
            carInfo={order.car}
          />
        )}
        <NextStepButton params={{ carSlug }} step="contact-info" />
      </OrderSummaryWrapper>
    </StyledBooking>
  );
}
