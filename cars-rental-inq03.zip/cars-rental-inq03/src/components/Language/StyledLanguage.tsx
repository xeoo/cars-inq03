import { DEVICE } from "@/utils/device";
import { font14, font16 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const SelectButton = styled.button<{ $selected: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0px;
  background: transparent;
  border: none;
  cursor: pointer;
  ${font16}
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font14}
  }
  color: ${(props) => (props.$selected ? THEME.red : THEME.white)};
  &:hover {
    color: ${THEME.red};
  }
`;

export const DivFlex = styled.div`
  display: flex;
`;
export const SelectWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 30px;
`;

export const OptionList = styled.ul<{ $background?: string }>`
  width: 149px;
  border: 1px solid ${THEME.grey100};
  list-style: none;
  border-radius: 4px;
  padding-inline-start: 0px;
  position: absolute;
  margin-top: 30px;
  padding-top: 14px;
  padding-bottom: 6px;
  cursor: pointer;
  z-index: 10;
  background: ${(props) =>
    props.$background ? props.$background : "transparent"};
  }};
`;

export const OptionItem = styled.li<{ $selected: boolean }>`
  display: flex;
  align-items: center;
  height: 24px;
  padding: 0 0 8px 20px;
  ${font16}
  color: ${THEME.white};
  opacity: ${(props) => (props.$selected ? "0.5" : "1")};
  &:hover {
    color: ${(props) => (props.$selected ? THEME.white : THEME.red)};
    opacity: ${(props) => (props.$selected ? "0.5" : "1")};
  }
`;

export const OptionItemTitle = styled.span`
  padding: 0 0 0px 8px;
`;

export const NameWrapper = styled.span`
  padding: 0 10px 0 8px;
`;
