"use client";

import { useEffect, useRef, useState } from "react";
import {
  DivFlex,
  OptionItem,
  OptionItemTitle,
  OptionList,
  SelectButton,
  SelectWrapper,
  NameWrapper,
} from "./StyledLanguage";
import English from "@/assets/icon/english.svg";
import Deutsch from "@/assets/icon/deutsch.svg";
import Italiano from "@/assets/icon/italiano.svg";
import Francais from "@/assets/icon/francais.svg";
import Espanol from "@/assets/icon/espanol.svg";
import Ukrainian from "@/assets/icon/ukrainian.svg";
import ArrowDown from "@/assets/icon/arrowDown.svg";
import { useTranslation } from "react-i18next";
import { TLanguage, useLanguage } from "@/context/LanguageContext";
import { useRouter, usePathname } from "next/navigation";
import { locales } from "@/constants/utils";

const languages: {
  [key in TLanguage]: { name: string; flag: React.ReactElement };
} = {
  en: { name: "English", flag: <English /> },
  de: { name: "Deutsch", flag: <Deutsch /> },
  it: { name: "Italiano", flag: <Italiano /> },
  fr: { name: "Français", flag: <Francais /> },
  es: { name: "Español", flag: <Espanol /> },
  uk: { name: "Українська", flag: <Ukrainian /> },
};

type SelectProps = {
  background?: string;
  isMobileDevice?: boolean;
};

export default function Select({ background, isMobileDevice }: SelectProps) {
  const [open, setOpen] = useState<boolean>(false);
  const { language, setLanguage } = useLanguage();

  const router = useRouter();
  const pathName = usePathname();
  const { i18n } = useTranslation();
  const newRef = useRef(null);

  useEffect(() => {
    const pathSegments = pathName.split('/');
    if(locales.includes(pathSegments[1])) {
      setLanguage(pathSegments[1] as TLanguage)
    }
  }, [pathName])

  const handleOutsideClick = () => {
    setTimeout(() => {
      setOpen(false);
    }, 200);
  };

  useEffect(() => {
    i18n.changeLanguage(language);
  }, [i18n, language]);

  useEffect(() => {
    if (open) {
      document.addEventListener("mousedown", handleOutsideClick);
      return () => {
        document.removeEventListener("mousedown", handleOutsideClick);
      };
    }
  }, [open]);

  const handleOpen = () => {
    setOpen(!open);
  };

  const handleChange = (el: TLanguage) => {
    i18n.changeLanguage(el);
    setLanguage(el);
    setOpen(false);
    const pathSegments = pathName.split('/');
    if(!locales.includes(pathSegments[1])) {
      router.push(`/${el}${pathName}`)
    } else {
      router.push(`/${el}/${pathSegments.slice(2).join('/')}`);
    }
  };

  return (
    <SelectWrapper>
      <DivFlex>
        <SelectButton onClick={handleOpen} $selected={open}>
          {languages[language].flag}
          <NameWrapper>
            {isMobileDevice
              ? languages[language].name.slice(0, 2)
              : languages[language].name}
          </NameWrapper>
          <ArrowDown />
        </SelectButton>
      </DivFlex>
      {open && (
        <OptionList ref={newRef} $background={background}>
          {(Object.keys(languages) as Array<TLanguage>).map((el, index) => (
            <OptionItem
              $selected={el === language}
              key={index}
              onClick={() => handleChange(el)}
            >
              {languages[el].flag}{" "}
              <OptionItemTitle>{languages[el].name}</OptionItemTitle>
            </OptionItem>
          ))}
        </OptionList>
      )}
    </SelectWrapper>
  );
}
