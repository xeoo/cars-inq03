"use client";
import {
  BottomWrapper,
  Contacts,
  ContactsUnderline,
  DirectionsTitle,
  FindUs,
  FindUsTitle,
  FindUsWrapper,
  IconWrapper,
  StyledMap,
  StyledMapWrapper,
  TopWrapper,
  StyledLink,
} from "./StyledMap";
import { CONTACTS } from "@/data/contacts";
import Directions from "@/assets/icon/directions.svg";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";

export default function Map() {
  const { t } = useTranslation();

  // Replace this URL with the actual Google Maps link to your location
  const googleMapsUrl =
    "https://www.google.com/maps?ll=50.284695,6.927065&z=14&t=m&hl=uk&gl=GB&mapclient=embed&cid=13101617178607182419";

  return (
    <>
      <StyledMapWrapper>
        <StyledMap></StyledMap>
      </StyledMapWrapper>
      <FindUsWrapper>
        <FindUs>
          <TopWrapper>
            <FindUsTitle>{t("findUs")}</FindUsTitle>
            <StyledLink
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              <IconWrapper>
                <Directions />
                <DirectionsTitle>{t("directions")}</DirectionsTitle>
              </IconWrapper>
            </StyledLink>
          </TopWrapper>
          <BottomWrapper itemScope itemType="http://schema.org/ContactPoint">
            <Contacts>{CONTACTS.address}</Contacts>
            <ContactsUnderline itemProp="email">
              {CONTACTS.email}
            </ContactsUnderline>
            <a itemProp="telephone" href={`tel:${CONTACTS.phone}`}>
              <ContactsUnderline>
                {CONTACTS.phone}
              </ContactsUnderline>
            </a>
          </BottomWrapper>
        </FindUs>
      </FindUsWrapper>
    </>
  );
}
