import { DEVICE } from "@/utils/device";
import { font14, font16, font20_600_28, font26 } from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledMap = styled.div`
  width: 100vw;
  position: absolute;
  z-index: 0;
  background-size: cover;
  background: url(image/map.png), ${THEME.grey400};
  background-blend-mode: luminosity;
  background-position: center;
  @media (max-width: ${DEVICE.medium}px) {
    height: 500px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    height: 600px;
  }
  @media (min-width: ${DEVICE.large}px) {
    height: 810px;
  }
`;

export const StyledLink = styled.a`
  text-decoration: none;
  color: inherit;

  &:hover {
    text-decoration: underline;
    text-decoration-color: red;
  }
`;


export const StyledMapWrapper = styled.div`
  padding-bottom: 810px;
  @media (max-width: ${DEVICE.medium}px) {
    padding-bottom: 500px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    padding-bottom: 550px;
  }
`;

export const FindUs = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  bottom: 940px;
  width: 380px;
  height: 218px;
  border-radius: 8px;
  background: ${THEME.white};
  @media (max-width: ${DEVICE.medium}px) {
    width: 320px;
    height: 207px;
  }
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    bottom: 770px;
    width: 370px;
    height: 218px;
  }
`;

export const FindUsWrapper = styled.div`
  display: flex;
  justify-content: center;
`;

export const FindUsTitle = styled.div`
  ${font26}
  color: ${THEME.dark100};
  @media (max-width: ${DEVICE.medium}px) {
    ${font20_600_28}
  }
`;

export const DirectionsTitle = styled.div`
  ${font14}
  color: ${THEME.red};
`;

export const Contacts = styled.div`
  ${font16};
  color: ${THEME.grey200};
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
  }
`;

export const ContactsUnderline = styled.div`
  ${font16}
  color: ${THEME.grey200};
  text-decoration: underline;
`;

export const TopWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 30px 30px 0px 30px;
  @media (max-width: ${DEVICE.medium}px) {
    flex-direction: column;
    padding: 14px 30px 0px 30px;
  }
`;

export const BottomWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;
  height: 96px;
  padding: 30px;
  @media (max-width: ${DEVICE.medium}px) {
    align-items: center;
  }
`;

export const IconWrapper = styled.div`
  display: flex;
  width: 90px;
  align-items: center;
  justify-content: space-between;
  @media (max-width: ${DEVICE.medium}px) {
    margin-top: 10px;
  }
`;
