"use client";

import axios from 'axios';
import {
  AddButton,
  Button,
  ContentFaq,
  FaqWrapper,
  FaqWrapperOpen,
  Label,
  StyledFaq,
  Title,
} from "./StyledFaq";
import AddIcon from "@/assets/icon/addButton.svg";
import MinusIcon from "@/assets/icon/minusButton.svg";
import { Fragment, useEffect, useState } from "react";
import "@/localization/i18n";
import { useTranslation } from "react-i18next";
import { useLoading } from '@/context/LoadingContext';
import { IFAQList } from '@/types/util';

export default function Faq({FAQList}: {FAQList: IFAQList}) {
  const { setLoading } = useLoading();
  const [isMinimized, setIsMinimized] = useState(true)
  const [currentQuestion, setcurrentQuestion] = useState<number | null>(null);
  const { t } = useTranslation();

  const getFAQList = async () => {
    try {
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  }

  useEffect(() => {
    setLoading(true);
    getFAQList();
  }, [])

  const showAnswer = (i: number) => {
    setcurrentQuestion(i);
  };

  const hideAnswer = () => {
    setcurrentQuestion(null);
  };

  const toggleList = () => {
    setIsMinimized((value) => !value)
  };

  return (
    <StyledFaq>
      <Title itemProp="name"> {t("faq")}</Title>
      {FAQList?.[isMinimized? 'minimizedFaqList' : 'maximizedFaqList'].map(({ title, content }, index) => (
        // eslint-disable-next-line react/jsx-key
        <Fragment key={`answer-question-${index}`}>
          {currentQuestion === index ? (
            <Fragment key={`activ-question-${index}`}>
              <FaqWrapperOpen>
                <Label itemProp="name">{title}</Label>
                <AddButton onClick={hideAnswer}>
                  <MinusIcon />
                </AddButton>
              </FaqWrapperOpen>
              <ContentFaq
                key={`activ--${index}`}>
                <div dangerouslySetInnerHTML={{ __html: content }} />
            </ContentFaq>
            </Fragment>
          ) : (
            <FaqWrapper key={`question-${index}`}>
              <Label>{title}</Label>
              <AddButton onClick={() => showAnswer(index)}>
                <AddIcon />
              </AddButton>
            </FaqWrapper>
          )}
        </Fragment>
      ))}
      {FAQList?.maximizedFaqList && FAQList?.maximizedFaqList?.length > 5 &&
      <Button onClick={toggleList}>{isMinimized ? t("seeMore") : t("seeLess")}</Button>}
    </StyledFaq>
  );
}
