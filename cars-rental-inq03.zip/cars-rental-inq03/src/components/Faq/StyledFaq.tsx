import { DEVICE } from "@/utils/device";
import {font14, font16, font20, font24, font26, font32, font40, font48, font56} from "@/utils/fonts";
import { THEME } from "@/utils/theme";
import styled from "styled-components";

export const StyledFaq = styled.div`
  margin-left: auto;
  margin-right: auto;
  background: ${THEME.dark};
  display: flex;
  flex-direction: column;
  margin-bottom: 100px;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    width: ${DEVICE.medium}px;
  }
  @media (min-width: ${DEVICE.large}px) {
    width: ${DEVICE.large}px;
  }
`;

export const Title = styled.h3`
  ${font56}
  color: ${THEME.white};
  margin-bottom: 60px;
  display: flex;
  justify-content: start;
  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    ${font48}
    justify-content: center;
  }
  @media (max-width: ${DEVICE.medium}px) {
    ${font24}
    justify-content: center;
    margin-bottom: 30px;
  }
  @media (min-width: ${DEVICE.large}px) {
  }
`;

export const Label = styled.h3`
  ${font20}
  color: ${THEME.grey};
  @media (max-width: ${DEVICE.medium}px) {
    ${font16}
  }
`;

export const FaqWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 69px;
  padding-left: 20px;
  padding-right: 20px;
  border-top: 1px solid ${THEME.grey100};
  border-bottom: 1px solid ${THEME.grey100};
`;

export const AddButton = styled.button`
  background: transparent;
  border: none;
  width: 24px;
  height: 25px;
  padding: 0;
  margin-left: 20px;
  &:hover {
    svg {
      g {
        path {
          fill: ${THEME.white};
        }
      }
    }
  }
`;

export const Button = styled.button`
  background: transparent;
  ${font16}
  border: none;
  color: ${THEME.red};
  cursor: pointer;
  text-decoration: underline;
  margin-top: 60px;

  @media (min-width: ${DEVICE.medium}px) and (max-width: ${DEVICE.large}px) {
    justify-content: center;
    margin-top: 45px;
  }
  @media (max-width: ${DEVICE.medium}px) {
    justify-content: center;
    margin-bottom: 0px;
    margin-top: 30px;
  }
  @media (min-width: ${DEVICE.large}px) {
  }
`;

export const ContentFaq = styled.div`
  background: ${THEME.grey100};
  color: ${THEME.grey};
  ${font16}
  padding: 30px;
  @media (max-width: ${DEVICE.medium}px) {
    ${font14}
  }
`;

export const FaqWrapperOpen = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 69px;
  background: ${THEME.dark50};
  padding-left: 20px;
  padding-right: 20px;
  border-top: 1px solid ${THEME.grey100};
  border-bottom: 1px solid ${THEME.grey100};
`;
