import { Order } from '@/types/order';
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

interface OrderContextProps {
  order: Order;
  setOrder: React.Dispatch<React.SetStateAction<Order>>;
}

const OrderContext = createContext<OrderContextProps | null>(null);

export const OrderProvider= ({ children }:{ children: ReactNode }) => {
  const [order, setOrder] = useState({});

  useEffect(() => {
    const sessionOrder = sessionStorage.getItem("order");

    if (sessionOrder) {
      setOrder(JSON.parse(sessionOrder));
    }
  }, []);

  return (
    // @ts-ignore
    <OrderContext.Provider value={{ order, setOrder}}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = (): OrderContextProps => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrder must be used within a OrderProvider');
  }
  return context;
};
