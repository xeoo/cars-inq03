import { Car } from '@/types/car';
import React, { createContext, useState, useContext, ReactNode } from 'react';

interface CarsContextProps {
  cars: Array<Car>;
  setCars: React.Dispatch<React.SetStateAction<Array<Car>>>;
}

const CarsContext = createContext<CarsContextProps | null>(null);

export const CarsProvider= ({ children }:{ children: ReactNode }) => {
  const [cars, setCars] = useState([]);

  return (
    // @ts-ignore
    <CarsContext.Provider value={{ cars, setCars}}>
      {children}
    </CarsContext.Provider>
  );
};

export const useCars = (): CarsContextProps => {
  const context = useContext(CarsContext);
  if (!context) {
    throw new Error('useCars must be used within a CarsProvider');
  }
  return context;
};
