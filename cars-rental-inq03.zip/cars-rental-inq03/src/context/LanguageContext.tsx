import React, { createContext, useState, useContext, ReactNode } from 'react';

export type TLanguage = "en" | "de" | "it" | "fr" | "es" | "uk";

interface LanguageContextProps {
  language: TLanguage;
  setLanguage: React.Dispatch<React.SetStateAction<TLanguage>>;
}

const LanguageContext = createContext<LanguageContextProps | null>(null);

export const LanguageProvider= ({ children }:{ children: ReactNode }) => {
  const [language, setLanguage] = useState<TLanguage>('en');

  return (
    <LanguageContext.Provider value={{ language, setLanguage}}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextProps => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
