import { Car } from '@/types/car';
import React, { createContext, useState, useContext, ReactNode } from 'react';

interface CarContextProps {
  car: Car;
  setCar: React.Dispatch<React.SetStateAction<Car>>;
}

const CarContext = createContext<CarContextProps | null>(null);

export const CarProvider= ({ children }:{ children: ReactNode }) => {
  const [car, setCar] = useState<Car | null>();

  return (
    // @ts-ignore
    <CarContext.Provider value={{ car, setCar}}>
      {children}
    </CarContext.Provider>
  );
};

export const useCar = (): CarContextProps => {
  const context = useContext(CarContext);
  if (!context) {
    throw new Error('useCar must be used within a CarProvider');
  }
  return context;
};
