import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import { locales } from '@/constants/utils';
import en from "./locales/en.json";
import de from "./locales/de.json";
import it from "./locales/it.json";
import fr from "./locales/fr.json";
import es from "./locales/es.json";
import uk from "./locales/uk.json";

const resources = {
  en: en,
  de: de,
  it: it,
  fr: fr,
  es: es,
  uk: uk,
};

i18n.use(initReactI18next).init({
  resources,
  lng: "en",
  supportedLngs: locales,
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
