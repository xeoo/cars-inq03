export const DATA_CARS = [
  {
    id: "8990865883443",
    title: "vw Scirocco GT",
    description:
      "Purpose driven design to eliminate doubt and inspire confidence. Purpose driven.",
    price: 176,
    laps: 2,
    icon: "https://s3-alpha-sig.figma.com/img/9cdb/0d6e/2a123da16477524fda1c19b08b1952e7?Expires=1713139200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=UK6bjuyGntkTyzVOUlskg9FzjaGQCgxjldjzTkqSK6ZLCpS8zgwpDHyFdGGnxGb3l4wnnlFrOGVitxCSfaoRG3RclZJA56VI1wgKYnrNuQ~Nf~~wreqEUw9x4CqauD5qWRBcFdmenY57QpI3Rc1oN5FOAWs3KM~NxR8VBmAD563SrHBHHXOYUzBSjR0RuEcKCmngUWU5ukjITvNWyYukE6usZjKk9mriWcprSzsbKgH4fNZ-muqiK4Mtt5ZyejGxeeGxqw6FnFgO5~ykmBM~WpBIJc8nGhWUkAGJTdD0ZL4gYBrrt9O7POruexEECzQlXsUeeHj3tt7oPeMVgqFsGw__",
    iconRight: false,
  },
  {
    id: "12345",
    title: "BMW X1 F48",
    description:
      "Purpose driven design to eliminate doubt and inspire confidence. Purpose driven.",
    price: 176,
    laps: 2,
    icon: "https://s3-alpha-sig.figma.com/img/9cdb/0d6e/2a123da16477524fda1c19b08b1952e7?Expires=1713139200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=UK6bjuyGntkTyzVOUlskg9FzjaGQCgxjldjzTkqSK6ZLCpS8zgwpDHyFdGGnxGb3l4wnnlFrOGVitxCSfaoRG3RclZJA56VI1wgKYnrNuQ~Nf~~wreqEUw9x4CqauD5qWRBcFdmenY57QpI3Rc1oN5FOAWs3KM~NxR8VBmAD563SrHBHHXOYUzBSjR0RuEcKCmngUWU5ukjITvNWyYukE6usZjKk9mriWcprSzsbKgH4fNZ-muqiK4Mtt5ZyejGxeeGxqw6FnFgO5~ykmBM~WpBIJc8nGhWUkAGJTdD0ZL4gYBrrt9O7POruexEECzQlXsUeeHj3tt7oPeMVgqFsGw__",
    iconRight: true,
  },
  {
    id: "12347",
    title: "vw Golf GTi",
    description:
      "Purpose driven design to eliminate doubt and inspire confidence. Purpose driven.",
    price: 176,
    laps: 2,
    icon: "https://s3-alpha-sig.figma.com/img/9cdb/0d6e/2a123da16477524fda1c19b08b1952e7?Expires=1713139200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=UK6bjuyGntkTyzVOUlskg9FzjaGQCgxjldjzTkqSK6ZLCpS8zgwpDHyFdGGnxGb3l4wnnlFrOGVitxCSfaoRG3RclZJA56VI1wgKYnrNuQ~Nf~~wreqEUw9x4CqauD5qWRBcFdmenY57QpI3Rc1oN5FOAWs3KM~NxR8VBmAD563SrHBHHXOYUzBSjR0RuEcKCmngUWU5ukjITvNWyYukE6usZjKk9mriWcprSzsbKgH4fNZ-muqiK4Mtt5ZyejGxeeGxqw6FnFgO5~ykmBM~WpBIJc8nGhWUkAGJTdD0ZL4gYBrrt9O7POruexEECzQlXsUeeHj3tt7oPeMVgqFsGw__",
    iconRight: false,
  },
];
