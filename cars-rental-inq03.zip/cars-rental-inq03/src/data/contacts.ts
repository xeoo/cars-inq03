export const CONTACTS = {
  address: "Auf d. Struth 9, 53539 Kelberg",
  email: "support@prodrivenurburg.de",
  phone: "+49 160 94971339",
};
