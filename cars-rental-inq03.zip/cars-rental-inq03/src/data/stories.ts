export const DATA_STORIES = [
  {image: "/image/car.jpeg", alt: "bmw car"},
  {image: "/image/car.jpeg", alt: "bmw car"},
  {image: "/image/car.jpeg", alt: "bmw car"},
  {image: "/image/car.jpeg", alt: "bmw car"},
  {image: "/image/car.jpeg", alt: "bmw car"},
];
