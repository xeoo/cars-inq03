export const STORIES = {
  yourRideStories: "Your Ride Stories",
  proDriveNurb: "#ProDriveNurb",
  winner:
    '"The winner is not the one in the fastest car, but the one who refuses to lose."',
  autor: "Dale Earnhardt",
};
