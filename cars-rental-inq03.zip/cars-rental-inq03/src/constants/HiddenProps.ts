export const hiddenClassNames = {
  smallDown: "small-down",
  smallUp: "small-up",
  mediumDown: "medium-down",
  mediumUp: "medium-up",
  largeDown: "large-down",
  largeUp: "large-up",
};
