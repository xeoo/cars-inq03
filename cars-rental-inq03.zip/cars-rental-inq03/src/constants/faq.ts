export const FAQ = [
  {
    title: "What do you need to drive the Nürburgring Nordschleife with us?",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
  {
    title: "How can I prepare?",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
  {
    title: "When is the best time to drive the ring?",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
  {
    title: "What is the difference between a Public Session and a Trackday?",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
  {
    title: "What is the difference between Basic and All-Inclusive options?",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
  {
    title: "FAQ 6",
    content:
      "<p>Eget magna fermentum iaculis eu non diam phasellus. Et pharetra pharetra massa massa ultricies mi quis hendrerit dolor. Eu non diam phasellus vestibulum lorem. Odio pellentesque diam volutpat commodo. Mauris in aliquam sem fringilla ut morbi tincidunt augue interdum. Eget magna fermentum iaculis eu non diam phasellus. Praesent semper feugiat nibh sed pulvinar.</p><p>Mauris cursus mattis molestie a iaculis at erat. Aliquet nec ullamcorper sit amet risus nullam. Arcu non sodales neque sodales ut etiam. Lorem sed risus ultricies tristique nulla aliquet enim tortor at. Faucibus turpis in eu mi bibendum neque egestas. Gravida rutrum quisque non tellus orci ac.</p><p> Eu mi bibendum neque egestas congue quisque egestas diam. Porttitor leo a diam sollicitudin. Morbi non arcu risus quis varius quam quisque. Dignissim enim sit amet venenatis. Habitasse platea dictumst quisque sagittis purus sit amet.</p>",
  },
];
