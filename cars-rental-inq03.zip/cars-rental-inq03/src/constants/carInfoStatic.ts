export const CAR_INFO_STATIC = {
  characteristics: [
    { title: "Motor", description: "2.0 Turbo /252PS" },
    { title: "0-100 kph", description: "5.3 seconds" },
    { title: "Transmission", description: "8-speed ZF" },
    { title: "Weight", description: "1400 kg" },
    { title: "Drive", description: "Rear-wheel drive" },
  ],
};
