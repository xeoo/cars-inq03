'use client';

import StepOneIcon from "@/assets/icon/checkoutStepOne.svg";
import StepTwoIcon from "@/assets/icon/checkoutStepTwo.svg";
import StepThreeIcon from "@/assets/icon/checkoutStepThree.svg";
import StepFourIcon from "@/assets/icon/checkoutStepFour.svg";
import StepFiveIcon from "@/assets/icon/checkoutStepFive.svg";

export const checkoutPath = [
  {
    icon: StepOneIcon,
    title: "stepOne",
    label: "Car details",
  },
  {
    icon: StepTwoIcon,
    title: "stepTwo",
    label: "Booking date",
    link: "booking",
  },
  {
    icon: StepThreeIcon,
    title: "stepThree",
    label: "Additions",
    link: "additions",
  },
  {
    icon: StepFourIcon,
    title: "stepFour",
    label: "Contact info",
    link: "contact-info",
  },
  {
    icon: StepFiveIcon,
    title: "stepFive",
    label: "Payment",
  },
];
