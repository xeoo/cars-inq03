'use client'
import FacebookIcon from "@/assets/icon/mediaFacebook.svg";
import InstagramIcon from "@/assets/icon/mediaInstagram.svg";
import WhatsAppIcon from "@/assets/icon/mediaWhatsApp.svg";

export const routes = {
  mainPage: { name: "", id: 1, path: "/" },
  mainRoutes: [
    { name: "Our cars", id: 2, path: "/catalog" },
    { name: "Book a car", id: 3, path: "/checkout" },
    { name: "Safety & Rules", id: 4, path: "/safety-rules" },
    { name: "Contacts", id: 5, path: "/contacts" },
  ],
  secondRoutes: [
    { name: "Terms and conditions", id: 6, path: "/terms-and-conditions" },
    { name: "Impressum", id: 7, path: "/impressum" },
    { name: "Privacy policy", id: 8, path: "/privacy" },
  ],
  // Please add a valid social media link
  mediaRoutes: [
    {
      id: 1,
      path: "https://facebook.com/prodrivenurburg",
      icon: FacebookIcon,
    },
    {
      id: 2,
      path: "https://instagram.com/prodrive_nurburg",
      icon: InstagramIcon,
    },
    {
      id: 3,
      path: "https://wa.me/4916094971339",
      icon: WhatsAppIcon,
    },
  ],
};
