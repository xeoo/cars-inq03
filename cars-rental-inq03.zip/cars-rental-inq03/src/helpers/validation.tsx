export const isNumber = (number: number) =>
  !isNaN(number) || "Must be a number";

export const isEmail = (email: string) =>
  isCorrectEmail(email) || "Check that your email is entered correctly";

const isCorrectEmail = (email: string) => {
  const emailRegex = new RegExp(
    /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
    "gm"
  );
  return emailRegex.test(email);
};
