export type SlugType = {
  params: { carSlug: string };
};
