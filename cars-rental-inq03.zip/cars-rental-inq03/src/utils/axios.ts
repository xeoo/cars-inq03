import axios from 'axios';
import { useLoading } from '../context/LoadingContext';
import { useEffect } from 'react';

const useAxiosInterceptors = () => {
  const { setLoading } = useLoading();

  useEffect(() => {
    const requestInterceptor = axios.interceptors.request.use(config => {
      setLoading(true);
      return config;
    });

    const responseInterceptor = axios.interceptors.response.use(
      response => {
        setTimeout(() => {
          setLoading(false);
        }, 0)
        return response;
      },
      error => {
        setTimeout(() => {
          setLoading(false);
        }, 0);
        return Promise.reject(error);
      }
    );

    return () => {
      axios.interceptors.request.eject(requestInterceptor);
      axios.interceptors.response.eject(responseInterceptor);
    };
  }, [setLoading]);

  return axios;
};

export default useAxiosInterceptors;
