export const DEVICE = {
  small: 360,
  medium: 768,
  large: 1170,
  mediumSliderButton: 1530,
};
