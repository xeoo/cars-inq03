
import calenarDate from "../../public/calendar";


const LAP_DURATION = 40;

const timeToMinutes = (time: string) => {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
};

const getMaxLaps = (openTime: string, closeTime: string) => {
  const openMinutes = timeToMinutes(openTime);
  const closeMinutes = timeToMinutes(closeTime);
  const totalAvailableMinutes = closeMinutes - openMinutes;
  const maxLaps = Math.floor(totalAvailableMinutes / LAP_DURATION);

  return maxLaps > 0 ? maxLaps : 0;
}

type TFormattedDatesArgs = {
  orderedDates: { [key: string]: string[]}, 
  unAvailableDates?: {[key: string]: number}, 
  quantity?: number
}
export const getFormattedDates = ({orderedDates, unAvailableDates, quantity = 1}: TFormattedDatesArgs) => {
  const formattedDates: Record<string, { morning?: string; defaultTime?: string; isFullPrice?: boolean; evening?: string; isFullDayAvailable?: boolean; open_time?: string; close_time?: string; morningLaps?: number; eveningLaps?: number; }> = {};
  const calendarDates: Record<string, { isSplit: boolean; open_time: string; close_time: string; isFullPrice?:boolean }> = calenarDate;

  for (const date in calendarDates) {
    const { isSplit, open_time, close_time, isFullPrice = false } = calendarDates[date];

    const reservedDateTimes = unAvailableDates && unAvailableDates[date] ? unAvailableDates[date] : 0;

    let orderedSlots = {
      morning: reservedDateTimes, 
      evening: reservedDateTimes
    }

    if(orderedDates[date]) {
      orderedSlots = orderedDates[date].reduce((acc, item) => {
        if (item === 'morning') {
          acc.morning += 1;
        } else if (item === 'evening') {
          acc.evening += 1;
        } else if (item === 'morning+evening') {
          acc.morning += 1;
          acc.evening += 1;
        }
      
        return acc;
      }, {morning: reservedDateTimes, evening: reservedDateTimes});
    }

    const morningEnd = "13:00";
    if (isSplit) {
      formattedDates[date] = {
        morning: `${open_time} - ${morningEnd}`,
        evening: `${morningEnd} - ${close_time}`,
        open_time,
        close_time,
        isFullPrice,
        morningLaps: getMaxLaps(open_time, morningEnd),
        eveningLaps: getMaxLaps(morningEnd, close_time),
        defaultTime: 'morning'
      };
    } else {
      let lapsDay = {
        morningLaps: 0,
        eveningLaps: 0,
        isFullPrice
      }
      if (timeToMinutes(open_time) < timeToMinutes(morningEnd)) {
        formattedDates[date] = {
          ...lapsDay,
          open_time,
          close_time: morningEnd,
          morning: `${open_time} - ${close_time}`,
          morningLaps: getMaxLaps(open_time, close_time),
          defaultTime: 'morning'
        }
      } else {
        formattedDates[date] = {
          ...lapsDay,
          open_time: morningEnd,
          close_time: close_time,
          evening: `${open_time} - ${close_time}`,
          defaultTime: 'evening',
          eveningLaps: getMaxLaps(open_time, close_time)
        }
      }
    }

    if (orderedSlots.morning >= quantity) {
      delete formattedDates[date]?.morning;
      formattedDates[date].defaultTime = 'evening';
    }

    if (orderedSlots.evening >= quantity) {
      delete formattedDates[date]?.evening
    }

    if(!formattedDates[date]?.evening && !formattedDates[date]?.morning ) {
      delete formattedDates[date];
    }

    if(formattedDates[date]?.evening && formattedDates[date]?.morning ) {
      formattedDates[date].isFullDayAvailable = true;
    }
  }

  return formattedDates;
}
