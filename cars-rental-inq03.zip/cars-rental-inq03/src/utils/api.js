import axios from 'axios';

export const getLocalizedCars = async (cars, language, domain, config) => {
  const localizedCarsPromises = cars.map(async (car) => {
    const LocalizationId = car.attributes.localizations.data.find((localizations) => localizations.attributes.locale === language)?.id
    if (LocalizationId) {
      const { data: localizedCar } = await axios.get(`${domain}/api/cars/${LocalizationId}?populate=*&locale=${language}`, config);

      return ({ ...car, attributes: { ...car.attributes, ...localizedCar.data.attributes } })
    }

    return car
  })

  return Promise.all(localizedCarsPromises);
}