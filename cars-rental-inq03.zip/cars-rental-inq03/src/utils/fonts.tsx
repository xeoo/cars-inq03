import { Kanit } from "next/font/google";

export const kanit = Kanit({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

export const font12 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 12px;
  font-weight: 400;
  line-height: 20px;
`;

export const font14 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
`;

export const font14_24 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 14px;
  font-weight: 400;
  line-height: 24px;
`;

export const font14_28 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 14px;
  font-weight: 400;
  line-height: 28px;
`;

export const font16 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 16px;
  font-weight: 400;
  line-height: 24px;
  letter-spacing: 0em;
`;

export const font16_600_28 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 16px;
  font-weight: 600;
  line-height: 28px;
`;

export const font56 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 56px;
  font-weight: 600;
  line-height: 60px;
  letter-spacing: 0em;
`;

export const font60 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 60px;
  font-weight: 600;
  line-height: 70px;
  letter-spacing: 0em;
`;

export const font20 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 20px;
  font-weight: 400;
  line-height: 28px;
  letter-spacing: 0em;
`;

export const font20_600 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 20px;
  font-weight: 600;
  line-height: 24px;
`;

export const font20_600_28 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 20px;
  font-weight: 600;
  line-height: 28px;
`;

export const font20_400_26 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 20px;
  font-weight: 400;
  line-height: 26px;
`;

export const font28_600_36 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 28px;
  font-weight: 600;
  line-height: 36px;
`;

export const font44_600_52 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 44px;
  font-weight: 600;
  line-height: 52px;
`;

export const font26 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 26px;
  font-weight: 600;
  line-height: 32px;
`;

export const font48 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 48px;
  font-weight: 600;
  line-height: 56px;
`;

export const font24 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 24px;
  font-weight: 600;
  line-height: 32px;
`;

export const font40 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 40px;
  font-weight: 600;
  line-height: 52px;
`;

export const font32 = `
  font-family: ${kanit.style.fontFamily};
  font-size: 32px;
  font-weight: 600;
  line-height: 40px;
  text-align: center;
`;
