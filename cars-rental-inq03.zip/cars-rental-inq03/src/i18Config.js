import { locales } from './constants/utils';

export const i18nConfig = {
  locales,
  defaultLocale: 'en'
};
