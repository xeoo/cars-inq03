export type Characteristic = { title: string, description: string }

export interface CarDetail {
  descriptionHtml: string,
  specifications: Array<any>,
  characteristics: Array<Characteristic>,
  id: string,
}

export interface Car {
  id: string,
  title: string,
  priceOptions: Array<{ price: string, laps: number, fullPrice: string}>,
  description: string,
  price: number,
  icon: string,
  laps: string,
  iconRight: boolean,
  characteristics: Array<Characteristic>,
  image: string,
  quantity: number,
  unAvailableDates: {[key: string]: number}
}
