import { Car } from "./car";

export interface TPayment {
  id: string,
  title: string,
  image: string,
  description: string,
  payment_percentage: number,
}

export interface TAddition {
  id: string;
  title: string;
  image: string;
  price: string;
  description: string;
  isDefault: boolean;
  type: string;
  descriptionHtml: string;
}

export type CarOrder = Car & {
  checkedLaps: number;
  carDetail: string;
  checkedTime: string;
  isFullPrice: boolean;
  time: string;
  date: string;
  carId: string;
  basePrice: string;
};
export type Addon = TAddition & { isSelected: boolean };
export type Contacts = {
  email: string;
  firstName: string;
  lastName: string;
  phone: string; 
  clientId: number;
}
export type Payment = { payment: string }

export interface Order {
  car: CarOrder;
  addons: Array<Addon>;
  contacts: Contacts;
  payment: TPayment;
  totalPrice: number;
}