export type FaqType = {
  title: string;
  content: string;
};

export interface IFAQList {
  minimizedFaqList: FaqType[], maximizedFaqList: FaqType[]
}