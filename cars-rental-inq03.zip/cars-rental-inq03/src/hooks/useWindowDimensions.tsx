import { DEVICE } from "@/utils/device";
import { useState, useEffect } from "react";

interface UseWindowDimensionsResult {
  width: number;
  height: number;
  isSmallScreen: boolean;
  isMediumScreen: boolean;
  isLargeScreen: boolean;
}

export function useWindowDimensions(): UseWindowDimensionsResult {
  // Initialize state with undefined width/height so server and client renders match
  // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
  const [windowSize, setWindowSize] = useState<{
    width: undefined | number;
    height: undefined | number;
  }>({ width: undefined, height: undefined });

  const [isLargeScreen, setLargeScreen] = useState<boolean>(false);
  const [isMediumScreen, setMediumScreen] = useState<boolean>(false);
  const [isSmallScreen, setSmallScreen] = useState<boolean>(false);

  useEffect(() => {
    // only execute all the code below in client side
    // Handler to call on window resize
    function handleResize() {
      // Set window width/height to state
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    }

    // Add event listener
    window.addEventListener("resize", handleResize);

    // Call handler right away so state gets updated with initial window size
    handleResize();

    // Remove event listener on cleanup
    return () => window.removeEventListener("resize", handleResize);
  }, []); // Empty array ensures that effect is only run on mount
  const { width, height } = windowSize;

  useEffect(() => {
    if (!width) {
      return;
    }

    if (width <= DEVICE.medium) {
      setSmallScreen(true);
      setMediumScreen(false);
      setLargeScreen(false);
    }

    if (width >= DEVICE.medium + 1 && width <= DEVICE.large) {
      setSmallScreen(false);
      setMediumScreen(true);
      setLargeScreen(false);
    }

    if (width >= DEVICE.large + 1) {
      setSmallScreen(false);
      setMediumScreen(false);
      setLargeScreen(true);
    }
  }, [width]);

  if (!width || !height) {
    return {
      height: 0,
      width: 0,
      isLargeScreen: false,
      isMediumScreen: false,
      isSmallScreen: false,
    };
  }

  return { height, width, isLargeScreen, isMediumScreen, isSmallScreen };
}
