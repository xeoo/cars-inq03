/** @type {import('next').NextConfig} */
const nextConfig = {
  crossOrigin: 'anonymous',
  pageExtensions: ['mdx', 'md', 'jsx', 'js', 'tsx', 'ts'],
  compiler: {
    styledComponents: true,
  },
  webpack(config) {
    config.module.rules.push({
      test: /\.svg$/i,
      issuer: /\.[jt]sx?$/,
      use: ['@svgr/webpack'],
    })

    return config
  },
  headers: () => [
    {
      source: '/checkout/1/booking',
      headers: [
        {
          key: 'Cache-Control',
          value: 'no-store',
        },
      ],
    },
  ],
  images: {
    domains: ['cdn.shopify.com', '31.131.21.128'],
  },
};

export default nextConfig;
